<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ACCOUNTTICK SYSTEM</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?= base_url('plugins/fontawesome-free/css/all.min.css') ?>">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="<?=base_url('plugins/icheck-bootstrap/icheck-bootstrap.min.css') ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?=base_url('dist/css/adminlte.min.css') ?>">
</head>
<body class="hold-transition register-page">
<div class="register-box">
  <div class="card card-outline card-primary">
    <div class="card-header text-center">
      <a href="../../index2.html" class="h1"><b>Register</b></a>
    </div>
    <div class="card-body">
      <p class="login-box-msg">Register a new membership</p>

      <form action="" method="post" enctype="multipart/form-data" id="add_data">
        <div class="input-group mb-3">
          <input type="text" name="fullname" class="form-control" placeholder="Full name">
          <p id="fullnameError" style="color: red;" class="invalid-input"></p>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="text" name="address" class="form-control" placeholder="Address">
          <p id="addressError" style="color: red;" class="invalid-input"></p>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="email" name="email" class="form-control" placeholder="Email">
          <p id="emailError" style="color: red;" class="invalid-input"></p>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" name="password" class="form-control" placeholder="Password">
          <p id="passwordError" style="color: red;" class="invalid-input"></p>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" name="repassword" class="form-control" placeholder="Retype password">
          <p id="repasswordError" style="color: red;" class="invalid-input"></p>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <!-- /.col -->
          
          <!-- /.col -->
        </div>
        <div class="social-auth-links text-center">
        <button type="submit" class="btn btn-block btn-primary">
          Register
        </button>
        <a href="<?= base_url('/') ?>" class="btn btn-block btn-danger">
          I already have a membership
        </a>
      </div>
      </form>

      
    </div>
    <!-- /.form-box -->
  </div><!-- /.card -->
</div>
<!-- /.register-box -->

<script src="<?= base_url('plugins/jquery/jquery.min.js') ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script type="text/javascript">

    $('body').on('submit', '#add_data', function (e) {
    e.preventDefault();
    

    let formData = new FormData(this);

    $.ajax({
      url: '<?php echo base_url('save_register'); ?>',
      type: 'POST',
      data: formData,
      dataType: 'json',
      contentType: false,
      processData: false,
      success: function (response) {
      if (response['status'] == 0) {
        if (response['fullname'] != "") {
            $('#fullnameError').html(response['fullname']).addClass('invalid-input');
          } else {
            $('#fullnameError').html('').removeClass('invalid-input');
          }

          if (response['address'] != "") {
            $('#addressError').html(response['address']).addClass('invalid-input');
          } else {
            $('#addressError').html('').removeClass('invalid-input');
          }

          if (response['email'] != "") {
            $('#emailError').html(response['email']).addClass('invalid-input');
          } else {
            $('#emailError').html('').removeClass('invalid-input');
          }

          if (response['password'] != "") {
            $('#passwordError').html(response['password']).addClass('invalid-input');
          } else {
            $('#passwordError').html('').removeClass('invalid-input');
          }

          if (response['repassword'] != "") {
            $('#repasswordError').html(response['repassword']).addClass('invalid-input');
          } else {
            $('#repasswordError').html('').removeClass('invalid-input');
          }

    }else{
        $('.invalid-input').html('').removeClass('invalid-input');
          Swal.fire({
            icon: 'success',
            title: 'Vendor Added',
            text: 'The Vendor has been successfully added!',
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'OK'
          }).then((result) => {
            if (result.isConfirmed) {
              window.location = "<?php echo base_url('/'); ?>";
            }
          });
    }  
    }
    })
    });

</script>

<!-- Bootstrap 4 -->
<script src="<?=base_url('plugins/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?= base_url('dist/js/adminlte.min.js') ?>"></script>
</body>
</html>
