<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>
<style>
#example1 th,
#example1 td {
    padding: 5px 8px;
    font-size: 13px;
    vertical-align: middle;
}

#example1 th {
    white-space: nowrap;
}
</style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Sale By Customer Report With GST</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Sr.No</th>
                    <th>Date</th>
                    <th>Invoice Number</th>
                    <th>Customer Name</th>
                    <th>Order Id</th>
                    <th>SGST %</th>
                    <th>SGST Amount</th>
                    <th>CGST %</th>
                    <th>CGST Amount</th>
                    <th>IGST %</th>
                    <th>IGST Amount</th>
                    <th>Total Amount</th>
                    <th>Paid Amount</th>
                    <th>Remaining Amount</th>

                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $cnt=1;
                    foreach($bill as $data){
                    ?>
                  <tr>
                    <td><?= $cnt++; ?></td>
                    <td><?= $data['invoice_date'] ?></td>
                    <td><?= $data['invoice_no'] ?></td>
                    <td><?= $data['customer_id'] ?></td>
                    <td><?= $data['order_id'] ?></td>
                    <td><?= $data['sgst'] ?></td>
                    <td><?= $data['sgst_amount'] ?></td>
                    <td><?= $data['cgst'] ?></td>
                    <td><?= $data['cgst_amount'] ?></td>
                    <td><?= $data['igst'] ?></td>
                    <td><?= $data['igst_amount'] ?></td>
                    <td><?= $data['product_amount'] ?></td>
                    <td><?= $data['paid_amount'] ?></td>
                    <td><?= $data['remaining_amount'] ?></td>
                  </tr>
                  <?php  } ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>

    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">
  
</script>
<?= $this->include('Admin/common_function/footer') ?>