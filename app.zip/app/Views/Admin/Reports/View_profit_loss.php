<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>
<style>
#example1 th,
#example1 td {
    padding: 5px 8px;
    font-size: 13px;
    vertical-align: middle;
}

#example1 th {
    white-space: nowrap;
}
</style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->


    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Income</h3>
              </div>
              
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Sr.no</th>
                    <th>Account Name</th>
                    <th>Amount</th>
                  </tr>
                  </thead>
                  <tbody>
                 <?php
                 $cnt=1;
                 foreach($amount as $data){
                  $credit += (float)$data['balance'];
                 ?>
                  <tr>
                    <td><?= $cnt++; ?></td>
                    <td><?= $data['account_name']; ?></td>
                    <td><?= $data['balance']; ?></td>
                  </tr>
                 <?php } ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
          </div>

          <div class="col-md-6">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Expense</h3>
              </div>
              
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Sr.no</th>
                    <th>Account Name</th>
                    <th>Amount</th>
                  </tr>
                  </thead>
                  <tbody>
                 <?php
                 $cnt=1;
                 foreach($expense as $row){
                  $expense11 += (float)$row['balance'];
                 ?>
                  <tr>
                    <td><?= $cnt++; ?></td>
                    <td><?= $row['account_name']; ?></td>
                    <td><?= $row['balance']; ?></td>
                  </tr>
                 <?php } ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>



    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Profit And Loss Reports</h3>
              </div>
              
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Credit</th>
                    <th>Debit</th>
                    <th>From Date</th>
                    <th>To Date</th>
                  </tr>
                  </thead>
                  <tbody>
                
                  <tr>
                    <td><?= number_format($credit, 2); ?></td>
                    <td><?= number_format($expense11, 2); ?></td>
                    <td></td>
                    <td></td>
                  </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">
  
</script>
<?= $this->include('Admin/common_function/footer') ?>