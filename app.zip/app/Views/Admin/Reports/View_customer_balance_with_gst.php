<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>
<style>
#example1 th,
#example1 td {
    padding: 5px 8px;
    font-size: 13px;
    vertical-align: middle;
}

#example1 th {
    white-space: nowrap;
}
</style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">View Customer Balance With GST</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Sr.No</th>
                    <th>Date</th>
                    <th>Customer Name</th>
                    <th>Order Id</th>
                    <th>Total Amount</th>
                    <th>Paid Amount</th>
                    <th>Remaining Amount</th>

                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $cnt=1;
                    foreach($billing as $data){
                        $total_amount += $data['product_amount'];
                        $paid_amount += $data['paid_amount'];
                        $remaining_amount += $data['remaining_amount'];
                    ?>
                  <tr>
                    <td><?= $cnt++; ?></td>
                    <td><?= $data['invoice_date'] ?></td>
                    <td><?= $data['customer_name'] ?></td>
                    <td><?= $data['order_id'] ?></td>
                    <td><?= $data['product_amount'] ?></td>
                    <td><?= $data['paid_amount'] ?></td>
                    <td><?= $data['remaining_amount'] ?></td>
                  </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Profit And Loss Report</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Total Amount</th>
                    <th>Paid Amount</th>
                    <th>Remaining Amount</th>
                    <th>From Date</th>
                    <th>To Date</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td><?= $total_amount; ?></td>
                    <td><?= $paid_amount; ?></td>
                    <td><?= $remaining_amount; ?></td>
                    <td><?= $from_date; ?></td>
                    <td><?= $to_date; ?></td>
                  </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">
  
</script>
<?= $this->include('Admin/common_function/footer') ?>