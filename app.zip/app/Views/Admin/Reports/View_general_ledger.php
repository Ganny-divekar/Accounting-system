<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>
<style>
#example1 th,
#example1 td {
    padding: 5px 8px;
    font-size: 13px;
    vertical-align: middle;
}

#example1 th {
    white-space: nowrap;
}
</style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">General Ledger Report</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Sr.No</th>
                    <th>Account Name</th>
                    <th>Credit</th>
                    <th>Debit</th>
                    <th>Balance</th>
                    <th>Action</th>

                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $cnt=1;
                    foreach($amount as $data){
                    ?>
                  <tr>
                    <td><?= $cnt++; ?></td>
                    <td><?= $data['account_name'] ?></td>
                    <td><?= $data['credit1'] ?></td>
                    <td><?= $data['debit1'] ?></td>
                    <td><?= $data['balance'] ?></td>
                    <td>
                        <a class="btn btn-secondary btn-sm" href="<?= base_url('view_general_ledger_single/'.$data['acc_id'] .'/'.$data['from_date'].'/'.$data['to_date']); ?>"  href="javascript:void(0);">
                            <i class="fas fa-image"></i>
                        </a>  
                    </td>
                  </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">
  function view_general_ledger(id,from_date,to_date) {
    window.location = "<?php echo base_url('view_general_ledger_single/'); ?>" +id+"/"+from_date+"/"+to_date;
  }
</script>
<?= $this->include('Admin/common_function/footer') ?>