<?= $this->include('Admin/common_function/header') ?>
<?= $this->include('Admin/common_function/menu') ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->


    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Reports</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <div class="row">
                  <div class="col-sm-4">
                    <div class="position-relative p-3 bg-gray" style="height: 180px">
                      <div class="ribbon-wrapper">
                        <div class="ribbon bg-primary">
                          Reports
                        </div>
                      </div>
                      <b>BUSINESS OVERVIEW</b> <br />
                      <a type="button" href="<?php echo base_url('profit_loss_datewise'); ?>" class="btn btn-block btn-sm btn-info">Prfit And Loss</a>
                      <a type="button" href="<?php echo base_url('trail_sheet_datewise'); ?>" class="btn btn-block btn-sm btn-info">Trail Sheet</a>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="position-relative p-3 bg-gray" style="height: 180px">
                      <div class="ribbon-wrapper ribbon-lg">
                        <div class="ribbon bg-primary">
                          Reports
                        </div>
                      </div>
                      <b>SALES</b> <br />
                      <a type="button" href="<?php echo base_url('sale_by_customer_datewise'); ?>" class="btn btn-block btn-sm btn-info">Sales By Customer GST</a>
                      <a type="button" href="<?php echo base_url('sale_by_item_datewise'); ?>" class="btn btn-block btn-sm btn-info">Sales By Item GST</a>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="position-relative p-3 bg-gray" style="height: 180px">
                      <div class="ribbon-wrapper ribbon-xl">
                        <div class="ribbon bg-primary">
                          Reports
                        </div>
                      </div>
                      <b>RECEIVABLES</b> <br />
                      <a type="button" href="<?php echo base_url('customer_balance_with_gst_datewise'); ?>" class="btn btn-block btn-sm btn-info">Customer Balance With GST</a>
                    </div>
                    </div>
                  </div>
               
                <div class="row mt-4">
                  <div class="col-sm-4">
                    <div class="position-relative p-3 bg-gray" style="height: 180px">
                      <div class="ribbon-wrapper ribbon-lg">
                        <div class="ribbon bg-primary">
                          Reports
                        </div>
                      </div>
                      <b>PURCHASE/EXPENSES</b> <br />
                      <a type="button" href="<?php echo base_url('purchase_report_datewise'); ?>" class="btn btn-block btn-sm btn-info">Purchase Report</a>
                      <a type="button" href="<?php echo base_url('vendor_wise_purchase_report_datewise'); ?>" class="btn btn-block btn-sm btn-info">Vendor Wise Purchase Report</a>

                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="position-relative p-3 bg-gray" style="height: 180px">
                      <div class="ribbon-wrapper ribbon-xl">
                        <div class="ribbon bg-primary">
                          Reports
                        </div>
                      </div>
                      <b>ACCOUNTANT</b> <br />
                      <a type="button" href="<?php echo base_url('general_ledger_datewise'); ?>" class="btn btn-block btn-sm btn-info">General Ledger</a>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">


</script>
<?= $this->include('Admin/common_function/footer') ?>