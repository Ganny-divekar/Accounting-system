<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>
<style>
#example1 th,
#example1 td {
    padding: 5px 8px;
    font-size: 13px;
    vertical-align: middle;
}

#example1 th {
    white-space: nowrap;
}
</style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Trail Sheet Reports</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Sr.No</th>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Debit(RS.)</th>
                    <th>Credit(RS.)</th>
                    <th>Transaction Type</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $cnt=1;
                    foreach($trail as $data){
                        $credit += $data['credit'];
                        $debit += $data['debit'];

                    ?>
                  <tr>
                    <td><?= $cnt++; ?></td>
                    <td><?= $data['date'] ?></td>
                    <td><?= $data['description'] ?></td>
                    <td><?= $data['debit'] ?></td>
                    <td><?= $data['credit'] ?></td>
                    <td><?= $data['trasaction_type'] ?></td>
                  </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Profit And Loss Report</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Credit</th>
                    <th>Debit</th>
                    <th>From Date</th>
                    <th>To Date</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td><?= $credit; ?></td>
                    <td><?= $debit; ?></td>
                    <td></td>
                    <td></td>
                  </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">
  
</script>
<?= $this->include('Admin/common_function/footer') ?>