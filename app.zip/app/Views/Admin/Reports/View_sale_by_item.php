<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>
<style>
#example1 th,
#example1 td {
    padding: 5px 8px;
    font-size: 13px;
    vertical-align: middle;
}

#example1 th {
    white-space: nowrap;
}
</style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Sale By Items Report With GST</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Sr.No</th>
                    <th>Date</th>
                    <th>Invoice Number</th>
                    <th>Order Id</th>
                    <th>Product Name</th>
                    <th>Rate</th>
                    <th>Quantity</th>
                    <th>Basic Price</th>
                    <th>GST</th>
                    <th>Total Amount</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $cnt=1;
                    foreach($order as $data){
                      $prd_rate = $data['product_rate']; 
                      $prd_qty = $data['product_quantity'];
                      $total =  $prd_rate*$prd_qty;

                      $sgst = $data['sgst']; 
                      $cgst = $data['cgst']; 
                      $gst = $sgst+$cgst;

                    ?>
                    
                  <tr>
                    <td><?= $cnt++; ?></td>
                    <td><?= $data['invoice_date'] ?></td>
                    <td><?= $data['invoice_no'] ?></td>
                    <td><?= $data['order_id'] ?></td>
                    <td><?= $data['product_name'] ?></td>
                    <td><?= $data['product_rate'] ?></td>
                    <td><?= $data['product_quantity'] ?></td>
                    <td><?= $total; ?></td>
                    <td><?= $gst; ?></td>
                    <td><?= $data['product_amount'] ?></td>
                  </tr>
                  <?php 
                    }
                  ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>

    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">
  
</script>
<?= $this->include('Admin/common_function/footer') ?>