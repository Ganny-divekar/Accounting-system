<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>
<style>
#example1 th,
#example1 td {
    padding: 5px 8px;
    font-size: 13px;
    vertical-align: middle;
}

#example1 th {
    white-space: nowrap;
}
</style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->


    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
    <h3 class="card-title">View GST Quotation</h3>

    </div>
              
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Sr.no</th>
                    <th>Quotation Date</th>
                    <th>Customer Name</th>
                    <th>Quotation Number</th>
                    <th>Order Id</th>
                    <th>Total Amount</th>
                    <th>Delete</th>
                    <th>Edit</th>
                    <th>Print</th>
                  </tr>
                  </thead>
                  <tbody>
                 <?php 
                    $cnt=1;
                    foreach($customer_quotation as $data){
                 ?>
                  <tr>
                    <td><?= $cnt++; ?></td>
                    <td><?= $data['quotation_date']; ?></td>
                    <td><?= $data['customer_name']; ?></td>
                    <td><?= $data['quotation_no']; ?></td>
                    <td><?= $data['order_id']; ?></td>
                    <td><?= $data['product_amount']; ?></td>
                    <td>
                        <button type="button" class="btn btn-danger btn-sm">Delete</button>
                    </td>
                    <td>
                        <button type="button" class="btn btn-success btn-sm">Edit</button>
                    </td>
                    <td>
                        <button type="button" onclick="quotation_bill_pdf(<?= $data['order_id']; ?>)" class="btn btn-warning btn-sm">Print</button>
                    </td>
                  </tr>
                  <?php 
                  }
                   ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">

 function quotation_bill_pdf(id) {
    window.location = "<?php echo base_url('quotation_bill_pdf/'); ?>" + id;
  }

 
  

  function deleted(id) {
    $.ajax({
      url: '<?php echo base_url('delete_customer/'); ?>' + id,
      type: 'POST',
      dataType: 'json',
      success: function (response) {
        if (response['status'] == 1) {
          Swal.fire({
            icon: 'success',
            title: 'Product Deleted',
            text: 'The Customer has been successfully Deleted...!',
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'OK'
          }).then((result) => {
            if (result.isConfirmed) {
              window.location = "<?php echo base_url('view_product'); ?>";
            }
          });
        }
      }
    });
  }
  
</script>
<?= $this->include('Admin/common_function/footer') ?>