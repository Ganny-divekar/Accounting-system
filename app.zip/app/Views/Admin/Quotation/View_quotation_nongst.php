<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Quotation Non GST</h3>
                        </div>
                        <!-- form start -->
                        <form action="" method="post" enctype="multipart/form-data" id="add_data">
                            <input type="hidden" name="customer_id" value="<?= $customer['id']; ?>">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Quotation Number</label>
                                            <input type="text" name="quotation_number" value="<?= $quotation_no; ?>" class="form-control form-control-sm" placeholder="Enter Quotation No" readonly>
                                            <p id="quotation_numberError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Quotation Date</label>
                                            <input type="date" name="quotation_date" class="form-control form-control-sm" placeholder="Enter Quotation Date">
                                            <p id="quotation_dateError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Customer Name</label>
                                            <input type="text" name="customer_name" value="<?= $customer['customer_name']; ?>" class="form-control form-control-sm" placeholder="Enter Customer Number" readonly>
                                            <p id="invoice_numberError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                </div>
                               
                                <hr>


    

    <div class="card-body">

        <div id="product_area">

            <div class="row product_row">

                <div class="col-md-3">
                    <div class="form-group">
                        <label>
                            <input type="checkbox" name="product_name[]" class="row_check">
                            Product Name
                        </label>

                        <select class="form-control" name="product[]">
                            <option>Select Product</option>
                            <?php foreach($product as $p){ ?>
                            <option value="<?= $p['id']; ?>"><?= $p['product_name']; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                        <label>Quantity (Kg/Pack/Nos/Case)</label>
                        <input type="text" class="form-control" name="qty[]">
                    </div>
                </div>

                <div class="col-md-2">
                    <div class="form-group">
                        <label>Discount (%)</label>
                        <input type="number" class="form-control" name="discount[]" value="0">
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group">
                        <label>Customize Rate (Without GST)</label>
                        <input type="text" class="form-control" name="rate[]">
                    </div>
                </div>

            </div>

        </div>

        <button type="button" class="btn btn-warning btn-sm mt-2" id="add_more">
            <i class="fas fa-plus"></i> Add More
        </button>

        <button type="button" class="btn btn-danger btn-sm mt-2" id="delete_row">
            <i class="fas fa-trash"></i> Delete
        </button>

    </div>

                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer p-2">
                                <button type="submit" class="btn btn-success btn-sm">
                                    <i class="fas fa-save"></i> Submit
                                </button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col-md-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>

<script src="<?= base_url('plugins/jquery/jquery.min.js') ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">

$('body').on('submit', '#add_data', function (e) {
    e.preventDefault();
    

    let formData = new FormData(this);

    $.ajax({
      url: '<?php echo base_url('save_customer_quotation_nongst'); ?>',
      type: 'POST',
      data: formData,
      dataType: 'json',
      contentType: false,
      processData: false,
      success: function (response) {
      if (response['status'] == 0) {
        if (response['quotation_number'] != "") {
            $('#quotation_numberError').html(response['quotation_number']).addClass('invalid-input');
          } else {
            $('#quotation_numberError').html('').removeClass('invalid-input');
          }

          if (response['quotation_date'] != "") {
            $('#quotation_dateError').html(response['quotation_date']).addClass('invalid-input');
          } else {
            $('#quotation_dateError').html('').removeClass('invalid-input');
          }

          if (response['customer_name'] != "") {
            $('#customer_nameError').html(response['customer_name']).addClass('invalid-input');
          } else {
            $('#customer_nameError').html('').removeClass('invalid-input');
          }


    }else{
        $('.invalid-input').html('').removeClass('invalid-input');
        alert("Quotation Order Added");
        window.location = "<?php echo base_url('customer_quotation_nongst_bill/'); ?>"+response.order_id;
          
    }
    }
    })
    });






    
    $('#add_more').click(function () {

    var row = $('.product_row:first').clone();

    row.find('input[type=text]').val('');
    row.find('input[type=number]').val(0);
    row.find('input[type=checkbox]').prop('checked', false);
    row.find('select').prop('selectedIndex', 0);

    $('#product_area').append(row);

});

$('#delete_row').click(function () {

    if ($('.product_row').length > 1) {
        $('.product_row:last').remove();
    }

});

</script>
<?= $this->include('Admin/common_function/footer') ?>