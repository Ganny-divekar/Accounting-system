<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Quotation Bill</h3>
                        </div>
                        <!-- form start -->
                        <form action="" method="post" enctype="multipart/form-data" id="add_data">
                            <input type="hidden" name="customer_id" value="<?= $quotation[0]['customer_id']; ?>">
                            <input type="hidden" name="order_id" value="<?= $quotation[0]['order_id']; ?>">
                            <input type="hidden" name="product_rate" value="<?= $quotation[0]['product_rate']; ?>">
                            <input type="hidden" name="product_quantity" value="<?= $quotation[0]['product_quantity']; ?>"> 
                            <input type="hidden" name="unit" value="<?= $quotation[0]['unit']; ?>">
                            
                            <input type="hidden" name="quotation_date" value="<?= $quotation[0]['quotation_date']; ?>">    
                            <input type="hidden" name="quotation_month" value="<?= $quotation[0]['quotation_month']; ?>">   
                            <input type="hidden" name="quotation_year" value="<?= $quotation[0]['quotation_year']; ?>">   
                            <input type="hidden" name="hsn_code" value="<?= $quotation[0]['hsn_code']; ?>">   
                            <input type="hidden" name="discount" value="<?= $quotation[0]['discount']; ?>">   
                            
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-5">
                                        <div class="form-group mb-2">
                                            <label>Quotation Number</label>
                                            <input type="text" name="quotation_no" value="<?= $quotation[0]['quotation_no']; ?>" class="form-control form-control-sm" placeholder="Enter Invoice Number" readonly>
                                            <p id="quotation_noError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <?php
                                    $total_amount = array_sum(array_column($quotation, 'product_amount'));
                                    ?>
                                    <div class="col-md-5">
                                        <div class="form-group mb-2">
                                            <label>Total Amount</label>
                                            <input type="text" name="product_amount" value="<?= $total_amount; ?>" class="form-control form-control-sm" placeholder="Total amount" readonly>
                                            <p id="product_amountError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer p-2">
                                <button type="submit" class="btn btn-success btn-sm">
                                    <i class="fas fa-save"></i> Submit
                                </button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col-md-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>

<script src="<?= base_url('plugins/jquery/jquery.min.js') ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">

$('body').on('submit', '#add_data', function (e) {
    e.preventDefault();
    
    let formData = new FormData(this);

    $.ajax({
      url: '<?php echo base_url('save_quotation_bill_nongst'); ?>',
      type: 'POST',
      data: formData,
      dataType: 'json',
      contentType: false,
      processData: false,
      success: function (response) {
      if (response['status'] == 0) {
        if (response['quotation_no'] != "") {
            $('#quotation_noError').html(response['quotation_no']).addClass('invalid-input');
          } else {
            $('#quotation_noError').html('').removeClass('invalid-input');
          }

          if (response['product_amount'] != "") {
            $('#product_amountError').html(response['product_amount']).addClass('invalid-input');
          } else {
            $('#product_amountError').html('').removeClass('invalid-input');
          }


    }else{
        $('.invalid-input').html('').removeClass('invalid-input');
            alert("Quotation Bill Added");
            window.location = "<?php echo base_url('quotation_nongst_bill_pdf/'); ?>"+response.order_id;
            
    }  
    }
    })
    });

</script>
<?= $this->include('Admin/common_function/footer') ?>