
<?= $this->include('Admin/common_function/header') ?>
<?= $this->include('Admin/common_function/menu') ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h6 class="m-0">Dashboard</h6>
          </div><!-- /.col -->
           
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <?php 
                if($total_customer>0){
                ?>
                <h3><?= $total_customer; ?></h3>
                <?php }else{ ?>
                <h3>0</h3>
                <?php } ?>
                <p>Total Customers</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="<?php echo base_url('view_customer'); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <?php 
                if($total_vendor>0){
                ?>
                <h3><?= $total_vendor; ?></h3>
                <?php }else{ ?>
                <h3>0</h3>
                <?php } ?>

                <p>Total Vendors</p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
              <a href="<?php echo base_url('view_vendor'); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <?php 
                if($pending>0){
                ?>
                <h3><?= number_format($pending); ?></h3>
                <?php }else{ ?>
                <h3>0</h3>
                <?php } ?>
                <p>Pending Amount With GST</p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
              <a href="<?php echo base_url('view_vendor'); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-secondary">
              <div class="inner">
                <?php 
                if($pending_non>0){
                ?>
                <h3><?= number_format($pending_non); ?></h3>
                <?php }else{ ?>
                <h3>0</h3>
                <?php } ?>
                

                <p>Pending Amount Without GST</p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
              <a href="<?php echo base_url('view_vendor'); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <?php 
                if($total_amount>0){
                ?>
                <h3><?= $total_amount; ?></h3>
                <?php }else{ ?>
                <h3>0</h3>
                <?php } ?>
                <p>Today Sale With GST</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-primary">
              <div class="inner">
                <?php
                if($total_amount11>0){
                ?>  
                <h3><?= $total_amount11; ?></h3>
                <?php }else{ ?>
                <h3>0</h3>
                <?php } ?>
                <p>Today Sale Without GST</p>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
           <!-- ./col -->
            <?php
                foreach($today_income as $income_today){
                  $credit += $income_today['credit'];
                  $debit += $income_today['debit'];
                  $today_income_balance = $credit-$debit;
                }
                ?>  
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <?php
                if($today_income_balance>0){
                ?>
                <h3><?= $today_income_balance; ?></h3>
                <?php }else{ ?>
                <h3>0</h3>
                <?php } ?>  
                
                <p>Todays Income</p>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
           <?php
                foreach($today_income11 as $income_today11){
                  $credit11 += $income_today11['credit'];
                  $debit11 += $income_today11['debit'];
                  $today_income_balance11 = $credit11-$debit11;
                }
                ?>  
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <?php
                if($today_income_balance11>0){
                ?>
                <h3><?= $today_income_balance11; ?></h3>
                <?php }else{ ?>
                <h3>0</h3>
                <?php } ?>  
                <p>OverAll Income</p>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?= $this->include('Admin/common_function/footer') ?>