<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Add Product</h3>
                        </div>
                        <!-- form start -->
                        <form action="" method="post" enctype="multipart/form-data" id="add_data">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Product Name</label>
                                            <input type="text" name="product_name" class="form-control form-control-sm" placeholder="Enter Product Name">
                                            <p id="product_nameError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Product Code</label>
                                            <input type="text" name="product_code" class="form-control form-control-sm" placeholder="Product Code">
                                            <p id="product_codeError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Hsn Code</label>
                                            <input type="text" name="hsn_code" class="form-control form-control-sm" placeholder="Enter HSN Code">
                                            <p id="hsn_codeError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Unit</label>
                                            <input type="text" name="unit" class="form-control form-control-sm" placeholder="Unit">
                                            <p id="unitError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Gst Percentage</label>
                                            <input type="text" name="gst_percentage" class="form-control form-control-sm" placeholder="Enter GST Percentage">
                                            <p id="gst_percentageError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Purchase Price</label>
                                            <input type="text" name="purchase_price" class="form-control form-control-sm" placeholder="Enter Purchase Price">
                                            <p id="Purchase_priceError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>selling_price</label>
                                            <input type="text" name="selling_price" class="form-control form-control-sm" placeholder="Selling Price">
                                            <p id="selling_priceError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Opening Stock</label>
                                            <input type="text" name="opening_stock" class="form-control form-control-sm" placeholder="Enter Opening Stock">
                                            <p id="opening_stockError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Reminder Stock</label>
                                            <input type="text" name="reminder_stock" class="form-control form-control-sm" placeholder="Enter Reminder Stock">
                                            <p id="reminder_stockError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Description</label>
                                            <input type="text" name="description" class="form-control form-control-sm" placeholder="Enter Description">
                                            <p id="descriptionError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Created Date</label>
                                            <input type="date" name="created_date" class="form-control form-control-sm" placeholder="Enter Created Date">
                                            <p id="created_dateError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer p-2">
                                <button type="submit" class="btn btn-success btn-sm">
                                    <i class="fas fa-save"></i> Submit
                                </button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col-md-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>

<script src="<?= base_url('plugins/jquery/jquery.min.js') ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">

    $('body').on('submit', '#add_data', function (e) {
    e.preventDefault();
    

    let formData = new FormData(this);

    $.ajax({
      url: '<?php echo base_url('save_product'); ?>',
      type: 'POST',
      data: formData,
      dataType: 'json',
      contentType: false,
      processData: false,
      success: function (response) {
      if (response['status'] == 0) {
        if (response['product_name'] != "") {
            $('#product_nameError').html(response['product_name']).addClass('invalid-input');
          } else {
            $('#product_nameError').html('').removeClass('invalid-input');
          }

          if (response['product_code'] != "") {
            $('#product_codeError').html(response['product_code']).addClass('invalid-input');
          } else {
            $('#product_codeError').html('').removeClass('invalid-input');
          }

          if (response['hsn_code'] != "") {
            $('#hsn_codeError').html(response['hsn_code']).addClass('invalid-input');
          } else {
            $('#hsn_codeError').html('').removeClass('invalid-input');
          }

          if (response['unit'] != "") {
            $('#unitError').html(response['unit']).addClass('invalid-input');
          } else {
            $('#unitError').html('').removeClass('invalid-input');
          }

          if (response['gst_percentage'] != "") {
            $('#gst_percentageError').html(response['gst_percentage']).addClass('invalid-input');
          } else {
            $('#gst_percentageError').html('').removeClass('invalid-input');
          }

          if (response['purchase_price'] != "") {
            $('#purchase_priceError').html(response['purchase_price']).addClass('invalid-input');
          } else {
            $('#purchase_priceError').html('').removeClass('invalid-input');
          }

          if (response['selling_price'] != "") {
            $('#selling_priceError').html(response['selling_price']).addClass('invalid-input');
          } else {
            $('#selling_priceError').html('').removeClass('invalid-input');
          }

          if (response['opening_stock'] != "") {
            $('#opening_stockError').html(response['opening_stock']).addClass('invalid-input');
          } else {
            $('#opening_stockError').html('').removeClass('invalid-input');
          }

          if (response['reminder_stock'] != "") {
            $('#reminder_stockError').html(response['reminder_stock']).addClass('invalid-input');
          } else {
            $('#reminder_stockError').html('').removeClass('invalid-input');
          }

          if (response['description'] != "") {
            $('#descriptionError').html(response['description']).addClass('invalid-input');
          } else {
            $('#descriptionError').html('').removeClass('invalid-input');
          }

          if (response['created_date'] != "") {
            $('#created_dateError').html(response['created_date']).addClass('invalid-input');
          } else {
            $('#created_dateError').html('').removeClass('invalid-input');
          }
    }else{
        $('.invalid-input').html('').removeClass('invalid-input');
          alert("Product Added Successfully...!");
              window.location = "<?php echo base_url('view_product'); ?>";
           
    }  
    }
    })
    });

</script>

<?= $this->include('Admin/common_function/footer') ?>