<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>
<style>
#example1 th,
#example1 td {
    padding: 5px 8px;
    font-size: 13px;
    vertical-align: middle;
}

#example1 th {
    white-space: nowrap;
}
</style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->


    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
    <h3 class="card-title">View Products</h3>
    <a href="<?= base_url('add_product') ?>" type="button" class="btn btn-primary btn-xs float-right">
        <i class="fas fa-plus"></i> Add Product
</a>

    </div>
              
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Action</th>
                    <th>Sr.no</th>
                    <th>Product Name</th>
                    <th>Barcode</th>
                    <th>unit</th>
                    <th>Gst Percentage</th>
                    <th>Purchase Price</th>
                    <th>Selling price</th>
                    <th>Opening Stock</th>
                    <th>Reminder Stock</th>
                    <th>Created Date</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php
                  $cnt=1;
                  foreach($product as $data){
                  ?>
                  <tr>
                    <td>
                      <div class="btn-group">
                        <button type="button" class="btn btn-primary btn-sm">Action</button>

                        <div class="btn-group">
                          <button type="button" class="btn btn-primary btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
                          </button>
                          <div class="dropdown-menu">
                            <a class="dropdown-item" onclick="edit(<?= $data['id']; ?>);" href="javascript:void(0);">Edit</a>
                            <a class="dropdown-item" onclick="deleted(<?= $data['id']; ?>);" href="javascript:void(0);">Delete</a>

                          </div>
                        </div>
                      </div>
                    </td>
                    <td><?= $cnt++ ?></td>
                    <td><?= $data['product_name']; ?></td>
                    <td><?= $data['barcode']; ?></td>
                    <td><?= $data['unit']; ?></td>
                    <td><?= $data['gst_percentage']; ?></td>
                    <td><?= $data['purchase_price']; ?></td>
                    <td><?= $data['selling_price']; ?></td>
                    <td><?= $data['opening_stock']; ?></td>
                    <td><?= $data['reminder_stock']; ?></td>
                    <td><?= $data['created_date']; ?></td>
                  </tr>
                 <?php } ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">

 function edit(id) {
    window.location = "<?php echo base_url('edit_product/'); ?>" + id;
  }

  function deleted(id) {
    $.ajax({
      url: '<?php echo base_url('delete_product/'); ?>' + id,
      type: 'POST',
      dataType: 'json',
      success: function (response) {
        if (response['status'] == 1) {
          Swal.fire({
            icon: 'success',
            title: 'Product Deleted',
            text: 'The Product has been successfully Deleted...!',
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'OK'
          }).then((result) => {
            if (result.isConfirmed) {
              window.location = "<?php echo base_url('view_product'); ?>";
            }
          });
        }
      }
    });
  }
  
</script>
<?= $this->include('Admin/common_function/footer') ?>