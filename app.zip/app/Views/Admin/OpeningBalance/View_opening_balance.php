<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Add Opening Balance</h3>
                        </div>
                        <!-- form start -->
                        <form action="" method="post" enctype="multipart/form-data" id="add_data">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Account Name</label>
                                            <select type="text" name="account_name" class="form-control form-control-sm" placeholder="Enter Account Name">
                                                <option value="">Select Account Name</option>
                                                <?php 
                                                foreach($account as $data){
                                                ?>
                                                <option value="<?= $data['id']; ?>"><?= $data['account_name']; ?></option>
                                                <?php 
                                                } 
                                                ?>
                                            </select>
                                            <p id="account_nameError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Amount</label>
                                            <input type="text" name="amount" class="form-control form-control-sm" placeholder="Enter Amount">
                                            <p id="account_nameError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Remark</label>
                                            <input type="text" name="remark" class="form-control form-control-sm" placeholder="Enter Remark">
                                            <p id="account_nameError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Payment Mode</label>
                                            <select type="text" name="payment_mode" class="form-control form-control-sm" placeholder="Enter Payment Mode">
                                                <option value="">Select Payment Mode</option>
                                                <option value="credit">Credit</option>
                                                <option value="expense">Expense</option>
                                            </select>
                                            <p id="account_nameError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer p-2">
                                <button type="submit" class="btn btn-success btn-sm">
                                    <i class="fas fa-save"></i> Submit
                                </button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col-md-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
    <h3 class="card-title">Opening Balance Details</h3>
    </div>
              
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Sr.no</th>
                    <th>Account Name</th>
                    <th>Amount</th>
                    <th>Date</th>
                    <th>Payment Mode</th>
                    <th>Delete</th>
                  </tr>
                  </thead>
                  <tbody>
                 <?php 
                 $cnt=1;
                 foreach($balance as $data){
                 ?>
                  <tr>
                    <td><?= $cnt++; ?></td>
                    <td><?= $data['account_name']; ?></td>
                    <td><?= $data['amount']; ?></td>
                    <td><?= $data['payment_date']; ?></td>
                    <td><?= $data['payment_mode']; ?></td>
                    <td>
                        <button class="btn btn-danger btn-sm" onclick="delete_opening_balance(<?= $data['id']; ?>);" href="javascript:void(0);">
                            <i class="fas fa-trash"></i>
                        </button>  
                    </td>
                  </tr>
                <?php 
                } 
                ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>

<script src="<?= base_url('plugins/jquery/jquery.min.js') ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">

    $('body').on('submit', '#add_data', function (e) {
    e.preventDefault();
    

    let formData = new FormData(this);

    $.ajax({
      url: '<?php echo base_url('save_opening_balance'); ?>',
      type: 'POST',
      data: formData,
      dataType: 'json',
      contentType: false,
      processData: false,
      success: function (response) {
      if (response['status'] == 0) {
        if (response['account_name'] != "") {
            $('#account_nameError').html(response['account_name']).addClass('invalid-input');
          } else {
            $('#account_nameError').html('').removeClass('invalid-input');
          }

          if (response['amount'] != "") {
            $('#amountError').html(response['amount']).addClass('invalid-input');
          } else {
            $('#amountError').html('').removeClass('invalid-input');
          }

          if (response['remark'] != "") {
            $('#remarkError').html(response['remark']).addClass('invalid-input');
          } else {
            $('#remarkError').html('').removeClass('invalid-input');
          }

          if (response['payment_mode'] != "") {
            $('#payment_modeError').html(response['payment_mode']).addClass('invalid-input');
          } else {
            $('#payment_modeError').html('').removeClass('invalid-input');
          }

    }else{
    $('.invalid-input').html('').removeClass('invalid-input');
    alert("Customer Added Successfully...!");
    window.location = "<?php echo base_url('opening_balance'); ?>";
         
    }  
    }
    })
    });

</script>
<?= $this->include('Admin/common_function/footer') ?>