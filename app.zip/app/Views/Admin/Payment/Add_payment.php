<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Add Payment</h3>
                        </div>
                        <!-- form start -->
                        <form action="" method="post" enctype="multipart/form-data" id="add_data">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Payment For</label>
                                            <select type="text" name="payment_for" class="form-control form-control-sm" placeholder="Enter Payment For">
                                                <option value="">Select Account Name</option>
                                                <?php 
                                                foreach($account as $data){
                                                ?>
                                                <option value="<?= $data['id']; ?>"><?= $data['account_name']; ?></option>
                                                <?php } ?>
                                            </select>
                                            <p id="payment_forError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Payment Through</label>
                                            <select type="text" name="payment_through" class="form-control form-control-sm" placeholder="Enter Payment Through">
                                                <option value="">Select Account Name</option>
                                                <?php 
                                                foreach($account as $data){
                                                ?>
                                                <option value="<?= $data['id']; ?>"><?= $data['account_name']; ?></option>
                                                <?php } ?>
                                            </select>
                                            <p id="payment_throughError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Amount</label>
                                            <input type="text" name="amount" class="form-control form-control-sm" placeholder="Enter Amount">
                                            <p id="amountError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Payment Mode</label>
                                            <input type="text" name="payment_mode" class="form-control form-control-sm" placeholder="Payment Mode">
                                            <p id="payment_modeError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Person Name</label>
                                            <input type="text" name="person_name" class="form-control form-control-sm" placeholder="Enter Person Name">
                                            <p id="person_nameError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Invoice Number</label>
                                            <input type="text" name="invoice_no" class="form-control form-control-sm" placeholder="Enter Invoice Number">
                                            <p id="invoice_noError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Remark</label>
                                            <input type="text" name="remark" class="form-control form-control-sm" placeholder="Enter Remark">
                                            <p id="remarkError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Payment Date</label>
                                            <input type="date" name="payment_date" class="form-control form-control-sm" placeholder="Enter Payment Date">
                                            <p id="payment_dateError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer p-2">
                                <button type="submit" class="btn btn-success btn-sm">
                                    <i class="fas fa-save"></i> Submit
                                </button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col-md-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
    <h3 class="card-title">Predefine Account Details</h3>
    </div>
              
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    
                    <th>Sr.no</th>
                    <th>Account Name</th>
                    <th>Balance</th>
                  </tr>
                  </thead>
                  <tbody>
                 <?php
                 $cnt=1;
                 foreach($amount as $data){  
                 ?>
                  <tr>
                    <td><?= $cnt++; ?></td>
                    <td><?= $data['account_name']; ?></td>
                    <td><?= $data['balance']; ?></td>
                  </tr>
                <?php } ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>

<script src="<?= base_url('plugins/jquery/jquery.min.js') ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">

    $('body').on('submit', '#add_data', function (e) {
    e.preventDefault();
    

    let formData = new FormData(this);

    $.ajax({
      url: '<?php echo base_url('save_expense'); ?>',
      type: 'POST',
      data: formData,
      dataType: 'json',
      contentType: false,
      processData: false,
      success: function (response) {
      if (response['status'] == 0) {
        if (response['payment_for'] != "") {
            $('#payment_forError').html(response['payment_for']).addClass('invalid-input');
          } else {
            $('#payment_forError').html('').removeClass('invalid-input');
          }

          if (response['payment_through'] != "") {
            $('#payment_throughError').html(response['payment_through']).addClass('invalid-input');
          } else {
            $('#payment_throughError').html('').removeClass('invalid-input');
          }

          if (response['amount'] != "") {
            $('#amountError').html(response['amount']).addClass('invalid-input');
          } else {
            $('#amountError').html('').removeClass('invalid-input');
          }

          if (response['payment_mode'] != "") {
            $('#payment_modeError').html(response['payment_mode']).addClass('invalid-input');
          } else {
            $('#payment_modeError').html('').removeClass('invalid-input');
          }

          if (response['person_name'] != "") {
            $('#person_nameError').html(response['person_name']).addClass('invalid-input');
          } else {
            $('#person_nameError').html('').removeClass('invalid-input');
          }

          if (response['invoice_no'] != "") {
            $('#invoice_noError').html(response['invoice_no']).addClass('invalid-input');
          } else {
            $('#invoice_noError').html('').removeClass('invalid-input');
          }

          if (response['remark'] != "") {
            $('#remarkError').html(response['remark']).addClass('invalid-input');
          } else {
            $('#remarkError').html('').removeClass('invalid-input');
          }

          if (response['payment_date'] != "") {
            $('#payment_dateError').html(response['payment_date']).addClass('invalid-input');
          } else {
            $('#payment_dateError').html('').removeClass('invalid-input');
          }

    }else{
    $('.invalid-input').html('').removeClass('invalid-input');
    alert("Payment Added Successfully...!");
    window.location = "<?php echo base_url('add_expense'); ?>";
         
    }  
    }
    })
    });

</script>
<?= $this->include('Admin/common_function/footer') ?>