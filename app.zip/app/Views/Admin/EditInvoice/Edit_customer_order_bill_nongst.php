<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Purchase Order Bill</h3>
                        </div>
                        <!-- form start -->
                        <form action="" method="post" enctype="multipart/form-data" id="add_data">
                            <input type="hidden" name="customer_id" value="<?= $sale[0]['customer_id']; ?>">
                            <input type="hidden" name="order_id" value="<?= $sale[0]['order_id']; ?>">
                            <input type="hidden" name="product_rate" value="<?= $sale[0]['product_rate']; ?>">
                            <input type="hidden" name="product_quantity" value="<?= $sale[0]['product_quantity']; ?>"> 
                            <input type="hidden" name="unit" value="<?= $sale[0]['unit']; ?>">
                            
                            <input type="hidden" name="invoice_date" value="<?= $sale[0]['invoice_date']; ?>">   
                            <input type="hidden" name="po_date" value="<?= $sale[0]['po_date']; ?>">   
                            <input type="hidden" name="invoice_month" value="<?= $sale[0]['invoice_month']; ?>">   
                            <input type="hidden" name="invoice_year" value="<?= $sale[0]['invoice_year']; ?>">   
                            <input type="hidden" name="hsn_code" value="<?= $sale[0]['hsn_code']; ?>">   
                            <input type="hidden" name="discount" value="<?= $sale[0]['discount']; ?>">   
                            
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-5">
                                        <div class="form-group mb-2">
                                            <label>Invoice Number</label>
                                            <input type="text" name="invoice_no" value="<?= $sale[0]['invoice_no']; ?>" class="form-control form-control-sm" placeholder="Enter Invoice Number" readonly>
                                            <p id="invoice_noError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <?php
                                    $total_amount = array_sum(array_column($sale, 'product_amount'));
                                    ?>
                                    <div class="col-md-5">
                                        <div class="form-group mb-2">
                                            <label>Total Amount</label>
                                            <input type="text" name="product_amount" value="<?= $total_amount; ?>" class="form-control form-control-sm" placeholder="Total amount" readonly>
                                            <p id="product_amountError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer p-2">
                                <button type="submit" class="btn btn-success btn-sm">
                                    <i class="fas fa-save"></i> Submit
                                </button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col-md-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>

<script src="<?= base_url('plugins/jquery/jquery.min.js') ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">

$('body').on('submit', '#add_data', function (e) {
    e.preventDefault();
    
    let formData = new FormData(this);

    $.ajax({
      url: '<?php echo base_url('save_edit_customer_bill_nongst'); ?>',
      type: 'POST',
      data: formData,
      dataType: 'json',
      contentType: false,
      processData: false,
      success: function (response) {
      if (response['status'] == 0) {
        if (response['invoice_no'] != "") {
            $('#invoice_noError').html(response['invoice_no']).addClass('invalid-input');
          } else {
            $('#invoice_noError').html('').removeClass('invalid-input');
          }

          if (response['product_amount'] != "") {
            $('#product_amountError').html(response['product_amount']).addClass('invalid-input');
          } else {
            $('#product_amountError').html('').removeClass('invalid-input');
          }  

    }else{
        $('.invalid-input').html('').removeClass('invalid-input');
            alert("Customer Bill Added");
            window.location = "<?php echo base_url('customer_bill_pdf1/'); ?>"+response.order_id;
            
    }  
    }
    })
    });

</script>
<?= $this->include('Admin/common_function/footer') ?>