<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>
<style>
#example1 th,
#example1 td {
    padding: 5px 8px;
    font-size: 13px;
    vertical-align: middle;
}

#example1 th {
    white-space: nowrap;
}
</style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->


    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
    <h3 class="card-title">View Customer Invoice GST</h3>
   

    </div>
              
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Sr.no</th>
                    <th>Invoice Date</th>
                    <th>Invoice No</th>
                    <th>Customer Name</th>
                    <th>Order Id</th>
                    <th>Total</th>
                    <th>Paid</th>
                    <th>Remaining</th>
                    <th>Edit Invoice</th>
                    <th>Delete Invoice</th>
                    <th>Print Invoice</th>



                  </tr>
                  </thead>
                  <tbody>
                <?php 
                $cnt=1;
                $totalAmount = 0;
                $paidAmount = 0;
                $remainingAmount = 0;

                foreach($customer_order as $data){

                $totalAmount += (float)$data['product_amount'];
                $paidAmount += (float)$data['paid_amount'];
                $remainingAmount += (float)$data['remaining_amount'];

                ?>
                  <tr>
                    <td><?= $cnt++; ?></td>
                    <td><?= $data['invoice_date'] ?></td>
                    <td><?= $data['invoice_no'] ?></td>
                    <td><?= $data['customer_name'] ?></td>
                    <td><?= $data['order_id'] ?></td>
                    <td><?= $data['product_amount'] ?></td>
                    <td><?= $data['paid_amount'] ?></td>
                    <td><?= $data['remaining_amount'] ?></td>
                    <td>
                         <a class="btn btn-primary btn-sm" onclick="edit_customer_invoice(<?= $data['order_id']; ?>);" href="javascript:void(0);">
                            <i class="fas fa-edit"></i>
                         </a>   
                    </td>
                    <td>
                        <button class="btn btn-danger btn-sm" onclick="delete_customer_invoice_bill(<?= $data['order_id']; ?>);" href="javascript:void(0);">
                            <i class="fas fa-trash"></i>
                        </button>  
                    </td>
                    <td>
                        <button class="btn btn-secondary btn-sm"onclick="customer_bill_pdf(<?= $data['order_id']; ?>);">
                            <i class="fas fa-print"></i>
                        </button>  
                    </td>
                  </tr>
                  <?php 
                  }
                  ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
    <h3 class="card-title">Other Details</h3>
   

    </div>
              
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Sr.no</th>
                    <th>Total Amount</th>
                    <th>Paid Amount</th>
                    <th>Remaining Amount</th>
                    <th>From Date</th>
                    <th>To Date</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                    $count=1;
                    ?>
                  <tr>
                    <td><?= $count++; ?></td>
                    <td><?= number_format($totalAmount, 2); ?></td>
                    <td><?= number_format($paidAmount, 2); ?></td>
                    <td><?= number_format($remainingAmount, 2); ?></td>
                    <td><?= $form_date; ?></td>
                    <td><?= $to_date; ?></td>
                  </tr>
                 
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">

 function edit_customer_invoice(id) {
    window.location = "<?php echo base_url('edit_customer_invoice/'); ?>" + id;
  }

  function customer_bill_pdf(id) {
    window.location = "<?php echo base_url('customer_bill_pdf/'); ?>" + id;
  }

  

  
 function delete_customer_invoice_bill(id) {
    $.ajax({
      url: '<?php echo base_url('delete_customer_invoice_bill/'); ?>' + id,
      type: 'POST',
      dataType: 'json',
      success: function (response) {
        if (response['status'] == 1) {
          
        alert("Customer Bill Deleted Successfully...!");
        window.location = "<?php echo base_url('view_invoice_gst_datewise'); ?>";  
        }
      }
    });
  }
 
  
</script>
<?= $this->include('Admin/common_function/footer') ?>