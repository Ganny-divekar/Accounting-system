<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Generate Purchase Order</h3>
                        </div>
                        <!-- form start -->
                        <form action="" method="post" enctype="multipart/form-data" id="add_data">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Purchase Order Number</label>
                                            <input type="text" name="purchase_order_no" value="<?= $purchase_order_no; ?>" class="form-control form-control-sm" placeholder="Enter Purchase Order No" readonly>
                                            <p id="purchase_order_noError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Vendor Name</label>
                                            <select type="text" name="vendor_name" class="form-control form-control-sm" placeholder="Vendor Name" readonly>
                                                <option value="">Select Vendor</option>
                                                <?php 
                                                foreach($vendor as $data){
                                                ?>
                                                <option value="<?php echo $data['id']; ?>"><?php echo $data['vendor_name']; ?></option>
                                                <?php } ?>
                                            </select>
                                            <p id="vendor_nameError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Work Order No</label>
                                            <input type="text" name="work_order_no" class="form-control form-control-sm" placeholder="Enter Work Order No">
                                            <p id="work_order_noError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>PO Date</label>
                                            <input type="date" name="po_date" class="form-control form-control-sm" placeholder="Enter PO Date">
                                            <p id="po_dateError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>GST Type</label>
                                            <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input" name="gst_type" type="checkbox" id="customCheckbox1" value="sgst_cgst" checked>
                                            <label for="customCheckbox1" class="custom-control-label">SGST-CGST</label>
                                        </div>
                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input" name="gst_type" type="checkbox" id="customCheckbox2" value="igst">
                                            <label for="customCheckbox2" class="custom-control-label">IGST</label>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                                <hr>



    <div class="card-body">
        <div id="product_area">
          <div class="row product_row">
            <div class="col-md-3">
                <div class="form-group">
                    <label>
                        <input type="checkbox" name="product_name[]" class="row_check">
                            Product Name
                        </label>

                        <select class="form-control" name="product[]">
                            <option>Select Product</option>
                            <?php foreach($product as $p){ ?>
                            <option value="<?= $p['id']; ?>"><?= $p['product_name']; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                        <label>Quantity (Kg/Pack/Nos/Case)</label>
                        <input type="text" class="form-control" name="qty[]">
                    </div>
                </div>

                <div class="col-md-2">
                    <div class="form-group">
                        <label>Discount (%)</label>
                        <input type="number" class="form-control" name="discount[]" value="0">
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group">
                        <label>Customize Rate (Without GST)</label>
                        <input type="text" class="form-control" name="rate[]">
                    </div>
                </div>
            </div>
        </div>
        <button type="button" class="btn btn-warning btn-sm mt-2" id="add_more">
            <i class="fas fa-plus"></i> Add More
        </button>

        <button type="button" class="btn btn-danger btn-sm mt-2" id="delete_row">
            <i class="fas fa-trash"></i> Delete
        </button>
    </div>
</div>
                            <!-- /.card-body -->
                            <div class="card-footer p-2">
                                <button type="submit" class="btn btn-success btn-sm">
                                    <i class="fas fa-save"></i> Submit
                                </button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col-md-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>

<script src="<?= base_url('plugins/jquery/jquery.min.js') ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">

$('body').on('submit', '#add_data', function (e) {
    e.preventDefault();
    

    let formData = new FormData(this);

    $.ajax({
      url: '<?php echo base_url('purchase_order_save'); ?>',
      type: 'POST',
      data: formData,
      dataType: 'json',
      contentType: false,
      processData: false,
      success: function (response) {
      if (response['status'] == 0) {
        if (response['purchase_order_no'] != "") {
            $('#purchase_order_noError').html(response['purchase_order_no']).addClass('invalid-input');
          } else {
            $('#purchase_order_noError').html('').removeClass('invalid-input');
          }

          if (response['vendor_name'] != "") {
            $('#vendor_nameError').html(response['vendor_name']).addClass('invalid-input');
          } else {
            $('#vendor_nameError').html('').removeClass('invalid-input');
          }

          if (response['work_order_no'] != "") {
            $('#work_order_noError').html(response['work_order_no']).addClass('invalid-input');
          } else {
            $('#work_order_noError').html('').removeClass('invalid-input');
          }

          if (response['po_date'] != "") {
            $('#po_dateError').html(response['po_date']).addClass('invalid-input');
          } else {
            $('#po_dateError').html('').removeClass('invalid-input');
          }

    }else{
        $('.invalid-input').html('').removeClass('invalid-input');
        alert("Purchase Order Generated");
        window.location = "<?php echo base_url('purchase_order_bill/'); ?>"+response.order_id;   
    }  
    }
    })
    });






    
    $('#add_more').click(function () {

    var row = $('.product_row:first').clone();

    row.find('input[type=text]').val('');
    row.find('input[type=number]').val(0);
    row.find('input[type=checkbox]').prop('checked', false);
    row.find('select').prop('selectedIndex', 0);

    $('#product_area').append(row);

});

$('#delete_row').click(function () {

    if ($('.product_row').length > 1) {
        $('.product_row:last').remove();
    }

});

</script>
<?= $this->include('Admin/common_function/footer') ?>