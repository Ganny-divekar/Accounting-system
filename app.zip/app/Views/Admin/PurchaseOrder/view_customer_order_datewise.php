<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>
<style>
#example1 th,
#example1 td {
    padding: 5px 8px;
    font-size: 13px;
    vertical-align: middle;
}

#example1 th {
    white-space: nowrap;
}
</style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->


    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
    <h3 class="card-title">View Customer Bill</h3>

    </div>
              
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Action</th>
                    <th>Sr.no</th>
                    <th>Invoice Date</th>
                    <th>Customer Name</th>
                    <th>Invoice Number</th>
                    <th>Order Id</th>
                    <th>Total AMount(Rs.)</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $cnt=1;
                    foreach($customer_order as $record){
                    ?>
                  <tr>
                    <td>
                      <div class="btn-group">
                        <button type="button" class="btn btn-primary btn-sm">Action</button>

                        <div class="btn-group">
                          <button type="button" class="btn btn-primary btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
                          </button>
                          <div class="dropdown-menu">
                            <a class="dropdown-item" onclick="customer_order_pdf(<?= $record['order_id']; ?>)" href="javascript:void(0);">Print</a>
                            <a class="dropdown-item" href="javascript:void(0);">Edit</a>
                            <a class="dropdown-item" href="javascript:void(0);">Delete</a>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td><?= $cnt++; ?></td>
                    <td><?= $record['invoice_date']; ?></td>
                    <td><?= $record['customer_name']; ?></td>
                    <td><?= $record['invoice_no']; ?></td>
                    <td><?= $record['order_id']; ?></td>
                    <td><?= $record['product_amount']; ?> </td>
                  </tr>
                  <?php 
                  }
                   ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <script src="<?= base_url('plugins/jquery/jquery.min.js') ?>"></script>
  <script type="text/javascript">

  function customer_order_pdf(id) {
    window.location = "<?php echo base_url('customer_bill_pdf/'); ?>" + id;
  }
  </script>

<?= $this->include('Admin/common_function/footer') ?>