<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">View Purchase Order Date Wise</h3>
                        </div>
                        <!-- form start -->
                        <form action="<?php echo base_url('view_purchase_datewise'); ?>" method="post" enctype="multipart/form-data" id="add_data">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>FROM DATE</label>
                                            <input type="date" name="from_date" class="form-control form-control-sm" placeholder="Enter Product Name"datetimepicker-input" data-target="#reservationdate">
                                            <p id="from_dateError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>TO DATE</label>
                                            <input type="date" name="to_date" class="form-control form-control-sm" placeholder="Product Code">
                                            <p id="to_dateError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer p-2">
                                <button type="submit" class="btn btn-success btn-sm">
                                    <i class="fas fa-save"></i> Submit
                                </button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col-md-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>

<?= $this->include('Admin/common_function/footer') ?>