<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>
<style>
#example1 th,
#example1 td {
    padding: 5px 8px;
    font-size: 13px;
    vertical-align: middle;
}

#example1 th {
    white-space: nowrap;
}
</style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->


    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
    <h3 class="card-title">View Customer</h3>
    <a href="<?= base_url('add_customer') ?>" type="button" class="btn btn-primary btn-xs float-right">
        <i class="fas fa-plus"></i> Add Customer
</a>

    </div>
              
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Action</th>
                    <th>Sr.no</th>
                    <th>Customer Name</th>
                    <th>Company Name</th>
                    <th>Mobile Number</th>
                    <th>Gst Number</th>
                    <th>Address</th>
                    <th>City</th>
                    <th>State</th>
                    <th>Pin Code</th>
                  </tr>
                  </thead>
                  <tbody>
                 <?php 
                 $cnt=1;
                 foreach($customer as $data){
                 ?>
                  <tr>
                    <td>
                      <div class="btn-group">
                        <button type="button" class="btn btn-primary btn-sm">Action</button>

                        <div class="btn-group">
                          <button type="button" class="btn btn-primary btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
                          </button>
                          <div class="dropdown-menu">
                            <a class="dropdown-item" onclick="customer_order(<?= $data['id']; ?>);" href="javascript:void(0);">With GST Bill</a>
                            <a class="dropdown-item" onclick="view_customer_bill(<?= $data['id']; ?>);" href="javascript:void(0);">Pay With GST</a>
                            <a class="dropdown-item" onclick="customer_order1(<?= $data['id']; ?>);" href="javascript:void(0);">Without GST Bill</a>
                            <a class="dropdown-item" onclick="view_customer_bill1(<?= $data['id']; ?>);" href="javascript:void(0);">Pay Without GST</a>
                            <a class="dropdown-item" onclick="customer_quotation(<?= $data['id']; ?>);" href="javascript:void(0);">Quotation With GST</a>
                            <a class="dropdown-item" onclick="customer_quotation_non_gst(<?= $data['id']; ?>);" href="javascript:void(0);">Quotation Non GST</a>
                            <a class="dropdown-item" onclick="edit(<?= $data['id']; ?>);" href="javascript:void(0);">Challan Entry</a>
                            <a class="dropdown-item" onclick="edit(<?= $data['id']; ?>);" href="javascript:void(0);">View Customer Folloup</a>
                            <a class="dropdown-item" onclick="edit(<?= $data['id']; ?>);" href="javascript:void(0);">Edit</a>
                            <a class="dropdown-item" onclick="deleted(<?= $data['id']; ?>);" href="javascript:void(0);">Delete</a>

                          </div>
                        </div>
                      </div>
                    </td>
                    <td><?= $cnt++; ?></td>
                    <td><?= $data['customer_name']; ?></td>
                    <td><?= $data['company_name']; ?></td>
                    <td><?= $data['mobile_no']; ?></td>
                    <td><?= $data['gst_no']; ?></td>
                    <td><?= $data['address']; ?></td>
                    <td><?= $data['city']; ?></td>
                    <td><?= $data['state']; ?></td>
                    <td><?= $data['pin_code']; ?></td>
                  </tr>
                <?php } ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">

 function customer_order(id) {
    window.location = "<?php echo base_url('customer_order/'); ?>" + id;
  }

  function view_customer_bill(id) {
    window.location = "<?php echo base_url('view_customer_bill/'); ?>" + id;
  }


  function customer_order1(id) {
    window.location = "<?php echo base_url('customer_order1/'); ?>" + id;
  }

  function view_customer_bill1(id) {
    window.location = "<?php echo base_url('view_customer_bill1/'); ?>" + id;
  }

  function customer_quotation(id) {
    window.location = "<?php echo base_url('customer_quotation/'); ?>" + id;
  }

  function customer_quotation_non_gst(id) {
    window.location = "<?php echo base_url('customer_quotation_non_gst/'); ?>" + id;
  }

  
  

  

  function deleted(id) {
    $.ajax({
      url: '<?php echo base_url('delete_customer/'); ?>' + id,
      type: 'POST',
      dataType: 'json',
      success: function (response) {
        if (response['status'] == 1) {
          alert("Customer Deleted Successfully...!");
          window.location = "<?php echo base_url('view_customer'); ?>";
            
        }
      }
    });
  }
  
</script>
<?= $this->include('Admin/common_function/footer') ?>