<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Purchase Order</title>

<style>
body{
    font-family: Arial, sans-serif;
    font-size:14px;
    margin:20px;
}

.container{
    width:100%;
}

table{
    width:100%;
    border-collapse:collapse;
}

table th,
table td{
    border:1px solid #000;
    padding:6px;
}

.header td{
    border:none;
}

.company{
    text-align:center;
}

.company h2{
    margin:0;
}

.company p{
    margin:3px;
}

.section{
    margin-top:15px;
}

.total td{
    border:1px solid #000;
    padding:8px;
}

.footer{
    margin-top:50px;
}

.signature{
    width:40%;
    float:right;
    text-align:center;
}
</style>
</head>
<body>
<div class="container">
    <table class="header">
        <tr>
            <td class="company">
                <h2>YOUR COMPANY NAME</h2>
                <p>
                    Address Line 1<br>
                    Nashik - 422001<br>
                    Mobile : 9876543210<br>
                    GSTIN : 27XXXXXXXXXX
                </p>
                <h2>SALE PRODUCT</h2>
            </td>
        </tr>
    </table>
    <table class="section">
        <tr>
            <?php 
            foreach($billing as $customer)
            ?>
            <td width="50%">
                <b>Customer Details</b><br><br>
                    <b>Customer Name</b> : <?= $customer['customer_name']; ?><br><br>
                    <b>Company</b> : <?= $customer['company_name']; ?><br><br>
                    <b>Address</b> : <?= $customer['address']; ?><br><br>
                    <b>GST No</b> : <?= $customer['gst_no']; ?>
            </td>
<?php 
foreach($billing as $invoice)
?>
            <td width="50%">
                <b>Invoice Details</b><br><br>
                <b>Invoice No : </b>  <?= $invoice['invoice_no']; ?><br><br>
                <b>PO No : </b>  <?= $invoice['po_no']; ?><br><br>
                <b>Invoice Date : </b>  <?= $invoice['invoice_date']; ?><br><br>
                <b>PO Date : </b>  <?= $invoice['po_date']; ?><br><br>
            </td>
        </tr>
    </table>
    <br>
    <table>
        <tr>
            <th>Sr.</th>
            <th>Product</th>
            <th>HSN</th>
            <th>Unit</th>
            <th>Rate</th>
            <th>Qty</th>
            <th>Amount</th>
            <th>Discount %</th>
            <th>Total</th>
        </tr>
       <?php
       $total_amount = 0;
       $sgst = 0;
       $cgst = 0;
       $cnt=1;
       foreach($billing as $data){
        $total_amount += $data['product_amount'];
        $cgst_amount += $data['cgst_amount'];
        $sgst_amount += $data['sgst_amount'];
       ?>
        <tr>
            <td><?= $cnt++; ?></td>
            <td><?= $data['product_name']; ?></td>
            <td><?= $data['hsn_code']; ?></td>
            <td><?= $data['unit']; ?></td>
            <td><?= $data['product_rate']; ?></td>
            <td><?= $data['product_quantity']; ?></td>
            <td><?= $data['product_rate']*$data['product_quantity']; ?></td>
            <td><?= $data['discount']; ?></td>
            <td><?= $data['product_amount']; ?></td>
        </tr>
        <?php 
        }
        ?>
    </table>
    <br>
    <table class="total">
       
        <tr>
            <td width="75%" align="right">
                <b>Total Amount</b>
            </td>
            <td>
                <?= number_format($total_amount, 2); ?>
            </td>
        </tr>
        <tr>
            <td align="right">
                CGST
            </td>
            <td>
                <?= number_format($cgst_amount, 2); ?>
            </td>
        </tr>
        <tr>
            <td align="right">
                SGST
            </td>
            <td>
                <?= number_format($sgst_amount, 2); ?>
            </td>
        </tr>
        <tr>
            <td align="right">
                IGST
            </td>
            <td>
                <?= number_format($igst_amount, 2); ?>
            </td>
        </tr>
        <tr>
            <td align="right">
                <b>Grand Total</b>
            </td>
            <td>
                <b><?= number_format($total_amount, 2); ?></b>
            </td>
        </tr>
    </table>
    <div class="section">
        <b>Terms & Conditions</b>
        <ol>
            <li>Material should be as per approved specification.</li>
            <li>GST Invoice is mandatory.</li>
            <li>Delivery should be completed before due date.</li>
            <li>Payment will be released as per agreed terms.</li>
        </ol>
    </div>
    <div class="footer">
        <div class="signature">
            <br><br><br>
            _______________________
            <br>
            Authorized Signature
        </div>
    </div>
</div>
</body>
</html>