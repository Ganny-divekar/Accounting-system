<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Pay Customer Bill</h3>
                        </div>
                        <!-- form start -->
                        <form action="" method="post" enctype="multipart/form-data" id="add_data">
                            <input type="hidden" value="<?= $id; ?>" name="customer_bill_id">
                            <input type="hidden" value="<?= $customer_id; ?>" name="customer_id">
                            <input type="hidden" value="<?= $order_id; ?>" name="order_id">

                            

                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-7">
                                        <div class="form-group mb-2">
                                            <label>Total Remaining Amount</label>
                                            <input type="text" value="<?php echo $history['remaining_amount']; ?>" id="tot_remaining_amnt" name="tot_remaining_amnt" class="form-control form-control-sm" placeholder="Total Remaining Amount">
                                            <p id="tot_remaining_amntError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-7">
                                        <div class="form-group mb-2">
                                            <label>Paid Amount</label>
                                            <input type="text" id="paid_amnt" name="paid_amnt" class="form-control form-control-sm" placeholder="Paid Amount">
                                            <p id="paid_amntError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-7">
                                        <div class="form-group mb-2">
                                            <label>Remaining Amount</label>
                                            <input type="text" id="remaining_amount" name="remaining_amount" class="form-control form-control-sm" placeholder="Remaining Amount">
                                            <p id="remaining_amountError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    
                                    <div class="col-md-7">
                                        <div class="form-group mb-2">
                                            <label>Paid To Amount</label>
                                            <input type="text" name="account_name" class="form-control form-control-sm" placeholder="Paid To Account">
                                            <p id="account_nameError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-7">
                                        <div class="form-group mb-2">
                                            <label>Payment Type</label>
                                            <select class="form-control" name="payment_type">
                                                  <option value="cash">Cash</option>
                                                  <option value="cheque">Cheque</option>
                                                  <option value="credit_card">Credit Card</option>
                                                  <option value="finance">Finance</option>
                                                  <option value="neft">NEFT</option>
                                            </select>
                                            <p id="account_typeError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-7">
                                        <div class="form-group mb-2">
                                            <label>Payment Date</label>
                                            <input type="date" name="payment_date" class="form-control form-control-sm" placeholder="Payment Date">
                                            <p id="payment_dateError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    
                                    <div class="col-md-7">
                                        <div class="form-group mb-2">
                                            <label>Reminder Date</label>
                                            <input type="date" name="reminder_date" class="form-control form-control-sm" placeholder="Reminder Date">
                                            <p id="reminder_dateError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer p-2">
                                <button type="submit" class="btn btn-success btn-sm">
                                    <i class="fas fa-save"></i> Submit
                                </button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
                
                <!-- /.col-md-12 -->
            </div>
            <!-- /.row -->
             
        </div>
        <!-- /.container-fluid -->
         
    </section>
    <!-- /.content -->
     <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
    <h3 class="card-title">View Purchase Payment History</h3>
    </div>
              
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Action</th>
                    <th>Sr.no</th>
                    <th>Paid Amount</th>
                    <th>Payment Mode</th>
                    <th>Payment Date</th>
                    <th>Reminder Date</th>
                  </tr>
                  </thead>
                  <tbody>
                   <?php 
                   $cnt=1;
                   foreach($row as $record){
                   ?>
                  <tr>
                    <td>
                      <div class="btn-group">
                        <button type="button" class="btn btn-primary btn-sm">Action</button>

                        <div class="btn-group">
                          <button type="button" class="btn btn-primary btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
                          </button>
                          <div class="dropdown-menu">
                            <a class="dropdown-item" onclick="purchase_pdf(<?= $record['id']; ?>)" href="javascript:void(0);">Print</a>
                            <a class="dropdown-item"  href="javascript:void(0);">Delete</a>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td><?= $cnt++; ?></td>
                    <td><?= $record['paid_amnt']; ?></td>
                    <td><?= $record['payment_type']; ?></td>
                    <td><?= $record['payment_date']; ?></td>
                    <td><?= $record['reminder_date']; ?></td>
                  </tr>
                 <?php 
                   }
                   ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
</div>

<script src="<?= base_url('plugins/jquery/jquery.min.js') ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">


    $('#paid_amnt').on('keyup change', function() {
        var total = parseFloat($('#tot_remaining_amnt').val()) || 0;
        var paid = parseFloat($(this).val()) || 0;

        var remaining = total - paid;

        if(remaining < 0){
            remaining = 0;
        }

        $('#remaining_amount').val(remaining);

    });

// ------------------------------------------------------------------------------------


    $('body').on('submit', '#add_data', function (e) {
    e.preventDefault();
    

    let formData = new FormData(this);

    $.ajax({
      url: '<?php echo base_url('save_customer_history'); ?>',
      type: 'POST',
      data: formData,
      dataType: 'json',
      contentType: false,
      processData: false,
      success: function (response) {
      if (response['status'] == 0) {
        if (response['tot_remaining_amnt'] != "") {
            $('#tot_remaining_amntError').html(response['tot_remaining_amnt']).addClass('invalid-input');
          } else {
            $('#tot_remaining_amntError').html('').removeClass('invalid-input');
          }

          if (response['paid_amnt'] != "") {
            $('#paid_amntError').html(response['paid_amnt']).addClass('invalid-input');
          } else {
            $('#paid_amntError').html('').removeClass('invalid-input');
          }

          if (response['remaining_amount'] != "") {
            $('#remaining_amountError').html(response['remaining_amount']).addClass('invalid-input');
          } else {
            $('#remaining_amountError').html('').removeClass('invalid-input');
          }

          if (response['account_name'] != "") {
            $('#account_nameError').html(response['account_name']).addClass('invalid-input');
          } else {
            $('#account_nameError').html('').removeClass('invalid-input');
          }

          if (response['payment_type'] != "") {
            $('#payment_typeError').html(response['payment_type']).addClass('invalid-input');
          } else {
            $('#payment_typeError').html('').removeClass('invalid-input');
          }

          if (response['payment_date'] != "") {
            $('#payment_dateError').html(response['payment_date']).addClass('invalid-input');
          } else {
            $('#payment_dateError').html('').removeClass('invalid-input');
          }

          if (response['reminder_date'] != "") {
            $('#reminder_dateError').html(response['reminder_date']).addClass('invalid-input');
          } else {
            $('#reminder_dateError').html('').removeClass('invalid-input');
          }

    }else{
        $('.invalid-input').html('').removeClass('invalid-input');
          alert("Payment History Added Successfully...!");
          window.location.href = "<?= base_url("pay_customer_history/"); ?>"+response.customer_bill_id +"/"+response.customer_id+"/"+response.order_id;
    }  
    }
    })
    });

// -----------------------------------------------------------------------------------------

function purchase_pdf(id) {
    window.location = "<?php echo base_url('purchase_history_pdf/'); ?>" + id;
  }
</script>
<?= $this->include('Admin/common_function/footer') ?>