<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Edit Customer</h3>
                        </div>
                        <!-- form start -->
                        <form action="" method="post" enctype="multipart/form-data" id="add_data">
                            <input type="text" name="customer_id" value="<?= $customer['id']; ?>">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Customer Name</label>
                                            <input type="text" name="customer_name" value="<?= $customer['customer_name']; ?>" class="form-control form-control-sm" placeholder="Enter Customer Name">
                                            <p id="customer_nameError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Company Name</label>
                                            <input type="text" name="company_name" value="<?= $customer['company_name']; ?>" class="form-control form-control-sm" placeholder="Enter Company Name">
                                            <p id="company_nameError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Mobile Number</label>
                                            <input type="text" name="mobile_no" value="<?= $customer['mobile_no']; ?>" class="form-control form-control-sm" placeholder="Enter Mobile Number">
                                            <p id="mobile_noError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>GST Number</label>
                                            <input type="text" name="gst_no" value="<?= $customer['gst_no']; ?>" class="form-control form-control-sm" placeholder="GST Number">
                                            <p id="gst_noError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Address</label>
                                            <input type="text" name="address" value="<?= $customer['address']; ?>" class="form-control form-control-sm" placeholder="Enter Address">
                                            <p id="addressError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>City</label>
                                            <input type="text" name="city" value="<?= $customer['city']; ?>" class="form-control form-control-sm" placeholder="Enter City">
                                            <p id="cityError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>State</label>
                                            <input type="text" name="state" value="<?= $customer['state']; ?>" class="form-control form-control-sm" placeholder="Enter State">
                                            <p id="stateError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Pin Code</label>
                                            <input type="text" name="pin_code" value="<?= $customer['pin_code']; ?>" class="form-control form-control-sm" placeholder="Enter Pin Code">
                                            <p id="pin_codeError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Payment Term</label>
                                            <input type="text" name="payment_term" value="<?= $customer['payment_term']; ?>" class="form-control form-control-sm" placeholder="Enter Payment Term">
                                            <p id="payment_termError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer p-2">
                                <button type="submit" class="btn btn-success btn-sm">
                                    <i class="fas fa-save"></i> Submit
                                </button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col-md-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>

<script src="<?= base_url('plugins/jquery/jquery.min.js') ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">

    $('body').on('submit', '#add_data', function (e) {
    e.preventDefault();
    

    let formData = new FormData(this);

    $.ajax({
      url: '<?php echo base_url('update_customer'); ?>',
      type: 'POST',
      data: formData,
      dataType: 'json',
      contentType: false,
      processData: false,
      success: function (response) {
      if (response['status'] == 0) {
        if (response['customer_name'] != "") {
            $('#customer_nameError').html(response['customer_name']).addClass('invalid-input');
          } else {
            $('#customer_nameError').html('').removeClass('invalid-input');
          }

          if (response['company_name'] != "") {
            $('#company_nameError').html(response['company_name']).addClass('invalid-input');
          } else {
            $('#company_nameError').html('').removeClass('invalid-input');
          }

          if (response['mobile_no'] != "") {
            $('#mobile_noError').html(response['mobile_no']).addClass('invalid-input');
          } else {
            $('#mobile_noError').html('').removeClass('invalid-input');
          }

          if (response['gst_no'] != "") {
            $('#gst_noError').html(response['gst_no']).addClass('invalid-input');
          } else {
            $('#gst_noError').html('').removeClass('invalid-input');
          }

          if (response['address'] != "") {
            $('#addressError').html(response['address']).addClass('invalid-input');
          } else {
            $('#addressError').html('').removeClass('invalid-input');
          }

          if (response['city'] != "") {
            $('#cityError').html(response['city']).addClass('invalid-input');
          } else {
            $('#cityError').html('').removeClass('invalid-input');
          }

          if (response['state'] != "") {
            $('#stateError').html(response['state']).addClass('invalid-input');
          } else {
            $('#stateError').html('').removeClass('invalid-input');
          }

          if (response['pin_code'] != "") {
            $('#pin_codeError').html(response['pin_code']).addClass('invalid-input');
          } else {
            $('#pin_codeError').html('').removeClass('invalid-input');
          }

          if (response['payment_term'] != "") {
            $('#payment_termError').html(response['payment_term']).addClass('invalid-input');
          } else {
            $('#payment_termError').html('').removeClass('invalid-input');
          }

    }else{
    $('.invalid-input').html('').removeClass('invalid-input');
    alert("Customer Updated Successfully...!");
    window.location = "<?php echo base_url('view_customer'); ?>";
         
    }  
    }
    })
    });

</script>
<?= $this->include('Admin/common_function/footer') ?>