<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>
<style>
#example1 th,
#example1 td {
    padding: 5px 8px;
    font-size: 13px;
    vertical-align: middle;
}

#example1 th {
    white-space: nowrap;
}
</style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->


    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
    <h3 class="card-title">View Customer Bill</h3>
    </div>
              
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Action</th>
                    <th>Sr.no</th>
                    <th>Invoice Number</th>
                    <th>Customer Name</th>
                    <th>Order Id</th>
                    <th>Total Amount</th>
                    <th>Paid Amount</th>
                    <th>Remaining Amount</th>
                    
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $cnt=1;
                    foreach($history as $record){
                    ?>
                  <tr>
                    <td>
                      <div class="btn-group">
                        <button type="button" class="btn btn-primary btn-sm">Action</button>

                        <div class="btn-group">
                          <button type="button" class="btn btn-primary btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
                          </button>
                          <div class="dropdown-menu">
                            <a class="dropdown-item" onclick="pay_customer_history1(<?= $record['id']; ?>,<?= $record['customer_id']; ?>,<?= $record['order_id']; ?>)" href="javascript:void(0);">Pay</a>
                            <a class="dropdown-item" onclick="customer_order_pdf1(<?= $record['order_id']; ?>)" href="javascript:void(0);">Print</a>
                            <a class="dropdown-item"  href="javascript:void(0);">View</a>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td><?= $cnt++; ?></td>
                    <td><?= $record['invoice_no']; ?></td>
                    <td><?= $record['customer_name']; ?></td>
                    <td><?= $record['order_id']; ?></td>
                    <td><?= $record['product_amount']; ?></td>
                    <td><?= $record['paid_amount']; ?></td>
                    <td><?= $record['remaining_amount']; ?></td>
                  </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">

  function pay_customer_history1(id,customer_id,order_id) {
    window.location = "<?php echo base_url('pay_customer_history1/'); ?>" + id + "/" +customer_id + "/" +order_id;
  }

  function customer_order_pdf1(id) {
    window.location = "<?php echo base_url('customer_bill_pdf1/'); ?>"+id;
  }

  


</script>
<?= $this->include('Admin/common_function/footer') ?>