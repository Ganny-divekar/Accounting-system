<!-- Main Sidebar Container -->
<?php
$session = session();
$username = $session->get('fullname');
?>
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="" class="brand-link">
      
      <span class="brand-text font-weight-light">Welcome:-<?= $username; ?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?= base_url('dist/img/user2-160x160.jpg'); ?>" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block">Alexander Pierce</a>
        </div>
      </div>

      

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item menu-open">
            <a href="<?= base_url('home') ?>" class="nav-link active">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?= base_url('view_vendor'); ?>" class="nav-link">
              <i class="nav-icon far fa-image"></i>
              <p>
                Vendors
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?= base_url('view_product'); ?>" class="nav-link">
              <i class="nav-icon far fa-image"></i>
              <p>
                Products
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?= base_url('view_customer'); ?>" class="nav-link">
              <i class="nav-icon far fa-image"></i>
              <p>
                Customer
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-chart-pie"></i>
              <p>
                Purchase Order
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?= base_url('generate_purchase_order'); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Purchase Order</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('datewise_purchase_order'); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>View PO Date Wise</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-chart-pie"></i>
              <p>
                Customer Order
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?= base_url('generate_customer_order'); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Customer Order</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('datewise_customer_order'); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>View Sale Date Wise</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-chart-pie"></i>
              <p>
                Quotation
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?= base_url('view_quotation_datewise'); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Quotation With GST</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('view_quotation_nongst_datewise'); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Quotation Without GST</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-chart-pie"></i>
              <p>
                Edit Invoice
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?= base_url('view_invoice_gst_datewise'); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>View Invoice With GST</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('view_invoice_nongst_datewise'); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>View Invoice Without GST</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-chart-pie"></i>
              <p>
                Expense / Accounts
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?= base_url('create_group'); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Create Group</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('view_account'); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Create Account</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('predefine_account'); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Predefine Account</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('opening_balance'); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Opening Balance</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('transfer_amount'); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Transfer</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('payment'); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Payment</p>
                </a>
              </li>
              <!-- <li class="nav-item">
                <a href="<?= base_url('view_invoice_nongst_datewise'); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Receipt</p>
                </a>
              </li> -->
            </ul>
          </li>
          <li class="nav-item">
            <a href="<?= base_url('view_report'); ?>" class="nav-link">
              <i class="nav-icon far fa-image"></i>
              <p>
                Reports
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?= base_url('backup_database'); ?>" class="nav-link">
              <i class="nav-icon far fa-image"></i>
              <p>
                Backup Database
              </p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  