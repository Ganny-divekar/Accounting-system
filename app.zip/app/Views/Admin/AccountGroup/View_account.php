<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>
<style>
#example1 th,
#example1 td {
    padding: 5px 8px;
    font-size: 13px;
    vertical-align: middle;
}

#example1 th {
    white-space: nowrap;
}
</style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->


    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
    <h3 class="card-title">View Account</h3>
 <a href="<?= base_url('add_account') ?>" type="button" class="btn btn-primary btn-xs float-right">
        <i class="fas fa-plus"></i> Add Account
</a>
    </div>
              
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Action</th>
                    <th>Sr.no</th>
                    <th>Account Name</th>
                    <th>Group Name</th>
                    <th>Remark</th>
                  </tr>
                  </thead>
                  <tbody>
                 <?php
                 $cnt=1;
                 foreach($account as $data){
                 ?>
                  <tr>
                    <td>
                      <div class="btn-group">
                        <button type="button" class="btn btn-primary btn-sm">Action</button>

                        <div class="btn-group">
                          <button type="button" class="btn btn-primary btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
                          </button>
                          <div class="dropdown-menu">
                            <a class="dropdown-item" onclick="edit(<?= $data['id']; ?>);" href="javascript:void(0);">Edit</a>
                            <a class="dropdown-item" onclick="deleted(<?= $data['id']; ?>);" href="javascript:void(0);">Delete</a>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td><?= $cnt++; ?></td>
                    <td><?= $data['account_name']; ?></td>
                    <td><?= $data['group_name']; ?></td>
                    <td><?= $data['remark']; ?></td>
                  </tr>
                 <?php 
                 } 
                 ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">

 function edit(id) {
    window.location = "<?php echo base_url('edit_account/'); ?>" + id;
  }


  function deleted(id) {
    $.ajax({
      url: '<?php echo base_url('delete_account/'); ?>' + id,
      type: 'POST',
      dataType: 'json',
      success: function (response) {
              alert("Account Deleted Successfully...!");
              window.location = "<?php echo base_url('view_account'); ?>";
      }
    });
  }
  
</script>
<?= $this->include('Admin/common_function/footer') ?>