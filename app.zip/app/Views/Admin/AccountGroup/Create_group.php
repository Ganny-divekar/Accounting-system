<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>
<style>
#example1 th,
#example1 td {
    padding: 5px 8px;
    font-size: 13px;
    vertical-align: middle;
}

#example1 th {
    white-space: nowrap;
}
</style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->


    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
    <h3 class="card-title">View Group</h3>

    </div>
              
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>Sr.no</th>
                    <th>Group Name</th>
                    <th>Remark Name</th>
                  </tr>
                  </thead>
                  <tbody>
                 <?php
                 $cnt=1;
                 foreach($group as $data){
                 ?>
                  <tr>
                    <td><?= $cnt++; ?></td>
                    <td><?= $data['group_name']; ?></td>
                    <td><?= $data['remark']; ?></td>
                  </tr>
                 <?php 
                 } 
                 ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">

 function customer_order(id) {
    window.location = "<?php echo base_url('customer_order/'); ?>" + id;
  }

  function view_customer_bill(id) {
    window.location = "<?php echo base_url('view_customer_bill/'); ?>" + id;
  }


  function customer_order1(id) {
    window.location = "<?php echo base_url('customer_order1/'); ?>" + id;
  }

  function view_customer_bill1(id) {
    window.location = "<?php echo base_url('view_customer_bill1/'); ?>" + id;
  }

  function customer_quotation(id) {
    window.location = "<?php echo base_url('customer_quotation/'); ?>" + id;
  }

  function customer_quotation_non_gst(id) {
    window.location = "<?php echo base_url('customer_quotation_non_gst/'); ?>" + id;
  }

  
  

  

  function deleted(id) {
    $.ajax({
      url: '<?php echo base_url('delete_customer/'); ?>' + id,
      type: 'POST',
      dataType: 'json',
      success: function (response) {
        if (response['status'] == 1) {
          Swal.fire({
            icon: 'success',
            title: 'Product Deleted',
            text: 'The Customer has been successfully Deleted...!',
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'OK'
          }).then((result) => {
            if (result.isConfirmed) {
              window.location = "<?php echo base_url('view_product'); ?>";
            }
          });
        }
      }
    });
  }
  
</script>
<?= $this->include('Admin/common_function/footer') ?>