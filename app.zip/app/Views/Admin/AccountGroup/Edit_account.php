<?= $this->include('Admin/common_function/header') ?>

<?= $this->include('Admin/common_function/menu') ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Edit Account</h3>
                        </div>
                        <!-- form start -->
                        <form action="" method="post" enctype="multipart/form-data" id="add_data">
                            <input type="text" name="id" value="<?= $account['id'] ?>">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Account Name</label>
                                            <input type="text" name="account_name" value="<?= $account['account_name'] ?>" class="form-control form-control-sm" placeholder="Enter Account Name">
                                            <p id="account_nameError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group mb-2">
                                            <label>Group Name</label>
                                            <select type="text" name="group_name" class="form-control form-control-sm" placeholder="Enter Group Name">
                                                 <?php
                                                 foreach($group as $data){
                                                 ?>
                                                 <option value="<?= $data['id'] ?>"><?= $data['group_name'] ?></option>
                                                 <?php } ?>
                                            </select>
                                            <p id="group_nameError" style="color: red;" class="invalid-input"></p>
                                        </div>
                                    </div>
                    
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer p-2">
                                <button type="submit" class="btn btn-success btn-sm">
                                    <i class="fas fa-save"></i> Submit
                                </button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col-md-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>

<script src="<?= base_url('plugins/jquery/jquery.min.js') ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">

    $('body').on('submit', '#add_data', function (e) {
    e.preventDefault();
    

    let formData = new FormData(this);

    $.ajax({
      url: '<?php echo base_url('update_account'); ?>',
      type: 'POST',
      data: formData,
      dataType: 'json',
      contentType: false,
      processData: false,
      success: function (response) {
      if (response['status'] == 0) {
        if (response['account_name'] != "") {
            $('#account_nameError').html(response['account_name']).addClass('invalid-input');
          } else {
            $('#account_nameError').html('').removeClass('invalid-input');
          }

          if (response['group_name'] != "") {
            $('#group_nameError').html(response['group_name']).addClass('invalid-input');
          } else {
            $('#group_nameError').html('').removeClass('invalid-input');
          }

         


    }else{
    $('.invalid-input').html('').removeClass('invalid-input');
    alert("Customer Added Successfully...!");
    window.location = "<?php echo base_url('view_account'); ?>";
         
    }  
    }
    })
    });

</script>
<?= $this->include('Admin/common_function/footer') ?>