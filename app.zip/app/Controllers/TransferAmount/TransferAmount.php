<?php

namespace App\Controllers\TransferAmount;

use App\Models\AccountGroup\AccountModel;
use App\Models\TransferAmount\TransferModel;
use App\Models\OpeningBalance\BalanceSheetModel;

use App\Controllers\BaseController;

class TransferAmount extends BaseController
{
    public function transfer_amount()
    {      
        $model = new AccountModel();    
        $data['account'] = $model->where('is_del','approved')
                                 ->findAll();

        $trasfer = new TransferModel();
        $data['amount'] = $trasfer->select('transfer_amount.*, from_acc.account_name AS from_account_name, to_acc.account_name AS to_account_name')
                                  ->join('accounts AS from_acc', 'transfer_amount.from_account = from_acc.id','left')
                                  ->join('accounts AS to_acc', 'transfer_amount.to_account = to_acc.id','left')
                                  ->where('transfer_amount.is_del','approved')->findAll(); 
        

        return view('Admin/TransferAmount/View_transfer_amount',$data);
    }

    public function save_transfer_amount()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('from_account_name', 'From Account Name', 'required');
        $validation->setRule('to_account_name', 'To Account Name', 'required');
        $validation->setRule('amount', 'Amount', 'required');
        $validation->setRule('remark', 'Remark', 'required');
        $validation->setRule('payment_mode', 'Payment Mode', 'required');

        if ($validation->withRequest($this->request)->run()) {

            $data['from_account_name'] = $this->request->getPost('from_account_name');
            $data['to_account_name'] = $this->request->getPost('to_account_name');
            $data['amount'] = $this->request->getPost('amount');
            $data['remark'] = $this->request->getPost('remark');
            $data['payment_mode'] = $this->request->getPost('payment_mode');
            $data['payment_date'] = date('Y-m-d');
            $month = date('m');
            $year = date('Y');


            if($data['payment_mode'] == 'credit'){
                $model = new TransferModel();
                $model->set('from_account',$data['from_account_name'])
                      ->set('to_account',$data['to_account_name'])
                      ->set('amount',$data['amount'])
                      ->set('payment_mode',$data['payment_mode'])
                      ->set('payment_date',$data['payment_date'])
                      ->set('remark',$data['remark'])
                      ->insert();


                $bal1 = new BalanceSheetModel();
                $bal1->set('account_name',$data['to_account_name'])
                    ->set('debit','0')
                    ->set('credit',$data['amount'])
                    ->set('trasaction_type',$data['payment_mode'])
                    ->set('date',$data['payment_date'])
                    ->set('month',$month)
                    ->set('year',$year)
                    ->set('description',$data['remark'])
                    ->insert();

                $bal2 = new BalanceSheetModel();
                $bal2->set('account_name',$data['from_account_name'])
                    ->set('debit',$data['amount'])
                    ->set('credit','0')
                    ->set('trasaction_type','expense')
                    ->set('date',$data['payment_date'])
                    ->set('month',$month)
                    ->set('year',$year)
                    ->set('description',$data['remark'])
                    ->insert();    
            }else{
                $model = new TransferModel();
                $model->set('from_account',$data['from_account_name'])
                      ->set('to_account',$data['to_account_name'])
                      ->set('amount',$data['amount'])
                      ->set('payment_mode',$data['payment_mode'])
                      ->set('payment_date',$data['payment_date'])
                      ->set('remark',$data['remark'])
                      ->insert();

                $bal1 = new BalanceSheetModel();
                $bal1->set('account_name',$data['to_account_name'])
                    ->set('debit','0')
                    ->set('credit',$data['amount'])
                    ->set('trasaction_type','credit')
                    ->set('date',$data['payment_date'])
                    ->set('month',$month)
                    ->set('year',$year)
                    ->set('description',$data['remark'])
                    ->insert();

                $bal2 = new BalanceSheetModel();
                $bal2->set('account_name',$data['from_account_name'])
                    ->set('debit',$data['amount'])
                    ->set('credit','0')
                    ->set('trasaction_type',$data['payment_mode'])
                    ->set('date',$data['payment_date'])
                    ->set('month',$month)
                    ->set('year',$year)
                    ->set('description',$data['remark'])
                    ->insert();        
            }

            $response['status'] = 1;
            $response['message'] = 'Amount Transfer added successfully!';

        }else{
            $response['status'] = 0;
            $response['from_account_name'] = $validation->getError('from_account_name');
            $response['to_account_name'] = $validation->getError('to_account_name');
            $response['amount'] = $validation->getError('amount');
            $response['remark'] = $validation->getError('remark');
            $response['payment_mode'] = $validation->getError('payment_mode');
        }

         return $this->response->setJSON($response);
    }
}