<?php

namespace App\Controllers\Product;

use App\Models\Product\ProductModel;

use App\Controllers\BaseController;

class Product extends BaseController
{
    public function index()
    {
          $model = new ProductModel();
          $data['product'] = $model->where('is_del','approved')->findAll();
         return view('Admin/Product/View_product',$data);
    }

    public function add_product()
    {
         return view('Admin/Product/Add_product');
    }

    public function save_product()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('product_name', 'Product Name', 'required');
        $validation->setRule('product_code', 'Product Code', 'required');
        $validation->setRule('hsn_code', 'HSN Code', 'required');
        $validation->setRule('unit', 'Unit', 'required');
        $validation->setRule('gst_percentage', 'Gst Percentage', 'required');
        $validation->setRule('purchase_price', 'Purchase Price', 'required');
        $validation->setRule('selling_price', 'Selling Price', 'required');
        $validation->setRule('opening_stock', 'Opening Stock', 'required');
        $validation->setRule('reminder_stock', 'Reminder Stock', 'required');
        $validation->setRule('description', 'Description', 'required');
        $validation->setRule('created_date', 'Created Date', 'required');

        if ($validation->withRequest($this->request)->run()) {

            $data['product_name'] = $this->request->getPost('product_name');
            $data['product_code'] = $this->request->getPost('product_code');
            $data['barcode'] = 'PRD' .str_pad(rand(1, 999999), 6, '0', STR_PAD_LEFT);
            $data['hsn_code'] = $this->request->getPost('hsn_code');
            $data['unit'] = $this->request->getPost('unit');
            $data['gst_percentage'] = $this->request->getPost('gst_percentage');
            $data['purchase_price'] = $this->request->getPost('purchase_price');
            $data['selling_price'] = $this->request->getPost('selling_price');
            $data['opening_stock'] = $this->request->getPost('opening_stock');
            $data['reminder_stock'] = $this->request->getPost('reminder_stock');
            $data['description'] = $this->request->getPost('description');
            $data['created_date'] = $this->request->getPost('created_date');
            $data['is_del'] = 'approved';

            $model = new ProductModel();
            $model->insert($data);

            $response['status'] = 1;
            $response['message'] = 'Product added successfully!';

        }else{
            $response['status'] = 0;
            $response['product_name'] = $validation->getError('product_name');
            $response['product_code'] = $validation->getError('product_code');
            $response['hsn_code'] = $validation->getError('hsn_code');
            $response['unit'] = $validation->getError('unit');
            $response['gst_percentage'] = $validation->getError('gst_percentage');
            $response['purchase_price'] = $validation->getError('purchase_price');
            $response['selling_price'] = $validation->getError('selling_price');
            $response['opening_stock'] = $validation->getError('opening_stock');
            $response['reminder_stock'] = $validation->getError('reminder_stock');
            $response['description'] = $validation->getError('description');
            $response['created_date'] = $validation->getError('created_date');

        }
        return $this->response->setJSON($response);

    }

    public function edit_product($id){
        $model = new ProductModel();
        $data['product'] = $model->find($id);
        return view('Admin/Product/Edit_product', $data);
    }

    public function update_product(){
        $validation = \Config\Services::validation();

        $validation->setRule('product_name', 'Product Name', 'required');
        $validation->setRule('product_code', 'Product Code', 'required');
        $validation->setRule('hsn_code', 'HSN Code', 'required');
        $validation->setRule('unit', 'Unit', 'required');
        $validation->setRule('gst_percentage', 'Gst Percentage', 'required');
        $validation->setRule('purchase_price', 'Purchase Price', 'required');
        $validation->setRule('selling_price', 'Selling Price', 'required');
        $validation->setRule('opening_stock', 'Opening Stock', 'required');
        $validation->setRule('reminder_stock', 'Reminder Stock', 'required');
        $validation->setRule('description', 'Description', 'required');
        $validation->setRule('created_date', 'Created Date', 'required');

        if ($validation->withRequest($this->request)->run()) {

            $id = $this->request->getPost('product_id');
            $data['product_name'] = $this->request->getPost('product_name');
            $data['product_code'] = $this->request->getPost('product_code');
            $data['barcode'] = 'PRD' .str_pad(rand(1, 999999), 6, '0', STR_PAD_LEFT);
            $data['hsn_code'] = $this->request->getPost('hsn_code');
            $data['unit'] = $this->request->getPost('unit');
            $data['gst_percentage'] = $this->request->getPost('gst_percentage');
            $data['purchase_price'] = $this->request->getPost('purchase_price');
            $data['selling_price'] = $this->request->getPost('selling_price');
            $data['opening_stock'] = $this->request->getPost('opening_stock');
            $data['reminder_stock'] = $this->request->getPost('reminder_stock');
            $data['description'] = $this->request->getPost('description');
            $data['created_date'] = $this->request->getPost('created_date');
            $data['is_del'] = 'approved';

            $model = new ProductModel();
            $model->update($id, $data);

            $response['status'] = 1;
            $response['message'] = 'Product Updated successfully!';

        }else{
            $response['status'] = 0;
            $response['product_name'] = $validation->getError('product_name');
            $response['product_code'] = $validation->getError('product_code');
            $response['hsn_code'] = $validation->getError('hsn_code');
            $response['unit'] = $validation->getError('unit');
            $response['gst_percentage'] = $validation->getError('gst_percentage');
            $response['purchase_price'] = $validation->getError('purchase_price');
            $response['selling_price'] = $validation->getError('selling_price');
            $response['opening_stock'] = $validation->getError('opening_stock');
            $response['reminder_stock'] = $validation->getError('reminder_stock');
            $response['description'] = $validation->getError('description');
            $response['created_date'] = $validation->getError('created_date');

        }
        return $this->response->setJSON($response);

    }

    public function delete_product($id){
            $model = new ProductModel();
            $delete = $model->update($id, ['is_del' => 'deleted']);
            if($delete == true){
                $response['status'] = 1;
            }
            return $this->response->setJSON($response);
    }

}