<?php

namespace App\Controllers\Quotation;

use App\Models\Customer\CustomerModel;
use App\Models\Product\ProductModel;
use App\Models\Quotation\CustomerQuotation;
use App\Models\Quotation\CustomerQuotationNongst;
use App\Models\Quotation\QuotationBill;
use App\Models\Quotation\QuotationBillNongst;


use App\Controllers\BaseController;

class Quotation extends BaseController
{
    public function customer_quotation($id)
    {
        $customer = new  CustomerModel();
        $data['customer'] = $customer->where('id',$id)
                      ->where('is_del','approved')
                      ->first();

        $product = new ProductModel();
        $data['product'] = $product->where('is_del','approved')
                                   ->findAll();

        $model = new CustomerQuotation();
        $last = $model->orderBy('quotation_no', 'DESC')->first();

        if($last){
            $lastNo = $last['quotation_no'];
            $num = (int) substr($lastNo, 2);
            $data['quotation_no'] = 'QT' .str_pad($num + 1, 6, '0', STR_PAD_LEFT);
        }else{
            $data['quotation_no'] = 'QT000001';
        }                          
        return view('Admin/Quotation/View_quotation',$data);
    }

    public function save_customer_quotation()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('quotation_number', 'Quotation Number', 'required');
        $validation->setRule('quotation_date', 'Quotation Date', 'required');
        $validation->setRule('customer_name', 'Customer Name', 'required');


        if ($validation->withRequest($this->request)->run()) {

                $order_id = rand(1000,9999).date('Ymd');

                $products   = $this->request->getPost('product');
                $qtys       = $this->request->getPost('qty');
                $rates      = $this->request->getPost('rate');
                $discounts  = $this->request->getPost('discount');
                $gst_type = $this->request->getPost('gst_type');

            foreach($products as $key=>$product){

                $user_rate = $rates[$key];
                $qty  = $qtys[$key];
                $discount = $discounts[$key];

                $sgst_amount = 0;
                $cgst_amount = 0;
                $igst_amount = 0;

                $Productmodel = new ProductModel();
                $product = $Productmodel->find($products[$key]);

                $rate = $product['purchase_price'];
                $stock = $product['opening_stock'];
                $gst = $product['gst_percentage'];
                $hsn_code = $product['hsn_code'];
                $product_id = $product['id'];
                $unit = $product['unit'];

                $sgst = $gst/2;
                $cgst = $gst/2;
                $igst = $gst;

                if($user_rate>0){
                    $comman_rate = $user_rate;
                }else{
                    $comman_rate = $rate;
                }

                if($gst_type=="sgst_cgst"){

                    $discount_amount = ($comman_rate * $discount)/100;
                    $product_rate = $comman_rate - $discount_amount;
                    $amount = $product_rate * $qty;
           
                    $sgst_amount = $amount*$sgst/100;
                    $cgst_amount = $amount*$cgst/100;

                }

                if($gst_type=="igst"){

                    $discount_amount = ($comman_rate * $discount)/100;
                    $product_rate = $comman_rate - $discount_amount;
                    $amount = $product_rate * $qty;

                    $igst = $gst;
                    $igst_amount = $amount*$igst/100;

                }

                    $insertData['customer_id'] = $this->request->getPost('customer_id');
                    $insertData['order_id'] = $order_id;
                    $insertData['quotation_no'] = $this->request->getPost('quotation_number');
                    $insertData['product_id'] = $product_id;
                    $insertData['product_rate'] = $product_rate;
                    $insertData['product_quantity'] = $qty;
                    $insertData['discount'] = $discount;
                    $insertData['unit'] = $unit;
                    $insertData['sgst'] = $sgst;
                    $insertData['sgst_amount'] = $sgst_amount;
                    $insertData['cgst'] = $cgst;
                    $insertData['cgst_amount'] = $cgst_amount;
                    $insertData['igst'] = $igst;
                    $insertData['igst_amount'] = $igst_amount;
                    $insertData['product_amount'] = $amount+$sgst_amount+$cgst_amount+$igst_amount;
                    $insertData['quotation_date'] = date('Y-m-d');
                    $insertData['quotation_month'] = date('m');
                    $insertData['quotation_year'] = date('Y');
                    $insertData['hsn_code'] = $hsn_code;

                    $model = new CustomerQuotation();
                    $model->insert($insertData);

                    $quantity = $stock - $qty;
                    $stockUpdate = new ProductModel();
                    $stockUpdate->where('id', $product_id)->where('is_del', 'approved')->set('opening_stock', $quantity)->update();

                    $response['status'] = 1;
                    $response['order_id'] = $order_id;
            }
        }else{

                $response['status'] = 0;
                $response['quotation_number'] = $validation->getError('quotation_number');
                $response['quotation_date'] = $validation->getError('quotation_date');
                $response['customer_name'] = $validation->getError('customer_name');

        }

        return $this->response->setJSON($response);
    }

    public function customer_quotation_bill($id)
    {
        $model = new CustomerQuotation();
        $data['quotation'] = $model->where('order_id',$id)
                                   ->where('is_del','approved')
                                   ->findAll();
        return view('Admin/Quotation/View_quotation_bill',$data);
    }

    public function save_quotation_bill()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('quotation_no', 'Quotation Number', 'required');
        $validation->setRule('product_amount', 'Product Amount', 'required');
        $validation->setRule('sgst', 'SGST', 'required');
        $validation->setRule('sgst_amount', 'Sgst Amount', 'required');
        $validation->setRule('cgst', 'CGST', 'required');
        $validation->setRule('cgst_amount', 'Cgst Amount', 'required');
        $validation->setRule('igst', 'IGST', 'required');
        $validation->setRule('igst_amount', 'Igst Amount', 'required');

        if ($validation->withRequest($this->request)->run()) {

            $data['customer_id'] = $this->request->getPost('customer_id');
            $data['order_id'] = $this->request->getPost('order_id');
            $data['product_rate'] = $this->request->getPost('product_rate');
            $data['unit'] = $this->request->getPost('unit');

            $data['quotation_date'] = $this->request->getPost('quotation_date');
            $data['quotation_month'] = $this->request->getPost('quotation_month');
            $data['quotation_year'] = $this->request->getPost('quotation_year');
            $data['hsn_code'] = $this->request->getPost('hsn_code');
            $data['discount'] = $this->request->getPost('discount');

            $data['quotation_no'] = $this->request->getPost('quotation_no');
            $data['product_amount'] = $this->request->getPost('product_amount');
            $data['sgst'] = $this->request->getPost('sgst');
            $data['sgst_amount'] = $this->request->getPost('sgst_amount');
            $data['cgst'] = $this->request->getPost('cgst');
            $data['cgst_amount'] = $this->request->getPost('cgst_amount');
            $data['igst'] = $this->request->getPost('igst');
            $data['igst_amount'] = $this->request->getPost('igst_amount');
            $data['paid_amount'] = 0;
            $data['remaining_amount'] = $this->request->getPost('product_amount');
            $data['is_del'] = 'approved';

            $model = new QuotationBill();
            $model->insert($data);


            $response['status'] = 1;
            $response['message'] = 'Bill added successfully!';
            $response['order_id'] = $data['order_id'];
        }else{

            $response['status'] = 0;
            $response['quotation_no'] = $validation->getError('quotation_no');
            $response['product_amount'] = $validation->getError('product_amount');
            $response['sgst'] = $validation->getError('sgst');
            $response['sgst_amount'] = $validation->getError('sgst_amount');
            $response['cgst'] = $validation->getError('cgst');
            $response['cgst_amount'] = $validation->getError('cgst_amount');
            $response['igst'] = $validation->getError('igst');
            $response['igst_amount'] = $validation->getError('igst_amount');
        }

            return $this->response->setJSON($response);
    }

    public function quotation_bill_pdf($id)
    {
        $model = new CustomerQuotation();
        $data['quotation'] = $model
                         ->select('customer_quotation.*, product.*,customer_details.*')
                         ->join('product', 'product.id = customer_quotation.product_id', 'left')
                         ->join('customer_details','customer_details.id = customer_quotation.customer_id')
                         ->where('customer_quotation.order_id',$id)
                         ->where('customer_quotation.is_del', 'approved')
                         ->findAll();

        return view('Admin/Quotation/Quotation_bill_pdf',$data);
    }

    public function view_quotation_datewise()
    {
        return view('Admin/Quotation/View_quotation_datewise');
    }

    public function view_gst_quotation()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('from_date', 'From Date', 'required');
        $validation->setRule('to_date', 'To Date', 'required');

        if (!$validation->withRequest($this->request)->run()) {

           return redirect()->back()->withInput()->with('error', 'Please select From Date and To Date');
        }


            $from_date = $this->request->getPost('from_date');
            $to_date = $this->request->getPost('to_date');


            $model = new QuotationBill();
            $data['customer_quotation'] = $model->select('quotation_bill.*, customer_details.*')
                    ->join('customer_details','customer_details.id = quotation_bill.customer_id')
                    ->where('quotation_bill.is_del','approved')
                    ->where('quotation_date >=', $from_date)
                    ->where('quotation_date <=', $to_date)
                    ->findAll();

            return view('Admin/Quotation/View_quotation_gst',$data);
    }

    public function customer_quotation_non_gst($id)
    {
        $customer = new  CustomerModel();
        $data['customer'] = $customer->where('id',$id)
                      ->where('is_del','approved')
                      ->first();

        $product = new ProductModel();
        $data['product'] = $product->where('is_del','approved')
                                   ->findAll();

        $model = new CustomerQuotationNongst();
        $last = $model->orderBy('quotation_no', 'DESC')->first();

        if($last){
            $lastNo = $last['quotation_no'];
            $num = (int) substr($lastNo, 2);
            $data['quotation_no'] = 'QT' .str_pad($num + 1, 6, '0', STR_PAD_LEFT);
        }else{
            $data['quotation_no'] = 'QT000001';
        }                          
        return view('Admin/Quotation/View_quotation_nongst',$data);
    }

    public function save_customer_quotation_nongst()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('quotation_number', 'Quotation Number', 'required');
        $validation->setRule('quotation_date', 'Quotation Date', 'required');
        $validation->setRule('customer_name', 'Customer Name', 'required');


        if ($validation->withRequest($this->request)->run()) {

                $order_id = rand(1000,9999).date('Ymd');

                $products   = $this->request->getPost('product');
                $qtys       = $this->request->getPost('qty');
                $rates      = $this->request->getPost('rate');
                $discounts  = $this->request->getPost('discount');
                $gst_type = $this->request->getPost('gst_type');

            foreach($products as $key=>$product){

                $user_rate = $rates[$key];
                $qty  = $qtys[$key];
                $discount = $discounts[$key];

                

                $Productmodel = new ProductModel();
                $product = $Productmodel->find($products[$key]);

                $rate = $product['purchase_price'];
                $stock = $product['opening_stock'];
                $gst = $product['gst_percentage'];
                $hsn_code = $product['hsn_code'];
                $product_id = $product['id'];
                $unit = $product['unit'];

                

                if($user_rate>0){
                    $comman_rate = $user_rate;
                }else{
                    $comman_rate = $rate;
                }

                
                    $discount_amount = ($comman_rate * $discount)/100;
                    $product_rate = $comman_rate - $discount_amount;
                    $amount = $product_rate * $qty;
           

                

                

                    $insertData['customer_id'] = $this->request->getPost('customer_id');
                    $insertData['order_id'] = $order_id;
                    $insertData['quotation_no'] = $this->request->getPost('quotation_number');
                    $insertData['product_id'] = $product_id;
                    $insertData['product_rate'] = $product_rate;
                    $insertData['product_quantity'] = $qty;
                    $insertData['discount'] = $discount;
                    $insertData['unit'] = $unit;
                    $insertData['product_amount'] = $amount;
                    $insertData['quotation_date'] = date('Y-m-d');
                    $insertData['quotation_month'] = date('m');
                    $insertData['quotation_year'] = date('Y');
                    $insertData['hsn_code'] = $hsn_code;

                    $model = new CustomerQuotationNongst();
                    $model->insert($insertData);

                    $quantity = $stock - $qty;
                    $stockUpdate = new ProductModel();
                    $stockUpdate->where('id', $product_id)->where('is_del', 'approved')->set('opening_stock', $quantity)->update();

                    $response['status'] = 1;
                    $response['order_id'] = $order_id;
            }
        }else{

                $response['status'] = 0;
                $response['quotation_number'] = $validation->getError('quotation_number');
                $response['quotation_date'] = $validation->getError('quotation_date');
                $response['customer_name'] = $validation->getError('customer_name');

        }

        return $this->response->setJSON($response);
    }

    public function customer_quotation_nongst_bill($id)
    {
        $model = new CustomerQuotationNongst();
        $data['quotation'] = $model->where('order_id',$id)
                                   ->where('is_del','approved')
                                   ->findAll();
        return view('Admin/Quotation/View_quotation_nongst_bill',$data);
    }

    public function save_quotation_bill_nongst()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('quotation_no', 'Quotation Number', 'required');
        $validation->setRule('product_amount', 'Product Amount', 'required');
       

        if ($validation->withRequest($this->request)->run()) {

            $data['customer_id'] = $this->request->getPost('customer_id');
            $data['order_id'] = $this->request->getPost('order_id');
            $data['product_rate'] = $this->request->getPost('product_rate');
            $data['unit'] = $this->request->getPost('unit');

            $data['quotation_date'] = $this->request->getPost('quotation_date');
            $data['quotation_month'] = $this->request->getPost('quotation_month');
            $data['quotation_year'] = $this->request->getPost('quotation_year');
            $data['hsn_code'] = $this->request->getPost('hsn_code');
            $data['discount'] = $this->request->getPost('discount');

            $data['quotation_no'] = $this->request->getPost('quotation_no');
            $data['product_amount'] = $this->request->getPost('product_amount');
            $data['paid_amount'] = 0;
            $data['remaining_amount'] = $this->request->getPost('product_amount');
            $data['is_del'] = 'approved';

            $model = new QuotationBillNongst();
            $model->insert($data);


            $response['status'] = 1;
            $response['message'] = 'Bill added successfully!';
            $response['order_id'] = $data['order_id'];
        }else{

            $response['status'] = 0;
            $response['quotation_no'] = $validation->getError('quotation_no');
            $response['product_amount'] = $validation->getError('product_amount');
        }

            return $this->response->setJSON($response);
    }

    public function quotation_nongst_bill_pdf($id)
    {
        $model = new CustomerQuotationNongst();
        $data['quotation'] = $model
                         ->select('customer_quotation_nongst.*, product.*,customer_details.*')
                         ->join('product', 'product.id = customer_quotation_nongst.product_id', 'left')
                         ->join('customer_details','customer_details.id = customer_quotation_nongst.customer_id')
                         ->where('customer_quotation_nongst.order_id',$id)
                         ->where('customer_quotation_nongst.is_del', 'approved')
                         ->findAll();
        return view('Admin/Quotation/Quotation_nongst_bill_pdf',$data);
    }

    public function view_quotation_nongst_datewise()
    {
        return view('Admin/Quotation/View_quotation_nongst_datewise');
    }

    public function view_nongst_quotation()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('from_date', 'From Date', 'required');
        $validation->setRule('to_date', 'To Date', 'required');

        if (!$validation->withRequest($this->request)->run()) {

           return redirect()->back()->withInput()->with('error', 'Please select From Date and To Date');
        }


            $from_date = $this->request->getPost('from_date');
            $to_date = $this->request->getPost('to_date');


            $model = new QuotationBillNongst();
            $data['customer_quotation'] = $model->select('quotation_bill_nongst.*, customer_details.*')
                    ->join('customer_details','customer_details.id = quotation_bill_nongst.customer_id')
                    ->where('quotation_bill_nongst.is_del','approved')
                    ->where('quotation_date >=', $from_date)
                    ->where('quotation_date <=', $to_date)
                    ->findAll();

            return view('Admin/Quotation/View_quotation_with_nongst',$data);
    }
    

}