<?php

namespace App\Controllers;

use App\Models\LoginModel;
class Home extends BaseController
{
    
    public function index()
    {
       
        return view('index');
    }

    public function register()
    {
        return view('register_member');
    }

    public function save_register()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('fullname', 'Full Name', 'required');
        $validation->setRule('address', 'Address', 'required');
        $validation->setRule('email', 'Email', 'required');
        $validation->setRule('password', 'Password', 'required');
        $validation->setRule('repassword', 'Re - Password', 'required');

        if ($validation->withRequest($this->request)->run()) {

            $data['fullname'] = $this->request->getPost('fullname');
            $data['address'] = $this->request->getPost('address');
            $data['email'] = $this->request->getPost('email');
            $data['password'] = $this->request->getPost('password');
            $data['repassword'] = $this->request->getPost('repassword');
            $data['is_del'] ='approved';

            if($data['password'] == $data['repassword']){
                $model = new LoginModel();
                $model->insert($data);

                $response['status'] = 1;
                $response['message'] = 'Registration successfully!';
            }else{
                alert("Please Match password");
            }

        }else{
            $response['status'] = 0;
            $response['fullname'] = $validation->getError('fullname');
            $response['address'] = $validation->getError('address');
            $response['email'] = $validation->getError('email');
            $response['password'] = $validation->getError('password');
            $response['repassword'] = $validation->getError('repassword');

        }

        return $this->response->setJSON($response);

    }

    public function login(){

    helper(['form']);

        $validation = \Config\Services::validation();

        $validation->setRule('email', 'Email', 'required');
        $validation->setRule('password', 'Password', 'required');

        if (!$validation->withRequest($this->request)->run()) {
            return redirect()->back()->withInput()->with('error', $validation->listErrors());
        }

            $email = $this->request->getPost('email');
            $password = $this->request->getPost('password');

            $model = new LoginModel();
            $user = $model
            ->where('email',$email)
            ->where('password',$password)
            ->where('is_del','approved')
            ->first();

            if($user){
                 if($password == $user['password']){

                 session()->set([
                    'user_id' => $user['id'],
                    'fullname' => $user['fullname'],
                    'email' => $user['email'],
                    'logged_in' => true
                 ]);
                 return redirect()->to('/home');
                 }
            }
            return redirect()->back()->with('error', 'Invalid Email or Password');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/');
    }
}
