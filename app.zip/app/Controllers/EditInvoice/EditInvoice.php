<?php

namespace App\Controllers\EditInvoice;
use App\Models\Customer\CustomerBill;
use App\Models\Customer\CustomerBill1;
use App\Models\Customer\CustomerOrder;
use App\Models\Customer\CustomerOrder1;
use App\Models\Product\ProductModel;


use App\Controllers\BaseController;

class EditInvoice extends BaseController
{
    public function view_invoice_gst_datewise()
    {
        return view('Admin/EditInvoice/View_invoice_gst_datewise');
    }

    public function view_invoice_gst()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('from_date', 'From Date', 'required');
        $validation->setRule('to_date', 'To Date', 'required');

        if (!$validation->withRequest($this->request)->run()) {

           return redirect()->back()->withInput()->with('error', 'Please select From Date and To Date');
        }


            $from_date = $this->request->getPost('from_date');
            $to_date = $this->request->getPost('to_date');


            $model = new CustomerBill();
            $data['customer_order'] = $model->select('customer_bill.*, customer_details.*')
                    ->join('customer_details','customer_details.id = customer_bill.customer_id')
                    ->where('customer_bill.is_del','approved')
                    ->where('invoice_date >=', $from_date)
                    ->where('invoice_date <=', $to_date)
                    ->findAll();

            $data['form_date'] = $from_date;
            $data['to_date'] = $to_date;
                    
        return view('Admin/EditInvoice/View_invoice_gst',$data);
    }

    public function edit_customer_invoice($id)
    {

        $product = new ProductModel();
        $data['product'] = $product->where('is_del','approved')
                                   ->findAll();

        $bill = new CustomerBill();
        $data['bill'] = $bill->select('customer_bill.*, customer_details.customer_name')
                              ->join('customer_details','customer_bill.customer_id = customer_details.id','left')
                              ->where('customer_bill.order_id',$id)
                              ->first();    

        $model = new CustomerOrder();
        $data['sale'] = $model->select('customer_order.*, product.product_name,product.gst_percentage, customer_details.customer_name')
                              ->join('product','customer_order.product_id = product.id','left')
                              ->join('customer_details','customer_order.customer_id = customer_details.id','left')
                              ->where('customer_order.order_id',$id)
                              ->where('customer_order.is_del','approved')
                              ->findAll();
        
        return view('Admin/EditInvoice/Edit_customer_invoice',$data);
    }

    public function save_edit_customer_invoice()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('invoice_number', 'Invoice Number', 'required');
        $validation->setRule('po_no', 'PO Number', 'required');
        $validation->setRule('po_date', 'PO Date', 'required');
        $validation->setRule('invoice_date', 'Invoice Date', 'required');

        $order_id =  $this->request->getPost('order_id');
        if ($validation->withRequest($this->request)->run()) {

                $products   = $this->request->getPost('product');
                $qtys       = $this->request->getPost('qty');
                $rates      = $this->request->getPost('rate');
                $discounts  = $this->request->getPost('discount');
                $gst_type = $this->request->getPost('gst_type');

            foreach($products as $key=>$product){

                $user_rate = $rates[$key];
                $qty  = $qtys[$key];
                $discount = $discounts[$key];

                $sgst_amount = 0;
                $cgst_amount = 0;
                $igst_amount = 0;

                $Productmodel = new ProductModel();
                $product = $Productmodel->find($products[$key]);

                $rate = $product['selling_price'];
                $stock = $product['opening_stock'];
                $gst = $product['gst_percentage'];
                $hsn_code = $product['hsn_code'];
                $product_id = $product['id'];
                $unit = $product['unit'];

                $sgst = $gst/2;
                $cgst = $gst/2;
                $igst = $gst;

                if($user_rate>0){
                    $comman_rate = $user_rate;
                }else{
                    $comman_rate = $rate;
                }

                if($gst_type=="sgst_cgst"){

                    $discount_amount = ($comman_rate * $discount)/100;
                    $product_rate = $comman_rate - $discount_amount;
                    $amount = $product_rate * $qty;
           
                    $sgst_amount = $amount*$sgst/100;
                    $cgst_amount = $amount*$cgst/100;

                }

                if($gst_type=="igst"){

                    $discount_amount = ($comman_rate * $discount)/100;
                    $product_rate = $comman_rate - $discount_amount;
                    $amount = $product_rate * $qty;

                    $igst = $gst;
                    $igst_amount = $amount*$igst/100;

                }
                    $insertData['customer_id'] = $this->request->getPost('customer_id');
                    $insertData['order_id'] = $order_id;
                    $insertData['invoice_no'] = $this->request->getPost('invoice_number');
                    $insertData['po_no'] = $this->request->getPost('po_no');
                    $insertData['product_id'] = $product_id;
                    $insertData['product_rate'] = $product_rate;
                    $insertData['product_quantity'] = $qty;
                    $insertData['discount'] = $discount;
                    $insertData['unit'] = $unit;
                    $insertData['sgst'] = $sgst;
                    $insertData['sgst_amount'] = $sgst_amount;
                    $insertData['cgst'] = $cgst;
                    $insertData['cgst_amount'] = $cgst_amount;
                    $insertData['igst'] = $igst;
                    $insertData['igst_amount'] = $igst_amount;
                    $insertData['product_amount'] = $amount+$sgst_amount+$cgst_amount+$igst_amount;
                    $insertData['invoice_date'] = date('Y-m-d');
                    $insertData['po_date'] = $this->request->getPost('po_date');
                    $insertData['invoice_month'] = date('m');
                    $insertData['invoice_year'] = date('Y');
                    $insertData['hsn_code'] = $hsn_code;
                    $insertData['is_del'] = 'approved';

                    $model = new CustomerOrder();
                    $model->where('order_id',$order_id)
                          ->where('is_del','approved')
                          ->insert($insertData);

                    $quantity = $stock - $qty;
                    $stockUpdate = new ProductModel();
                    $stockUpdate->where('id', $product_id)->where('is_del', 'approved')->set('opening_stock', $quantity)->update();

                    $response['status'] = 1;
                    $response['order_id'] = $order_id;
            }
        }else{

                $response['status'] = 0;
                $response['invoice_number'] = $validation->getError('invoice_number');
                $response['po_no'] = $validation->getError('po_no');
                $response['po_date'] = $validation->getError('po_date');
                $response['invoice_date'] = $validation->getError('invoice_date');

        }

        return $this->response->setJSON($response);
    }

    public function edit_customer_order_bill($id)
    {
        $model = new CustomerOrder();
        $data['sale'] = $model->where('order_id',$id)->where('is_del', 'approved')->find();
        return view('Admin/EditInvoice/Edit_customer_order_bill',$data);
    }

    public function save_edit_customer_bill()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('invoice_no', 'Invoice Number', 'required');
        $validation->setRule('product_amount', 'Product Amount', 'required');
        $validation->setRule('sgst', 'SGST', 'required');
        $validation->setRule('sgst_amount', 'Sgst Amount', 'required');
        $validation->setRule('cgst', 'CGST', 'required');
        $validation->setRule('cgst_amount', 'Cgst Amount', 'required');
        $validation->setRule('igst', 'IGST', 'required');
        $validation->setRule('igst_amount', 'Igst Amount', 'required');

        if ($validation->withRequest($this->request)->run()) {

            $data['customer_id'] = $this->request->getPost('customer_id');
            $order_id = $this->request->getPost('order_id');
            $data['product_rate'] = $this->request->getPost('product_rate');
            $data['unit'] = $this->request->getPost('unit');

            $data['invoice_date'] = $this->request->getPost('invoice_date');
            $data['po_date'] = $this->request->getPost('po_date');
            $data['invoice_month'] = $this->request->getPost('invoice_month');
            $data['invoice_year'] = $this->request->getPost('invoice_year');
            $data['hsn_code'] = $this->request->getPost('hsn_code');
            $data['discount'] = $this->request->getPost('discount');

            $data['invoice_no'] = $this->request->getPost('invoice_no');
            $data['product_amount'] = $this->request->getPost('product_amount');
            $data['sgst'] = $this->request->getPost('sgst');
            $data['sgst_amount'] = $this->request->getPost('sgst_amount');
            $data['cgst'] = $this->request->getPost('cgst');
            $data['cgst_amount'] = $this->request->getPost('cgst_amount');
            $data['igst'] = $this->request->getPost('igst');
            $data['igst_amount'] = $this->request->getPost('igst_amount');
            $data['paid_amount'] = 0;
            $data['remaining_amount'] = $this->request->getPost('product_amount');
            $data['is_del'] = 'approved';

            $model = new CustomerBill();
            $model->where('order_id',$order_id)
                  ->set($data)
                  ->update();
           
            


            $response['status'] = 1;
            $response['message'] = 'Bill added successfully!';
            $response['order_id'] = $order_id;
        }else{

            $response['status'] = 0;
            $response['invoice_no'] = $validation->getError('invoice_no');
            $response['product_amount'] = $validation->getError('product_amount');
            $response['sgst'] = $validation->getError('sgst');
            $response['sgst_amount'] = $validation->getError('sgst_amount');
            $response['cgst'] = $validation->getError('cgst');
            $response['cgst_amount'] = $validation->getError('cgst_amount');
            $response['igst'] = $validation->getError('igst');
            $response['igst_amount'] = $validation->getError('igst_amount');
        }

            return $this->response->setJSON($response);
    }

    public function delete_customer_product($id,$order_id)
    {

        $productorder = new CustomerOrder();
        $product = $productorder->where('id',$id)
                         ->where('order_id',$order_id)
                         ->first();

        $product_order_id = $product['order_id'];
        $sgst_amount1 = $product['sgst_amount'];
        $cgst_amount1 = $product['cgst_amount'];
        $product_amount1 = $product['product_amount'];


        
        $product_bill = new CustomerBill();
        $bill = $product_bill->where('order_id',$product_order_id)
                             ->first();
         
        $sgst_amount2 = $bill['sgst_amount'];
        $cgst_amount2 = $bill['cgst_amount'];
        $product_amount2 = $bill['product_amount'];
        $remain_amount2 = $bill['remaining_amount'];


        $tot_sgst = ($sgst_amount2) - ($sgst_amount1);
        $tot_cgst = ($cgst_amount2) - ($cgst_amount1);
        $tot_product_amount = ($product_amount2) - ($product_amount1);


        $update_bill = new CustomerBill();
        $final = $update_bill->where('order_id',$order_id)
                             ->set('sgst_amount',$tot_sgst)
                             ->set('cgst_amount',$tot_cgst)
                             ->set('product_amount',$tot_product_amount)
                             ->set('remaining_amount',$tot_product_amount)
                             ->update();


            $model = new CustomerOrder();
            $delete = $model->where('order_id',$order_id)
                            ->where('id',$id)
                            ->set('is_del','deleted')
                            ->update();

                          
            if($delete){
                $response['status'] = 1;
                $response['order_id'] = $order_id;
                $response['message'] = "Product Deleted Successfully...!";
            }else{
                $response['status'] = 0;
                $response['order_id'] = $order_id;
                $response['message'] = "Product Deleted Failed...!";
            }
            return $this->response->setJSON($response);
    }

    public function delete_customer_invoice_bill($id)
    {
        $model = new CustomerBill();
        $delete = $model->where('order_id',$id)
                        ->set('is_del','deleted')
                        ->update();

                          
            if($delete){
                $response['status'] = 1;
                $response['order_id'] = $id;
                $response['message'] = "Bill Deleted Successfully...!";
            }else{
                $response['status'] = 0;
                $response['order_id'] = $id;
                $response['message'] = "Bill Deleted Failed...!";
            }
            return $this->response->setJSON($response);
    }

    // -----------------//------------//------------------//----------------//---------------//--------------//----------

    public function view_invoice_nongst_datewise()
    {
        return view('Admin/EditInvoice/View_invoice_nongst_datewise');
    }

    public function view_invoice_nongst()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('from_date', 'From Date', 'required');
        $validation->setRule('to_date', 'To Date', 'required');

        if (!$validation->withRequest($this->request)->run()) {

           return redirect()->back()->withInput()->with('error', 'Please select From Date and To Date');
        }


            $from_date = $this->request->getPost('from_date');
            $to_date = $this->request->getPost('to_date');


            $model = new CustomerBill1();
            $data['customer_order'] = $model->select('customer_bill1.*, customer_details.*')
                    ->join('customer_details','customer_details.id = customer_bill1.customer_id')
                    ->where('customer_bill1.is_del','approved')
                    ->where('invoice_date >=', $from_date)
                    ->where('invoice_date <=', $to_date)
                    ->findAll();

            $data['form_date'] = $from_date;
            $data['to_date'] = $to_date;
                    
        return view('Admin/EditInvoice/View_invoice_nongst',$data);
    }

    public function edit_customer_invoice_nongst($id)
    {
        $product = new ProductModel();
        $data['product'] = $product->where('is_del','approved')
                                   ->findAll();

        $bill = new CustomerBill1();
         $data['bill'] = $bill->select('customer_bill1.*, customer_details.customer_name')
                              ->join('customer_details','customer_bill1.customer_id = customer_details.id','left')
                              ->where('customer_bill1.order_id',$id)
                              ->first();    

        $model = new CustomerOrder1();
        $data['sale'] = $model->select('customer_order1.*, product.product_name,product.gst_percentage, customer_details.customer_name')
                              ->join('product','customer_order1.product_id = product.id','left')
                              ->join('customer_details','customer_order1.customer_id = customer_details.id','left')
                              ->where('customer_order1.order_id',$id)
                              ->where('customer_order1.is_del','approved')
                              ->findAll();
        
        return view('Admin/EditInvoice/Edit_customer_invoice_nongst',$data);
    }

    public function save_edit_customer_invoice_nongst()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('invoice_number', 'Invoice Number', 'required');
        $validation->setRule('po_no', 'PO Number', 'required');
        $validation->setRule('po_date', 'PO Date', 'required');
        $validation->setRule('invoice_date', 'Invoice Date', 'required');

        $order_id =  $this->request->getPost('order_id');
        if ($validation->withRequest($this->request)->run()) {

                $products   = $this->request->getPost('product');
                $qtys       = $this->request->getPost('qty');
                $rates      = $this->request->getPost('rate');
                $discounts  = $this->request->getPost('discount');
                $gst_type = $this->request->getPost('gst_type');

            foreach($products as $key=>$product){

                $user_rate = $rates[$key];
                $qty  = $qtys[$key];
                $discount = $discounts[$key];

                // $sgst_amount = 0;
                // $cgst_amount = 0;
                // $igst_amount = 0;

                $Productmodel = new ProductModel();
                $product = $Productmodel->find($products[$key]);

                $rate = $product['selling_price'];
                $stock = $product['opening_stock'];
                $gst = $product['gst_percentage'];
                $hsn_code = $product['hsn_code'];
                $product_id = $product['id'];
                $unit = $product['unit'];

                // $sgst = $gst/2;
                // $cgst = $gst/2;
                // $igst = $gst;

                if($user_rate>0){
                    $comman_rate = $user_rate;
                }else{
                    $comman_rate = $rate;
                }

                // if($gst_type=="sgst_cgst"){

                    $discount_amount = ($comman_rate * $discount)/100;
                    $product_rate = $comman_rate - $discount_amount;
                    $amount = $product_rate * $qty;
           
                    // $sgst_amount = $amount*$sgst/100;
                    // $cgst_amount = $amount*$cgst/100;

                // }

                // if($gst_type=="igst"){

                //     $discount_amount = ($comman_rate * $discount)/100;
                //     $product_rate = $comman_rate - $discount_amount;
                //     $amount = $product_rate * $qty;

                //     $igst = $gst;
                //     $igst_amount = $amount*$igst/100;

                // }
                    $insertData['customer_id'] = $this->request->getPost('customer_id');
                    $insertData['order_id'] = $order_id;
                    $insertData['invoice_no'] = $this->request->getPost('invoice_number');
                    $insertData['po_no'] = $this->request->getPost('po_no');
                    $insertData['product_id'] = $product_id;
                    $insertData['product_rate'] = $product_rate;
                    $insertData['product_quantity'] = $qty;
                    $insertData['discount'] = $discount;
                    $insertData['unit'] = $unit;
                    // $insertData['sgst'] = $sgst;
                    // $insertData['sgst_amount'] = $sgst_amount;
                    // $insertData['cgst'] = $cgst;
                    // $insertData['cgst_amount'] = $cgst_amount;
                    // $insertData['igst'] = $igst;
                    // $insertData['igst_amount'] = $igst_amount;
                    $insertData['product_amount'] = $amount;
                    $insertData['invoice_date'] = date('Y-m-d');
                    $insertData['po_date'] = $this->request->getPost('po_date');
                    $insertData['invoice_month'] = date('m');
                    $insertData['invoice_year'] = date('Y');
                    $insertData['hsn_code'] = $hsn_code;
                    $insertData['is_del'] = 'approved';

                    $model = new CustomerOrder1();
                    $model->where('order_id',$order_id)
                          ->where('is_del','approved')
                          ->insert($insertData);

                    $quantity = $stock - $qty;
                    $stockUpdate = new ProductModel();
                    $stockUpdate->where('id', $product_id)->where('is_del', 'approved')->set('opening_stock', $quantity)->update();

                    $response['status'] = 1;
                    $response['order_id'] = $order_id;
            }
        }else{

                $response['status'] = 0;
                $response['invoice_number'] = $validation->getError('invoice_number');
                $response['po_no'] = $validation->getError('po_no');
                $response['po_date'] = $validation->getError('po_date');
                $response['invoice_date'] = $validation->getError('invoice_date');

        }

        return $this->response->setJSON($response);
    }

    public function edit_customer_order_bill_nongst($id)
    {
        $model = new CustomerOrder1();
        $data['sale'] = $model->where('order_id',$id)->where('is_del', 'approved')->find();
        return view('Admin/EditInvoice/Edit_customer_order_bill_nongst',$data);
    }

    public function save_edit_customer_bill_nongst()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('invoice_no', 'Invoice Number', 'required');
        $validation->setRule('product_amount', 'Product Amount', 'required');

        if ($validation->withRequest($this->request)->run()) {

            $data['customer_id'] = $this->request->getPost('customer_id');
            $order_id = $this->request->getPost('order_id');
            $data['product_rate'] = $this->request->getPost('product_rate');
            $data['unit'] = $this->request->getPost('unit');

            $data['invoice_date'] = $this->request->getPost('invoice_date');
            $data['po_date'] = $this->request->getPost('po_date');
            $data['invoice_month'] = $this->request->getPost('invoice_month');
            $data['invoice_year'] = $this->request->getPost('invoice_year');
            $data['hsn_code'] = $this->request->getPost('hsn_code');
            $data['discount'] = $this->request->getPost('discount');

            $data['invoice_no'] = $this->request->getPost('invoice_no');
            $data['product_amount'] = $this->request->getPost('product_amount');
            $data['paid_amount'] = 0;
            $data['remaining_amount'] = $this->request->getPost('product_amount');
            $data['is_del'] = 'approved';

            $model = new CustomerBill1();
            $model->where('order_id',$order_id)
                  ->set($data)
                  ->update();
           
            


            $response['status'] = 1;
            $response['message'] = 'Bill added successfully!';
            $response['order_id'] = $order_id;
        }else{

            $response['status'] = 0;
            $response['invoice_no'] = $validation->getError('invoice_no');
            $response['product_amount'] = $validation->getError('product_amount');
        }

            return $this->response->setJSON($response);
    }

    public function delete_customer_nongst_product($id, $order_id)
    {
        $productorder = new CustomerOrder1();
        $product = $productorder->where('id',$id)
                         ->where('order_id',$order_id)
                         ->first();

        $product_order_id = $product['order_id'];
        $product_amount1 = $product['product_amount'];


        
        $product_bill = new CustomerBill1();
        $bill = $product_bill->where('order_id',$product_order_id)
                             ->first();
         
        $product_amount2 = $bill['product_amount'];
        $remain_amount2 = $bill['remaining_amount'];

        $tot_product_amount = ($product_amount2) - ($product_amount1);


        $update_bill = new CustomerBill1();
        $final = $update_bill->where('order_id',$order_id)
                             ->set('product_amount',$tot_product_amount)
                             ->set('remaining_amount',$tot_product_amount)
                             ->update();


            $model = new CustomerOrder1();
            $delete = $model->where('order_id',$order_id)
                            ->where('id',$id)
                            ->set('is_del','deleted')
                            ->update();

                          
            if($delete){
                $response['status'] = 1;
                $response['order_id'] = $order_id;
                $response['message'] = "Product Deleted Successfully...!";
            }else{
                $response['status'] = 0;
                $response['order_id'] = $order_id;
                $response['message'] = "Product Deleted Failed...!";
            }
            return $this->response->setJSON($response);
    }

    public function delete_customer_invoice_bill_nongst($id)
    {
        $model = new CustomerBill1();
        $delete = $model->where('order_id',$id)
                        ->set('is_del','deleted')
                        ->update();

                          
            if($delete){
                $response['status'] = 1;
                $response['order_id'] = $id;
                $response['message'] = "Bill Deleted Successfully...!";
            }else{
                $response['status'] = 0;
                $response['order_id'] = $id;
                $response['message'] = "Bill Deleted Failed...!";
            }
            return $this->response->setJSON($response);
    }
}