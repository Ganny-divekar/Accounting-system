<?php

namespace App\Controllers\Predefine;

use App\Controllers\BaseController;

class Predefine extends BaseController
{
    public function predefine_account()
    {
        return view('Admin/Predefine/View_predefine_account');
    }
}