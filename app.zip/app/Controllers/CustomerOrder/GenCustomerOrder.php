<?php

namespace App\Controllers\CustomerOrder;

use App\Controllers\BaseController;
use App\Models\Vendor\VendorModel;
use App\Models\Product\ProductModel;
use App\Models\Vendor\PurchaseOrder;
use App\Models\Vendor\PurchaseBill;
use App\Models\Customer\CustomerModel;
use App\Models\Customer\CustomerOrder;
use App\Models\Customer\CustomerBill;


class GenCustomerOrder extends BaseController
{

    public function generate_customer_order()
    {
        $model = new CustomerModel();
        $data['customer'] = $model->where('is_del','approved')
                                  ->findAll();

        $model = new ProductModel();
        $data['product'] = $model->where('is_del','approved')->findAll();

        $model = new CustomerOrder();
        $last = $model->orderBy('invoice_no', 'DESC')->first();

        if($last){
            $lastNo = $last['invoice_no'];
            $num = (int) substr($lastNo, 3);
            $data['invoice_no'] = 'INV' .str_pad($num + 1, 6, '0', STR_PAD_LEFT);
        }else{
            $data['invoice_no'] = 'INV000001';
        }

        return view('Admin/CustomerOrder/view_customer_order',$data);
    }

    public function customer_order_save()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('invoice_number', 'Invoice Number', 'required');
        $validation->setRule('po_no', 'PO Number', 'required');
        $validation->setRule('po_date', 'PO Date', 'required');
        $validation->setRule('invoice_date', 'Invoice Date', 'required');

        if ($validation->withRequest($this->request)->run()) {

                $order_id = rand(1000,9999).date('Ymd');

                $products   = $this->request->getPost('product');
                $qtys       = $this->request->getPost('qty');
                $rates      = $this->request->getPost('rate');
                $discounts  = $this->request->getPost('discount');
                $gst_type = $this->request->getPost('gst_type');

            foreach($products as $key=>$product){

                $user_rate = $rates[$key];
                $qty  = $qtys[$key];
                $discount = $discounts[$key];

                $sgst_amount = 0;
                $cgst_amount = 0;
                $igst_amount = 0;

                $Productmodel = new ProductModel();
                $product = $Productmodel->find($products[$key]);

                $rate = $product['purchase_price'];
                $stock = $product['opening_stock'];
                $gst = $product['gst_percentage'];
                $hsn_code = $product['hsn_code'];
                $product_id = $product['id'];
                $unit = $product['unit'];

                $sgst = $gst/2;
                $cgst = $gst/2;
                $igst = $gst;

                if($user_rate>0){
                    $comman_rate = $user_rate;
                }else{
                    $comman_rate = $rate;
                }

                if($gst_type=="sgst_cgst"){

                    $discount_amount = ($comman_rate * $discount)/100;
                    $product_rate = $comman_rate - $discount_amount;
                    $amount = $product_rate * $qty;
           
                    $sgst_amount = $amount*$sgst/100;
                    $cgst_amount = $amount*$cgst/100;

                }

                if($gst_type=="igst"){

                    $discount_amount = ($comman_rate * $discount)/100;
                    $product_rate = $comman_rate - $discount_amount;
                    $amount = $product_rate * $qty;

                    $igst = $gst;
                    $igst_amount = $amount*$igst/100;

                }

                    $insertData['customer_id'] = $this->request->getPost('customer_name');
                    $insertData['order_id'] = $order_id;
                    $insertData['invoice_no'] = $this->request->getPost('invoice_number');
                    $insertData['po_no'] = $this->request->getPost('po_no');
                    $insertData['product_id'] = $product_id;
                    $insertData['product_rate'] = $product_rate;
                    $insertData['product_quantity'] = $qty;
                    $insertData['discount'] = $discount;
                    $insertData['unit'] = $unit;
                    $insertData['sgst'] = $sgst;
                    $insertData['sgst_amount'] = $sgst_amount;
                    $insertData['cgst'] = $cgst;
                    $insertData['cgst_amount'] = $cgst_amount;
                    $insertData['igst'] = $igst;
                    $insertData['igst_amount'] = $igst_amount;
                    $insertData['product_amount'] = $amount+$sgst_amount+$cgst_amount+$igst_amount;
                    $insertData['invoice_date'] = date('Y-m-d');
                    $insertData['po_date'] = $this->request->getPost('po_date');
                    $insertData['invoice_month'] = date('m');
                    $insertData['invoice_year'] = date('Y');
                    $insertData['hsn_code'] = $hsn_code;
                    $insertData['is_del'] = 'approved';

                    $model = new CustomerOrder();
                    $model->insert($insertData);

                    $quantity = $stock - $qty;
                    $stockUpdate = new ProductModel();
                    $stockUpdate->where('id', $product_id)->where('is_del', 'approved')->set('opening_stock', $quantity)->update();

                    $response['status'] = 1;
                    $response['order_id'] = $order_id;
            }
        }else{

                $response['status'] = 0;
                $response['invoice_number'] = $validation->getError('invoice_number');
                $response['po_no'] = $validation->getError('po_no');
                $response['po_date'] = $validation->getError('po_date');
                $response['invoice_date'] = $validation->getError('invoice_date');

        }

        return $this->response->setJSON($response);
    }

    public function datewise_customer_order()
    {
        return view('Admin/CustomerOrder/datewise_customer_order');
    }

    public function view_customer_datewise()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('from_date', 'From Date', 'required');
        $validation->setRule('to_date', 'To Date', 'required');

        if (!$validation->withRequest($this->request)->run()) {

           return redirect()->back()->withInput()->with('error', 'Please select From Date and To Date');
        }


            $from_date = $this->request->getPost('from_date');
            $to_date = $this->request->getPost('to_date');


            $model = new CustomerBill();
            $data['customer_order'] = $model->select('customer_bill.*, customer_details.*')
                    ->join('customer_details','customer_details.id = customer_bill.customer_id')
                    ->where('customer_bill.is_del','approved')
                    ->where('invoice_date >=', $from_date)
                    ->where('invoice_date <=', $to_date)
                    ->findAll();

           return view('Admin/PurchaseOrder/view_customer_order_datewise', $data);
    }
    

}