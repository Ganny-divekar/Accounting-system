<?php

namespace App\Controllers\OpeningBalance;

use App\Models\AccountGroup\AccountModel;
use App\Models\OpeningBalance\OpeningModel;
use App\Models\OpeningBalance\BalanceSheetModel;




use App\Controllers\BaseController;

class OpeningBalance extends BaseController
{
    public function opening_balance()
    {
        $model = new AccountModel();    
        $data['account'] = $model->where('is_del','approved')
                                 ->findAll();

        $opening = new OpeningModel();
        $data['balance'] = $opening->select('opening_balance.*, accounts.account_name')
                                   ->join('accounts','accounts.id = opening_balance.account_name','left')
                                   ->where('opening_balance.is_del','approved')
                                   ->findAll();               
        return view('Admin/OpeningBalance/View_opening_balance',$data);
    }

    public function save_opening_balance()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('account_name', 'Customer Name', 'required');
        $validation->setRule('amount', 'Company Name', 'required');
        $validation->setRule('remark', 'Mobile Number', 'required');
        $validation->setRule('payment_mode', 'GST Number', 'required');

        if ($validation->withRequest($this->request)->run()) {

            $data['account_name'] = $this->request->getPost('account_name');
            $data['amount'] = $this->request->getPost('amount');
            $data['remark'] = $this->request->getPost('remark');
            $data['payment_mode'] = $this->request->getPost('payment_mode');
            $data['payment_date'] = date('Y-m-d');
            $month = date('m');
            $year = date('d');


            if($data['payment_mode'] == 'credit'){
                $model = new BalanceSheetModel();
                $model->set('account_name',$data['account_name'])
                      ->set('debit','0')
                      ->set('credit',$data['amount'])
                      ->set('trasaction_type',$data['payment_mode'])
                      ->set('date',$data['payment_date'])
                      ->set('month',$month)
                      ->set('year',$year)
                      ->set('description',$data['remark'])
                      ->insert();
            }else{
                $model = new BalanceSheetModel();
                $model->set('account_name',$data['account_name'])
                      ->set('debit',$data['amount'])
                      ->set('credit','0')
                      ->set('trasaction_type',$data['payment_mode'])
                      ->set('date',$data['payment_date'])
                      ->set('month',$month)
                      ->set('year',$year)
                      ->set('description',$data['remark'])
                      ->insert();
            }

            $model = new OpeningModel();
            $model->insert($data);

            $response['status'] = 1;
            $response['message'] = 'Opening Balance added successfully!';

        }else{
            $response['status'] = 0;
            $response['account_name'] = $validation->getError('account_name');
            $response['remark'] = $validation->getError('remark');
            $response['payment_mode'] = $validation->getError('payment_mode');

        }

         return $this->response->setJSON($response);
    }
}