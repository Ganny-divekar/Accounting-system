<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\Customer\CustomerModel;
use App\Models\Customer\CustomerBill;
use App\Models\Customer\CustomerBill1;
use App\Models\AccountGroup\GroupModel;
use App\Models\AccountGroup\AccountModel;
use App\Models\OpeningBalance\BalanceSheetModel;


use App\Models\Vendor\VendorModel;


class Index extends BaseController
{
    protected $session;
    public function __construct()
    {
        $this->session = session();

        if(!$this->session->get('user_id')){
            header('Location:'.base_url('/'));
            exit;
        }
    }
    public function index()
    {
        $data['user_id'] = $this->session->get('user_id');
        $data['fullname'] = $this->session->get('fullname');
        $data['email'] = $this->session->get('email');

        $customer = new CustomerModel();
        $result = $customer->select('COUNT(id) AS total_customer')
                                     ->where('is_del','approved')
                                     ->get()
                                     ->getRow();
        $data['total_customer'] = $result->total_customer;


        $vendor = new VendorModel();
        $result11 = $vendor->select('COUNT(id) AS total_vendor')
                                     ->where('is_del','approved')
                                     ->get()
                                     ->getRow();

        $data['total_vendor'] = $result11->total_vendor;

        $bill = new CustomerBill();
        $customer = $bill->select('SUM(remaining_amount) AS pending')
                                     ->where('is_del','approved')
                                     ->get()
                                     ->getRow();

        $data['pending'] = $customer->pending;

        $bill11 = new CustomerBill1();
        $customer11 = $bill11->select('SUM(remaining_amount) AS pending')
                                     ->where('is_del','approved')
                                     ->get()
                                     ->getRow();

        $data['pending_non'] = $customer11->pending;

        $sale = new CustomerBill();
        $today = date("Y-m-d");
        $sale_bill = $sale->select('SUM(product_amount) AS total_amount')
                          ->where('invoice_date',$today) 
                          ->where('is_del','approved')
                          ->get()
                          ->getRow();

        $data['total_amount'] = $sale_bill->total_amount;

        $sale11 = new CustomerBill1();
        $today11 = date("Y-m-d");
        $customer11_non = $sale11->select('SUM(product_amount) AS total_amount11')
                                     ->where('invoice_date',$today11) 
                                     ->where('is_del','approved')
                                     ->get()
                                     ->getRow();
        $data['total_amount11'] = $customer11_non->total_amount11;


        $income = new GroupModel();
        $ac_grp = $income->where('is_del','approved')
                         ->where('id','5')
                         ->first();
        $ac_grp_id = $ac_grp['id'];

                        
        $income11 = new AccountModel();
        $ac11_type = $income11->where('is_del','approved')
                              ->where('group_name',$ac_grp_id)
                              ->findAll();

        $ac11_type_id = [];
        foreach($ac11_type as $ac11_type_data){
             $ac11_type_id[] = $ac11_type_data['id'];
        }     
        
        

        $income_bal = new BalanceSheetModel();
        $data['today_income'] = $income_bal->whereIn('account_name',$ac11_type_id)
                                     ->where('is_del','approved')
                                     ->where('date',date('Y-m-d'))
                                     ->findAll();


        $income11 = new GroupModel();
        $ac_grp11 = $income11->where('is_del','approved')
                         ->where('id','5')
                         ->first();
        $ac_grp_id11 = $ac_grp11['id'];

                        
        $income1111 = new AccountModel();
        $ac11_type11 = $income1111->where('is_del','approved')
                              ->where('group_name',$ac_grp_id11)
                              ->findAll();

        $ac11_type_id11 = [];
        foreach($ac11_type11 as $ac11_type_data11){
             $ac11_type_id11[] = $ac11_type_data11['id'];
        }     
        
        

        $income_bal11 = new BalanceSheetModel();
        $data['today_income11'] = $income_bal11->whereIn('account_name',$ac11_type_id)
                                     ->where('is_del','approved')
                                     ->findAll();
                             
                                             
        return view('Admin/index',$data);
    }

    public function backup_database()
    {
        $db = \Config\Database::connect();

        $hostname = $db->hostname;
        $username = $db->username;
        $password = $db->password;
        $database = $db->database;

        $mysqldump = 'C:\\xampp\\mysql\\bin\\mysqldump.exe';

        $backupPath = WRITEPATH . 'backups/';

        if(!is_dir($backupPath)){
            mkdir($backupPath, 0777, true);
        }

        $filename = 'database_backup_' . date('Y-m-d_H-i-s') . ' .sql';
        $filePath = $backupPath.$filename;

        $command = '"' . $mysqldump . '"' .' --host=' . escapeshellarg($hostname) .
                                          ' --user=' . escapeshellarg($username) .
                                          ' --password=' . escapeshellarg($password) .
                                          ' ' .escapeshellarg($database) . ' --result-file='
                                          . escapeshellarg($filePath);
 
        exec($command. $output. $result);

        if($result !== 0 || !file_exists($filePath) || filesize($filePath) == 0){
            return $this->response->setStatusCode(500)->setBody('Database backup failed.');
        }
        return $this->response->download($filePath.null);
                                                
    }
}                                             