<?php

namespace App\Controllers\Reports;

use App\Controllers\BaseController;

use App\Models\Vendor\PurchaseBill;
use App\Models\Vendor\VendorModel;
use App\Models\AccountGroup\GroupModel;
use App\Models\AccountGroup\AccountModel;
use App\Models\OpeningBalance\BalanceSheetModel;
use App\Models\Customer\CustomerModel;
use App\Models\Customer\CustomerBill;
use App\Models\Customer\CustomerOrder;






class Reports extends BaseController
{
    public function view_report()
    {  
        return view('Admin/Reports/View_report');
    }

    public function profit_loss_datewise()
    {
        return view('Admin/Reports/Profit_loss_datewise');
    }

    public function view_profit_loss()
    {
 
            //    INCOME REPORTS
        $account_group = new GroupModel();
        $acc_grp = $account_group->where('is_del','approved')
                                 ->where('id','5')
                                 ->findAll();

        foreach($acc_grp as $grp){
        $acc_grp_id = $grp['id'];
        }

        $accounts = new AccountModel();
        $accs = $accounts->where('is_del','approved')
                                 ->where('group_name',$acc_grp_id)
                                 ->findAll();

        $amount = [];

        foreach($accs as $acc){
        $acc_id = $acc['id'];                       

        $balance = new BalanceSheetModel();
        $result = $balance->select('SUM(debit) AS debit1, SUM(credit) AS credit1')
                              ->where('account_name',$acc_id)
                              ->where('is_del','approved')
                              ->first();

        $credit = $result['credit1'];  
        $debit = $result['debit1']; 
        $balance = $credit-$debit;
        
        $amount[] = [
                'account_name' => $acc['account_name'],
                'balance' => $balance
            ];

        }

        $data['amount'] = $amount;

        //    EXPENSE REPORTS

        $account_group1 = new GroupModel();
        $acc_grp1 = $account_group1->where('is_del','approved')
                                 ->where('id','4')
                                 ->findAll();

        foreach($acc_grp1 as $grp1){
        $acc_grp_id1 = $grp1['id'];
        }         
        
        $accounts1 = new AccountModel();
        $accs1 = $accounts1->where('is_del','approved')
                                 ->where('group_name',$acc_grp_id1)
                                 ->findAll();

        $amount1 = [];     
        
        foreach($accs1 as $acc1){
        $acc_id1 = $acc1['id'];                       

        $balance1 = new BalanceSheetModel();
        $result1 = $balance1->select('SUM(debit) AS debit1, SUM(credit) AS credit1')
                              ->where('account_name',$acc_id1)
                              ->where('is_del','approved')
                              ->first();

        $credit1 = $result1['credit1'];  
        $debit1 = $result1['debit1']; 
        $balance1 = $credit1-$debit1;
        
        $amount1[] = [
                'account_name' => $acc1['account_name'],
                'balance' => $balance1
            ];

        }

        $data['expense'] = $amount1;


        return view('Admin/Reports/View_profit_loss',$data);
    }

    public function trail_sheet_datewise()
    {
        return view('Admin/Reports/Trail_sheet_datewise');
    }

    public function view_trail_sheet()
    {
        $balance = new BalanceSheetModel();
        $result['trail'] = $balance->where('is_del','approved')
                              ->findAll();

        return view('Admin/Reports/View_trail_sheet',$result);
    }

    public function sale_by_customer_datewise()
    {
        $customer = new CustomerModel();
        $data['customer'] = $customer->where('is_del','approved')->findAll();
        return view('Admin/Reports/Sale_by_customer_datewise',$data);
    }

    public function view_sale_by_customer()
    {

        $customer_name = $this->request->getPost('customer_name');
        $from_date = $this->request->getPost('from_date');
        $to_date = $this->request->getPost('to_date');

        $customer = new CustomerBill();
        $data['bill'] = $customer->where('customer_id',$customer_name)
                                 ->where('invoice_date >=',$from_date)
                                 ->where('invoice_date <=',$to_date)
                                 ->findAll();

        return view('Admin/Reports/View_sale_by_customer',$data);
    }

    public function sale_by_item_datewise()
    {
        return view('Admin/Reports/Sale_by_item_datewise');
    }

    public function view_sale_by_item()
    {
        $from_date = $this->request->getPost('from_date');
        $to_date = $this->request->getPost('to_date');

        $customer = new CustomerBill();
        $data['bill'] = $customer->where('invoice_date >=',$from_date)
                                 ->where('invoice_date <=',$to_date)
                                 ->findAll();

                                 
        $order_ids = [];
        foreach($data['bill'] as $customer_bill){
           $order_ids[] = $customer_bill['order_id'];
        }
        

        if(!empty($order_ids)){
            $customer_order = new CustomerOrder();
            $data['order'] = $customer_order->select('customer_order.*, product.product_name')
                                        ->join('product','customer_order.product_id = product.id','left')
                                        ->whereIn('order_id',$order_ids)
                                        ->where('invoice_date >=',$from_date)
                                        ->where('invoice_date <=',$to_date)
                                        ->where('customer_order.is_del','approved')
                                        ->findAll();  
        }else{
            $data['order'] = [];
        }                    
        return view('Admin/Reports/View_sale_by_item',$data);
    }

    public function customer_balance_with_gst_datewise()
    {
        return view('Admin/Reports/Customer_balance_with_gst_datewise');
    }

    public function View_customer_balance_with_gst()
    {
        $from_date = $this->request->getPost('from_date');
        $to_date = $this->request->getPost('to_date');

        $customer = new CustomerBill();
        $data['billing'] = $customer->select('customer_bill.*, customer_details.customer_name')
                                 ->join('customer_details','customer_bill.customer_id = customer_details.id','left')
                                 ->where('invoice_date >=',$from_date)
                                 ->where('invoice_date <=',$to_date)
                                 ->where('customer_bill.is_del','approved')
                                 ->findAll();

         $data['from_date'] = $from_date;
         $data['to_date'] = $to_date;                     



        return view('Admin/Reports/View_customer_balance_with_gst',$data);
    }

    public function purchase_report_datewise()
    {
        return view('Admin/Reports/Purchase_report_datewise');
    }

    public function View_purchase_report()
    {
        $from_date = $this->request->getPost('from_date');
        $to_date = $this->request->getPost('to_date');

        $purchase = new PurchaseBill();
        $data['purchase'] = $purchase->select('purchase_bill.*, vendor_details.vendor_name')
                                 ->join('vendor_details','purchase_bill.customer_id = vendor_details.id','left')
                                 ->where('purchase_date >=',$from_date)
                                 ->where('purchase_date <=',$to_date)
                                 ->where('purchase_bill.is_del','approved')
                                 ->findAll();

        $data['from_date'] = $from_date;
        $data['to_date'] = $to_date;
        return view('Admin/Reports/View_purchase_report',$data);
    }

    public function vendor_wise_purchase_report_datewise()
    {
        $purchase = new VendorModel();
        $data['vendor'] = $purchase->where('is_del','approved')->findAll();
        return view('Admin/Reports/Vendor_wise_purchase_report_datewise',$data);
    }

    public function View_vendor_wise_purchase_report()
    {
        $from_date = $this->request->getPost('from_date');
        $to_date = $this->request->getPost('to_date');
        $vendor_name = $this->request->getPost('vendor_name');

        $purchase = new PurchaseBill();
        $data['purchase'] = $purchase->select('purchase_bill.*, vendor_details.vendor_name')
                                 ->join('vendor_details','purchase_bill.customer_id = vendor_details.id','left')
                                 ->where('purchase_date >=',$from_date)
                                 ->where('purchase_date <=',$to_date)
                                 ->where('customer_id',$vendor_name)
                                 ->where('purchase_bill.is_del','approved')
                                 ->findAll();

        $data['from_date'] = $from_date;
        $data['to_date'] = $to_date;      

        return view('Admin/Reports/View_vendor_wise_purchase_report',$data);
    }

    public function general_ledger_datewise()
    {
        return view('Admin/Reports/General_ledger_datewise');
    }

    public function view_general_ledger()
    {
        $from_date = $this->request->getPost('from_date');
        $to_date = $this->request->getPost('to_date');

        $acc = new AccountModel();
        $accounts = $acc->where('is_del','approved')->findAll();
        
        $amount = [];

        foreach($accounts as $account){
            $account_id = $account['id'];

            $balance = new BalanceSheetModel();
            $result = $balance->select('SUM(debit) AS debit1, SUM(credit) AS credit1,description')
                              ->where('account_name',$account_id)
                              ->where('is_del','approved')
                              ->first();

            $debit = $result['debit1'];
            $credit = $result['credit1'];
            $remark = $result['description'];

            $balance = $credit - $debit;

            $amount[] = [
                'account_name' => $account['account_name'],
                'debit1' => $debit,
                'credit1' => $credit,
                'description' => $remark,
                'balance' => $balance,
                'acc_id' => $account_id,
                'from_date' => $from_date,
                'to_date' => $to_date

            ];

        }

        $data['amount'] = $amount;


        return view('Admin/Reports/View_general_ledger',$data);
    }


    public function view_general_ledger_single($sid,$from_date,$to_date)
    {
        $balance = new BalanceSheetModel();
        $result['balance'] = $balance->select('balance_sheet.*,accounts.account_name')
                                     ->join('accounts','balance_sheet.account_name = accounts.id')
                                     ->where('date >=',$from_date)
                                     ->where('date <=',$to_date)
                                     ->where('balance_sheet.account_name',$sid)
                                     ->where('balance_sheet.is_del','approved')
                                     ->findAll();

                                    //  echo "<pre>";
                                    //  print_r($result['balance']);
                                    //  die();

                          
        return view('Admin/Reports/View_general_ledger_single',$result);
    }

    
    

    
}