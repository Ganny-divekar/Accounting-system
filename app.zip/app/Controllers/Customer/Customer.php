<?php

namespace App\Controllers\Customer;

use App\Models\Customer\CustomerModel;
use App\Models\Product\ProductModel;
use App\Models\Customer\CustomerOrder;
use App\Models\Customer\CustomerBill;
use App\Models\Customer\CustomerOrder1;
use App\Models\Customer\CustomerBill1;
use App\Models\Customer\CustomerHistory;
use App\Models\Customer\CustomerHistory1;



use App\Controllers\BaseController;

class Customer extends BaseController
{
    public function index()
    {

        $model = new CustomerModel();
        $data['customer'] = $model->where('is_del','approved')->findAll();
        return view('Admin/Customer/View_customer',$data);
    }

    public function add_customer()
    {
          return view('Admin/Customer/Add_customer');                      
    }

    public function save_customer()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('customer_name', 'Customer Name', 'required');
        $validation->setRule('company_name', 'Company Name', 'required');
        $validation->setRule('mobile_no', 'Mobile Number', 'required');
        $validation->setRule('gst_no', 'GST Number', 'required');
        $validation->setRule('address', 'Address', 'required');
        $validation->setRule('city', 'City', 'required');
        $validation->setRule('state', 'State', 'required');
        $validation->setRule('pin_code', 'Pin Code', 'required');
        $validation->setRule('payment_term', 'Payment Term', 'required');

        if ($validation->withRequest($this->request)->run()) {

            $data['customer_name'] = $this->request->getPost('customer_name');
            $data['company_name'] = $this->request->getPost('company_name');
            $data['mobile_no'] = $this->request->getPost('mobile_no');
            $data['gst_no'] = $this->request->getPost('gst_no');
            $data['address'] = $this->request->getPost('address');
            $data['city'] = $this->request->getPost('city');
            $data['state'] = $this->request->getPost('state');
            $data['pin_code'] = $this->request->getPost('pin_code');
            $data['payment_term'] = $this->request->getPost('payment_term');

            $model = new CustomerModel();
            $model->insert($data);

            $response['status'] = 1;
            $response['message'] = 'Customer added successfully!';

        }else{
            $response['status'] = 0;
            $response['customer_name'] = $validation->getError('customer_name');
            $response['company_name'] = $validation->getError('company_name');
            $response['mobile_no'] = $validation->getError('mobile_no');
            $response['gst_no'] = $validation->getError('gst_no');
            $response['address'] = $validation->getError('address');
            $response['city'] = $validation->getError('city');
            $response['state'] = $validation->getError('state');
            $response['pin_code'] = $validation->getError('pin_code');
            $response['payment_term'] = $validation->getError('payment_term');

        }

         return $this->response->setJSON($response);

    }

    public function edit_customer($id)
    {
        $model = new CustomerModel();
        $data['customer'] = $model->where('is_del','approved')
                                  ->where('id',$id)
                                  ->first();
        return view('Admin/Customer/Edit_customer',$data);
    }

    public function update_customer()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('customer_name', 'Customer Name', 'required');
        $validation->setRule('company_name', 'Company Name', 'required');
        $validation->setRule('mobile_no', 'Mobile Number', 'required');
        $validation->setRule('gst_no', 'GST Number', 'required');
        $validation->setRule('address', 'Address', 'required');
        $validation->setRule('city', 'City', 'required');
        $validation->setRule('state', 'State', 'required');
        $validation->setRule('pin_code', 'Pin Code', 'required');
        $validation->setRule('payment_term', 'Payment Term', 'required');

        if ($validation->withRequest($this->request)->run()) {

            $id = $this->request->getPost('customer_id');
            $data['customer_name'] = $this->request->getPost('customer_name');
            $data['company_name'] = $this->request->getPost('company_name');
            $data['mobile_no'] = $this->request->getPost('mobile_no');
            $data['gst_no'] = $this->request->getPost('gst_no');
            $data['address'] = $this->request->getPost('address');
            $data['city'] = $this->request->getPost('city');
            $data['state'] = $this->request->getPost('state');
            $data['pin_code'] = $this->request->getPost('pin_code');
            $data['payment_term'] = $this->request->getPost('payment_term');

            $model = new CustomerModel();
            $model->update($id, $data);

            $response['status'] = 1;
            $response['message'] = 'Customer updated successfully!';

        }else{

            $response['status'] = 0;
            $response['customer_name'] = $validation->getError('customer_name');
            $response['company_name'] = $validation->getError('company_name');
            $response['mobile_no'] = $validation->getError('mobile_no');
            $response['gst_no'] = $validation->getError('gst_no');
            $response['address'] = $validation->getError('address');
            $response['city'] = $validation->getError('city');
            $response['state'] = $validation->getError('state');
            $response['pin_code'] = $validation->getError('pin_code');
            $response['payment_term'] = $validation->getError('payment_term');
        }

         return $this->response->setJSON($response);
    }

    public function delete_customer($id)
    {
            $model = new CustomerModel();
            $delete = $model->update($id, ['is_del' => 'deleted']);
            if($delete == true){
                $response['status'] = 1;
            }
            return $this->response->setJSON($response);
    }

    public function customer_order($id)
    {

        $model = new CustomerModel();
        $data['customer'] = $model->find($id);

        $model = new ProductModel();
        $data['product'] = $model->where('is_del','approved')->findAll();

        $model = new CustomerOrder();
        $last = $model->orderBy('invoice_no', 'DESC')->first();

        if($last){
            $lastNo = $last['invoice_no'];
            $num = (int) substr($lastNo, 3);
            $data['invoice_no'] = 'INV' .str_pad($num + 1, 6, '0', STR_PAD_LEFT);
        }else{
            $data['invoice_no'] = 'INV000001';
        }
        
        return view('Admin/Customer/Customer_order',$data);
    }

    public function save_customer_order()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('invoice_number', 'Invoice Number', 'required');
        $validation->setRule('po_no', 'PO Number', 'required');
        $validation->setRule('po_date', 'PO Date', 'required');
        $validation->setRule('invoice_date', 'Invoice Date', 'required');

        if ($validation->withRequest($this->request)->run()) {

                $order_id = rand(1000,9999).date('Ymd');

                $products   = $this->request->getPost('product');
                $qtys       = $this->request->getPost('qty');
                $rates      = $this->request->getPost('rate');
                $discounts  = $this->request->getPost('discount');
                $gst_type = $this->request->getPost('gst_type');

            foreach($products as $key=>$product){

                $user_rate = $rates[$key];
                $qty  = $qtys[$key];
                $discount = $discounts[$key];

                $sgst_amount = 0;
                $cgst_amount = 0;
                $igst_amount = 0;

                $Productmodel = new ProductModel();
                $product = $Productmodel->find($products[$key]);

                $rate = $product['selling_price'];
                $stock = $product['opening_stock'];
                $gst = $product['gst_percentage'];
                $hsn_code = $product['hsn_code'];
                $product_id = $product['id'];
                $unit = $product['unit'];

                $sgst = $gst/2;
                $cgst = $gst/2;
                $igst = $gst;

                
                if($user_rate>0){
                    $comman_rate = $user_rate;
                }else{
                    $comman_rate = $rate;
                }

                if($gst_type=="sgst_cgst"){

                    $discount_amount = ($comman_rate * $discount)/100;
                    $product_rate = $comman_rate - $discount_amount;
                    $amount = $product_rate * $qty;
           
                    $sgst_amount = $amount*$sgst/100;
                    $cgst_amount = $amount*$cgst/100;

                }

                if($gst_type=="igst"){

                    $discount_amount = ($comman_rate * $discount)/100;
                    $product_rate = $comman_rate - $discount_amount;
                    $amount = $product_rate * $qty;

                    $igst = $gst;
                    $igst_amount = $amount*$igst/100;

                }
               
                    $insertData['customer_id'] = $this->request->getPost('customer_id');
                    $insertData['order_id'] = $order_id;
                    $insertData['invoice_no'] = $this->request->getPost('invoice_number');
                    $insertData['po_no'] = $this->request->getPost('po_no');
                    $insertData['product_id'] = $product_id;
                    $insertData['product_rate'] = $product_rate;
                    $insertData['product_quantity'] = $qty;
                    $insertData['discount'] = $discount;
                    $insertData['unit'] = $unit;
                    $insertData['sgst'] = $sgst;
                    $insertData['sgst_amount'] = $sgst_amount;
                    $insertData['cgst'] = $cgst;
                    $insertData['cgst_amount'] = $cgst_amount;
                    $insertData['igst'] = $igst;
                    $insertData['igst_amount'] = $igst_amount;
                    $insertData['product_amount'] = $amount+$sgst_amount+$cgst_amount+$igst_amount;
                    $insertData['invoice_date'] = date('Y-m-d');
                    $insertData['po_date'] = $this->request->getPost('po_date');
                    $insertData['invoice_month'] = date('m');
                    $insertData['invoice_year'] = date('Y');
                    $insertData['hsn_code'] = $hsn_code;
                    $insertData['is_del'] = 'approved';

                    $model = new CustomerOrder();
                    $model->insert($insertData);

                    $quantity = $stock - $qty;
                    $stockUpdate = new ProductModel();
                    $stockUpdate->where('id', $product_id)->where('is_del', 'approved')->set('opening_stock', $quantity)->update();

                    $response['status'] = 1;
                    $response['order_id'] = $order_id;
   
            }
        }else{

                $response['status'] = 0;
                $response['invoice_number'] = $validation->getError('invoice_number');
                $response['po_no'] = $validation->getError('po_no');
                $response['po_date'] = $validation->getError('po_date');
                $response['invoice_date'] = $validation->getError('invoice_date');

        }

                return $this->response->setJSON($response);
    }

    public function customer_order_bill($id)
    {
        $model = new CustomerOrder();
        $data['sale'] = $model->where('order_id',$id)->where('is_del', 'approved')->find();
        return view('Admin/Customer/Customer_order_bill',$data);
    }

    public function save_customer_bill()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('invoice_no', 'Invoice Number', 'required');
        $validation->setRule('product_amount', 'Product Amount', 'required');
        $validation->setRule('sgst', 'SGST', 'required');
        $validation->setRule('sgst_amount', 'Sgst Amount', 'required');
        $validation->setRule('cgst', 'CGST', 'required');
        $validation->setRule('cgst_amount', 'Cgst Amount', 'required');
        $validation->setRule('igst', 'IGST', 'required');
        $validation->setRule('igst_amount', 'Igst Amount', 'required');

        if ($validation->withRequest($this->request)->run()) {

            $data['customer_id'] = $this->request->getPost('customer_id');
            $data['order_id'] = $this->request->getPost('order_id');
            $data['product_rate'] = $this->request->getPost('product_rate');
            $data['unit'] = $this->request->getPost('unit');

            $data['invoice_date'] = $this->request->getPost('invoice_date');
            $data['po_date'] = $this->request->getPost('po_date');
            $data['invoice_month'] = $this->request->getPost('invoice_month');
            $data['invoice_year'] = $this->request->getPost('invoice_year');
            $data['hsn_code'] = $this->request->getPost('hsn_code');
            $data['discount'] = $this->request->getPost('discount');

            $data['invoice_no'] = $this->request->getPost('invoice_no');
            $data['product_amount'] = $this->request->getPost('product_amount');
            $data['sgst'] = $this->request->getPost('sgst');
            $data['sgst_amount'] = $this->request->getPost('sgst_amount');
            $data['cgst'] = $this->request->getPost('cgst');
            $data['cgst_amount'] = $this->request->getPost('cgst_amount');
            $data['igst'] = $this->request->getPost('igst');
            $data['igst_amount'] = $this->request->getPost('igst_amount');
            $data['paid_amount'] = 0;
            $data['remaining_amount'] = $this->request->getPost('product_amount');
            $data['is_del'] = 'approved';

            $model = new CustomerBill();
            $model->insert($data);


            $response['status'] = 1;
            $response['message'] = 'Bill added successfully!';
            $response['order_id'] = $data['order_id'];
        }else{

            $response['status'] = 0;
            $response['invoice_no'] = $validation->getError('invoice_no');
            $response['product_amount'] = $validation->getError('product_amount');
            $response['sgst'] = $validation->getError('sgst');
            $response['sgst_amount'] = $validation->getError('sgst_amount');
            $response['cgst'] = $validation->getError('cgst');
            $response['cgst_amount'] = $validation->getError('cgst_amount');
            $response['igst'] = $validation->getError('igst');
            $response['igst_amount'] = $validation->getError('igst_amount');
        }

            return $this->response->setJSON($response);
    }

    public function customer_bill_pdf($id)
    {
        $model = new CustomerOrder();
        $data['billing'] = $model
                         ->select('customer_order.*, product.*,customer_details.*')
                         ->join('product', 'product.id = customer_order.product_id', 'left')
                         ->join('customer_details','customer_details.id = customer_order.customer_id')
                         ->where('customer_order.order_id',$id)
                         ->where('customer_order.is_del', 'approved')
                         ->findAll();

        return view('Admin/Customer/Customer_bill_pdf',$data);
    }

    public function view_customer_bill($id)
    {
        $model = new CustomerBill();
        $data['history'] = $model->select('customer_bill.*, customer_details.*')
                                 ->join('customer_details', 'customer_details.id = customer_bill.customer_id', 'left')
                                 ->where('customer_bill.customer_id',$id)
                                 ->where('customer_bill.is_del','approved')
                                 ->findAll();
        return view('Admin/Customer/View_customer_bill',$data);
    }

    public function pay_customer_history($id, $customer_id, $order_id)
    {
        $data['id'] = $id;
        $data['customer_id'] = $customer_id;
        $data['order_id'] = $order_id;

        $model = new CustomerBill();
        $data['history'] = $model->where('id',$id)
                                 ->where('customer_id',$customer_id)
                                 ->where('order_id',$order_id)
                                 ->where('is_del','approved')
                                 ->first();

        $select = new CustomerHistory();
        $data['row'] = $select->where('customer_id',$customer_id)
                                    ->where('customer_bill_id',$id)
                                    ->where('order_id',$order_id)
                                    ->findAll();


        return view('Admin/Customer/Pay_customer_history',$data);
    }

    public function save_customer_history()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('tot_remaining_amnt', 'Total Remaining Amount', 'required');
        $validation->setRule('paid_amnt', 'Paid Amount', 'required');
        $validation->setRule('remaining_amount', 'Remaining Amount', 'required');
        $validation->setRule('account_name', 'Account Name', 'required');
        $validation->setRule('payment_type', 'Payment Type', 'required');
        $validation->setRule('payment_date', 'Payment Date', 'required');
        $validation->setRule('reminder_date', 'Reminder Date', 'required');

         if ($validation->withRequest($this->request)->run()) {

            $data['customer_id'] = $this->request->getPost('customer_id');
            $data['customer_bill_id'] = $this->request->getPost('customer_bill_id');
            $data['order_id'] = $this->request->getPost('order_id');

            $data['tot_remaining_amnt'] = $this->request->getPost('tot_remaining_amnt');
            $data['paid_amnt'] = $this->request->getPost('paid_amnt');
            $data['remaining_amount'] = $this->request->getPost('remaining_amount');
            $data['paid_to_account'] = $this->request->getPost('account_name');
            $data['payment_type'] = $this->request->getPost('payment_type');
            $data['payment_date'] = $this->request->getPost('payment_date');
            $data['reminder_date'] = $this->request->getPost('reminder_date');


            $model = new CustomerHistory();
            $model->insert($data);

            $select = new CustomerBill();
            $record = $select->where('id',$data['customer_bill_id'])
                            ->where('customer_id',$data['customer_id'])
                            ->where('order_id',$data['order_id'])
                            ->first();

                        $paid_amount_table = $record['paid_amount'];
                        $remaining_amount_table = $record['remaining_amount'];

                        $tot_paid = $data['paid_amnt'] + $paid_amount_table;
                        $tot_remaining = $remaining_amount_table - $data['paid_amnt'];

            $update = new CustomerBill();
            $update->where('id',$data['customer_bill_id'])
                   ->where('customer_id',$data['customer_id'])
                   ->where('order_id',$data['order_id'])
                   ->set(['paid_amount'=>$tot_paid, 'remaining_amount'=>$tot_remaining])
                   ->update();

            $response['status'] = 1;
            $response['message'] = 'Customer Payment successfully!';
            $response['customer_bill_id'] = $data['customer_bill_id'];
            $response['customer_id'] = $data['customer_id'];
            $response['order_id'] = $data['order_id'];

         }else{

            $response['status'] = 0;
            $response['tot_remaining_amnt'] = $validation->getError('tot_remaining_amnt');
            $response['paid_amnt'] = $validation->getError('paid_amnt');
            $response['remaining_amount'] = $validation->getError('remaining_amount');
            $response['account_name'] = $validation->getError('account_name');
            $response['payment_type'] = $validation->getError('payment_type');
            $response['payment_date'] = $validation->getError('payment_date');
            $response['reminder_date'] = $validation->getError('reminder_date');

         }

            return $this->response->setJSON($response);
    }


    // ----------------------------------------------------------------------------------------------------
    // Without GST Billing

     public function customer_order1($id)
     {
        $model = new CustomerModel();
        $data['customer'] = $model->where('id',$id)
                                  ->where('is_del','approved')
                                  ->first();

        $model = new ProductModel();
        $data['product'] = $model->where('is_del','approved')
                                  ->findAll();

        $model = new CustomerOrder1();
        $last = $model->orderBy('invoice_no', 'DESC')->first();

        if($last){
            $lastNo = $last['invoice_no'];
            $num = (int) substr($lastNo, 3);
            $data['invoice_no'] = 'INV' .str_pad($num + 1, 6, '0', STR_PAD_LEFT);
        }else{
            $data['invoice_no'] = 'INV000001';
        }


        return view('Admin/Customer/Customer_order1',$data);
     }

     public function save_customer_order1()
     {
        $validation = \Config\Services::validation();

        $validation->setRule('invoice_number', 'Invoice Number', 'required');
        $validation->setRule('po_no', 'PO Number', 'required');
        $validation->setRule('po_date', 'PO Date', 'required');
        $validation->setRule('invoice_date', 'Invoice Date', 'required');

        if ($validation->withRequest($this->request)->run()) {

                $order_id = rand(1000,9999).date('Ymd');

                $products   = $this->request->getPost('product');
                $qtys       = $this->request->getPost('qty');
                $rates      = $this->request->getPost('rate');
                $discounts  = $this->request->getPost('discount');
                // $gst_type = $this->request->getPost('gst_type');

            foreach($products as $key=>$product){

                $user_rate = $rates[$key];
                $qty  = $qtys[$key];
                $discount = $discounts[$key];

                // $sgst_amount = 0;
                // $cgst_amount = 0;
                // $igst_amount = 0;

                $Productmodel = new ProductModel();
                $product = $Productmodel->find($products[$key]);

                $rate = $product['purchase_price'];
                $stock = $product['opening_stock'];
                // $gst = $product['gst_percentage'];
                $hsn_code = $product['hsn_code'];
                $product_id = $product['id'];
                $unit = $product['unit'];

                // $sgst = $gst/2;
                // $cgst = $gst/2;
                // $igst = $gst;

                if($user_rate>0){
                    $comman_rate = $user_rate;
                }else{
                    $comman_rate = $rate;
                }

                // if($gst_type=="sgst_cgst"){

                    $discount_amount = ($comman_rate * $discount)/100;
                    $product_rate = $comman_rate - $discount_amount;
                    $amount = $product_rate * $qty;
           
                    // $sgst_amount = $amount*$sgst/100;
                    // $cgst_amount = $amount*$cgst/100;

                // }

                // if($gst_type=="igst"){

                    // $discount_amount = ($comman_rate * $discount)/100;
                    // $product_rate = $comman_rate - $discount_amount;
                    // $amount = $product_rate * $qty;

                    // $igst = $gst;
                    // $igst_amount = $amount*$igst/100;

                // }

                    $insertData['customer_id'] = $this->request->getPost('customer_id');
                    $insertData['order_id'] = $order_id;
                    $insertData['invoice_no'] = $this->request->getPost('invoice_number');
                    $insertData['po_no'] = $this->request->getPost('po_no');
                    $insertData['product_id'] = $product_id;
                    $insertData['product_rate'] = $product_rate;
                    $insertData['product_quantity'] = $qty;
                    $insertData['discount'] = $discount;
                    $insertData['unit'] = $unit;
                    // $insertData['sgst'] = $sgst;
                    // $insertData['sgst_amount'] = $sgst_amount;
                    // $insertData['cgst'] = $cgst;
                    // $insertData['cgst_amount'] = $cgst_amount;
                    // $insertData['igst'] = $igst;
                    // $insertData['igst_amount'] = $igst_amount;
                    $insertData['product_amount'] = $amount;
                    $insertData['invoice_date'] = date('Y-m-d');
                    $insertData['po_date'] = $this->request->getPost('po_date');
                    $insertData['invoice_month'] = date('m');
                    $insertData['invoice_year'] = date('Y');
                    $insertData['hsn_code'] = $hsn_code;
                    $insertData['is_del'] = 'approved';

                    $model = new CustomerOrder1();
                    $model->insert($insertData);

                    $quantity = $stock - $qty;
                    $stockUpdate = new ProductModel();
                    $stockUpdate->where('id', $product_id)->where('is_del', 'approved')->set('opening_stock', $quantity)->update();

                    $response['status'] = 1;
                    $response['order_id'] = $order_id;
            }
        }else{

                $response['status'] = 0;
                $response['invoice_number'] = $validation->getError('invoice_number');
                $response['po_no'] = $validation->getError('po_no');
                $response['po_date'] = $validation->getError('po_date');
                $response['invoice_date'] = $validation->getError('invoice_date');

        }

        return $this->response->setJSON($response);
     }

     public function customer_order_bill1($id)
     {
        $model = new CustomerOrder1();
        $data['sale'] = $model->where('order_id',$id)
                              ->where('is_del','approved')
                              ->find();
        return view('Admin/Customer/customer_order_bill1',$data);
     }

     public function save_customer_bill1()
     {
        $validation = \Config\Services::validation();

        $validation->setRule('invoice_no', 'Invoice Number', 'required');
        $validation->setRule('product_amount', 'Product Amount', 'required');
        // $validation->setRule('sgst', 'SGST', 'required');
        // $validation->setRule('sgst_amount', 'Sgst Amount', 'required');
        // $validation->setRule('cgst', 'CGST', 'required');
        // $validation->setRule('cgst_amount', 'Cgst Amount', 'required');
        // $validation->setRule('igst', 'IGST', 'required');
        // $validation->setRule('igst_amount', 'Igst Amount', 'required');

        if ($validation->withRequest($this->request)->run()) {

            $data['customer_id'] = $this->request->getPost('customer_id');
            $data['order_id'] = $this->request->getPost('order_id');
            $data['product_rate'] = $this->request->getPost('product_rate');
            $data['unit'] = $this->request->getPost('unit');

            $data['invoice_date'] = $this->request->getPost('invoice_date');
            $data['po_date'] = $this->request->getPost('po_date');
            $data['invoice_month'] = $this->request->getPost('invoice_month');
            $data['invoice_year'] = $this->request->getPost('invoice_year');
            $data['hsn_code'] = $this->request->getPost('hsn_code');
            $data['discount'] = $this->request->getPost('discount');

            $data['invoice_no'] = $this->request->getPost('invoice_no');
            $data['product_amount'] = $this->request->getPost('product_amount');
            // $data['sgst'] = $this->request->getPost('sgst');
            // $data['sgst_amount'] = $this->request->getPost('sgst_amount');
            // $data['cgst'] = $this->request->getPost('cgst');
            // $data['cgst_amount'] = $this->request->getPost('cgst_amount');
            // $data['igst'] = $this->request->getPost('igst');
            // $data['igst_amount'] = $this->request->getPost('igst_amount');
            $data['paid_amount'] = 0;
            $data['remaining_amount'] = $this->request->getPost('product_amount');
            $data['is_del'] = 'approved';

            $model = new CustomerBill1();
            $model->insert($data);


            $response['status'] = 1;
            $response['message'] = 'Bill added successfully!';
            $response['order_id'] = $data['order_id'];
        }else{

            $response['status'] = 0;
            $response['invoice_no'] = $validation->getError('invoice_no');
            $response['product_amount'] = $validation->getError('product_amount');
            $response['sgst'] = $validation->getError('sgst');
            $response['sgst_amount'] = $validation->getError('sgst_amount');
            $response['cgst'] = $validation->getError('cgst');
            $response['cgst_amount'] = $validation->getError('cgst_amount');
            $response['igst'] = $validation->getError('igst');
            $response['igst_amount'] = $validation->getError('igst_amount');
        }

            return $this->response->setJSON($response);
     }

     public function customer_bill_pdf1($id)
     {
        $model = new CustomerOrder1();
        $data['billing'] = $model
                         ->select('customer_order1.*, product.*,customer_details.*')
                         ->join('product', 'product.id = customer_order1.product_id', 'left')
                         ->join('customer_details','customer_details.id = customer_order1.customer_id')
                         ->where('customer_order1.order_id',$id)
                         ->where('customer_order1.is_del', 'approved')
                         ->findAll();

        return view('Admin/Customer/Customer_bill_pdf1',$data);
     }

     public function view_customer_bill1($id)
     {
        $model = new CustomerBill1();
        $data['history'] = $model->select('customer_bill1.*, customer_details.customer_name')
                                 ->join('customer_details', 'customer_details.id = customer_bill1.customer_id', 'left')
                                 ->where('customer_bill1.customer_id',$id)
                                 ->where('customer_bill1.is_del','approved')
                                 ->findAll();

                                 
        return view('Admin/Customer/View_customer_bill1',$data);
     }

     public function pay_customer_history1($id, $customer_id, $order_id)
    {
        $data['id'] = $id;
        $data['customer_id'] = $customer_id;
        $data['order_id'] = $order_id;

        $model = new CustomerBill1();
        $data['history'] = $model->where('id',$id)
                                 ->where('customer_id',$customer_id)
                                 ->where('order_id',$order_id)
                                 ->where('is_del','approved')
                                 ->first();

        $select = new CustomerHistory1();
        $data['row'] = $select->where('customer_id',$customer_id)
                                    ->where('customer_bill_id',$id)
                                    ->where('order_id',$order_id)
                                    ->findAll();


        return view('Admin/Customer/Pay_customer_history1',$data);
    }

    public function save_customer_history1()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('tot_remaining_amnt', 'Total Remaining Amount', 'required');
        $validation->setRule('paid_amnt', 'Paid Amount', 'required');
        $validation->setRule('remaining_amount', 'Remaining Amount', 'required');
        $validation->setRule('account_name', 'Account Name', 'required');
        $validation->setRule('payment_type', 'Payment Type', 'required');
        $validation->setRule('payment_date', 'Payment Date', 'required');
        $validation->setRule('reminder_date', 'Reminder Date', 'required');

         if ($validation->withRequest($this->request)->run()) {

            $data['customer_id'] = $this->request->getPost('customer_id');
            $data['customer_bill_id'] = $this->request->getPost('customer_bill_id');
            $data['order_id'] = $this->request->getPost('order_id');

            $data['tot_remaining_amnt'] = $this->request->getPost('tot_remaining_amnt');
            $data['paid_amnt'] = $this->request->getPost('paid_amnt');
            $data['remaining_amount'] = $this->request->getPost('remaining_amount');
            $data['paid_to_account'] = $this->request->getPost('account_name');
            $data['payment_type'] = $this->request->getPost('payment_type');
            $data['payment_date'] = $this->request->getPost('payment_date');
            $data['reminder_date'] = $this->request->getPost('reminder_date');


            $model = new CustomerHistory1();
            $model->insert($data);

            $select = new CustomerBill1();
            $record = $select->where('id',$data['customer_bill_id'])
                            ->where('customer_id',$data['customer_id'])
                            ->where('order_id',$data['order_id'])
                            ->first();

                        $paid_amount_table = $record['paid_amount'];
                        $remaining_amount_table = $record['remaining_amount'];

                        $tot_paid = $data['paid_amnt'] + $paid_amount_table;
                        $tot_remaining = $remaining_amount_table - $data['paid_amnt'];

            $update = new CustomerBill1();
            $update->where('id',$data['customer_bill_id'])
                   ->where('customer_id',$data['customer_id'])
                   ->where('order_id',$data['order_id'])
                   ->set(['paid_amount'=>$tot_paid, 'remaining_amount'=>$tot_remaining])
                   ->update();

            $response['status'] = 1;
            $response['message'] = 'Customer Payment successfully!';
            $response['customer_bill_id'] = $data['customer_bill_id'];
            $response['customer_id'] = $data['customer_id'];
            $response['order_id'] = $data['order_id'];

         }else{

            $response['status'] = 0;
            $response['tot_remaining_amnt'] = $validation->getError('tot_remaining_amnt');
            $response['paid_amnt'] = $validation->getError('paid_amnt');
            $response['remaining_amount'] = $validation->getError('remaining_amount');
            $response['account_name'] = $validation->getError('account_name');
            $response['payment_type'] = $validation->getError('payment_type');
            $response['payment_date'] = $validation->getError('payment_date');
            $response['reminder_date'] = $validation->getError('reminder_date');

         }

            return $this->response->setJSON($response);
    }
}