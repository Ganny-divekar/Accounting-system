<?php

namespace App\Controllers\AccountGroup;

use App\Models\AccountGroup\GroupModel;
use App\Models\AccountGroup\AccountModel;


use App\Controllers\BaseController;

class AccountGroup extends BaseController
{
    public function create_group()
    {
        $model = new GroupModel();
        $data['group'] = $model->where('is_del','approved')->findAll();
        return view('Admin/AccountGroup/Create_group',$data);
    }

    public function view_account()
    {
        $model = new AccountModel();
        $data['account'] = $model->select('accounts.*, account_group.group_name')
                                 ->join('account_group','account_group.id = accounts.group_name','left')
                                 ->where('accounts.is_del','approved')->findAll();
        return view('Admin/AccountGroup/View_account',$data);
    }

    public function add_account()
    {
        $model = new GroupModel();
        $data['group'] = $model->where('is_del','approved')->findAll();
        return view('Admin/AccountGroup/Add_account',$data);
    }

    public function save_account()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('account_name', 'Account Name', 'required');
        $validation->setRule('group_name', 'Group Name', 'required');

        if ($validation->withRequest($this->request)->run()) {

            $data['account_name'] = $this->request->getPost('account_name');
            $data['group_name'] = $this->request->getPost('group_name');

            $group = new GroupModel();
            $grp = $group->where('id',$data['group_name'])
                         ->where('is_del','approved')
                         ->first();

                         $group_name = $grp['group_name'];

            $data['remark'] = $data['account_name'] ."_". $group_name;

            $model = new AccountModel();
            $model->insert($data);

            $response['status'] = 1;
            $response['message'] = 'Account added successfully!';

        }else{
            $response['status'] = 0;
            $response['account_name'] = $validation->getError('account_name');
            $response['group_name'] = $validation->getError('group_name');

        }

         return $this->response->setJSON($response);
    }

    public function edit_account($id)
    {
        $model = new AccountModel();
        $data['account'] = $model->select('accounts.*, account_group.group_name')
                                 ->join('account_group','account_group.id = accounts.group_name','left')
                                 ->where('accounts.id',$id)
                                 ->where('accounts.is_del','approved')
                                 ->first();

        $group = new GroupModel();
        $data['group'] = $group->where('is_del','approved')->findAll();                         
        return view('Admin/AccountGroup/Edit_account',$data);
    }

    public function update_account()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('account_name', 'Account Name', 'required');
        $validation->setRule('group_name', 'Group Name', 'required');

        if ($validation->withRequest($this->request)->run()) {

            $id = $this->request->getPost('id');
            $data['account_name'] = $this->request->getPost('account_name');
            $data['group_name'] = $this->request->getPost('group_name');
            $data['remark'] = $this->request->getPost('remark');

            $group = new GroupModel();
            $grp = $group->where('id',$data['group_name'])
                         ->where('is_del','approved')
                         ->first();

                         $group_name = $grp['group_name'];

            $data['remark'] = $data['account_name'] ."_". $group_name;
            $model = new AccountModel();
            $model->update($id, $data);

            $response['status'] = 1;
            $response['message'] = 'Account added successfully!';

        }else{
            $response['status'] = 0;
            $response['account_name'] = $validation->getError('account_name');
            $response['group_name'] = $validation->getError('group_name');

        }

         return $this->response->setJSON($response);
    }

    public function delete_account($id)
    {
        $model = new AccountModel();
        $delete = $model->update($id, ['is_del' => 'deleted']);
        if($delete == true){
            $response['status'] = 1;
        }
        return $this->response->setJSON($response);
    }
}