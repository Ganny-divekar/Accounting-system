<?php

namespace App\Controllers\PurchaseOrder;

use App\Controllers\BaseController;
use App\Models\Vendor\VendorModel;
use App\Models\Product\ProductModel;
use App\Models\Vendor\PurchaseOrder;
use App\Models\Vendor\PurchaseBill;
use App\Models\Customer\CustomerModel;
use App\Models\Customer\CustomerOrder;
use App\Models\Customer\CustomerBill;


class GenPurchaseOrder extends BaseController
{
    public function generate_purchase_order()
    {
        $model = new VendorModel();
        $data['vendor'] = $model->where('is_del','approved')
              ->findAll();
             
        $product = new ProductModel();
        $data['product'] = $product->where('is_del','approved')
                                         ->findAll();

        $purchase = new PurchaseOrder();
        $last = $purchase->orderBy('purchase_order_no', 'DESC')->first();

        if($last){
            $lastNo = $last['purchase_order_no'];
            $num = (int) substr($lastNo, 2);
            $data['purchase_order_no'] = 'PO' .str_pad($num + 1, 6, '0', STR_PAD_LEFT);
        }else{
            $data['purchase_order_no'] = 'PO000001';
        }
        return view('Admin/PurchaseOrder/Generate_purchase_order',$data);
    }

    public function purchase_order_save()
    {
        
    $validation = \Config\Services::validation();

     $validation->setRule('purchase_order_no', 'Purchase Order No', 'required');
     $validation->setRule('vendor_name', 'Vendor Name', 'required');
     $validation->setRule('work_order_no', 'Work Order No', 'required');
     $validation->setRule('po_date', 'PO Date', 'required');



    if (!$validation->withRequest($this->request)->run()) {

        return $this->response->setJSON([
            'status'=>0,
            'purchase_order_no'=>$validation->getError('purchase_order_no'),
            'vendor_name'=>$validation->getError('vendor_name'),
            'work_order_no'=>$validation->getError('work_order_no'),
            'po_date'=>$validation->getError('po_date'),

        ]);
    }

    $model = new PurchaseOrder();

    $order_id = rand(1000,9999).date('Ymd');

    $products   = $this->request->getPost('product');
    $qtys       = $this->request->getPost('qty');
    $rates      = $this->request->getPost('rate');
    $discounts  = $this->request->getPost('discount');

    $gst_type = $this->request->getPost('gst_type');

    foreach($products as $key=>$product)
    {

        $user_rate = $rates[$key];
        $qty  = $qtys[$key];
        $discount = $discounts[$key];

        $sgst_amount = 0;
        $cgst_amount = 0;
        $igst_amount = 0;

        $Productmodel = new ProductModel();
        $product = $Productmodel->find($products[$key]);    

        $rate = $product['purchase_price'];
        $stock = $product['opening_stock'];
        $gst = $product['gst_percentage'];
        $hsn_code = $product['hsn_code'];
        $product_id = $product['id'];
        $unit = $product['unit'];

        $sgst = $gst/2;
        $cgst = $gst/2;
        $igst = $gst;

       if($user_rate>0){
        $comman_rate = $user_rate;
       }else{
        $comman_rate = $rate;
       }
        if($gst_type=="sgst_cgst")
        {
            $discount_amount = ($comman_rate * $discount)/100;
            $product_rate = $comman_rate - $discount_amount;
            $amount = $product_rate * $qty;
           
            $sgst_amount = $amount*$sgst/100;
            $cgst_amount = $amount*$cgst/100;
        }
        if($gst_type=="igst"){
            $discount_amount = ($comman_rate * $discount)/100;
            $product_rate = $comman_rate - $discount_amount;
            $amount = $product_rate * $qty;

            $igst = $gst;
            $igst_amount = $amount*$igst/100;
        }


        $insertData['customer_id'] = $this->request->getPost('vendor_name');
        $insertData['order_id'] = $order_id;
        $insertData['purchase_order_no'] = $this->request->getPost('purchase_order_no');
        $insertData['product_id'] = $product_id;
        $insertData['product_rate'] = $product_rate;
        $insertData['product_quantity'] = $qty;
        $insertData['discount'] = $discount;
        $insertData['unit'] = $unit;
        $insertData['sgst'] = $sgst;
        $insertData['sgst_amount'] = $sgst_amount;
        $insertData['cgst'] = $cgst;
        $insertData['cgst_amount'] = $cgst_amount;
        $insertData['igst'] = $igst;
        $insertData['igst_amount'] = $igst_amount;
        $insertData['product_amount'] = $amount+$sgst_amount+$cgst_amount+$igst_amount;
        $insertData['purchase_date'] = date('Y-m-d');
        $insertData['purchase_month'] = date('m');
        $insertData['purchase_year'] = date('Y');
        $insertData['po_date'] = $this->request->getPost('po_date');
        $insertData['hsn_code'] = $hsn_code;
        $insertData['is_del'] = 'approved';

        $model->insert($insertData);

        $quantity = $stock + $qty;
        $stockUpdate = new ProductModel();
        $stockUpdate->where('id', $product_id)->where('is_del', 'approved')->set('opening_stock', $quantity)->update();

        
    }

    return $this->response->setJSON([
        'status'=>1,
        'order_id'=>$order_id
    ]);
}

public function datewise_purchase_order()
{
    return view('Admin/PurchaseOrder/View_Purchase_datewise');
}

public function view_purchase_datewise(){
       $validation = \Config\Services::validation();

        $validation->setRule('from_date', 'From Date', 'required');
        $validation->setRule('to_date', 'To Date', 'required');

        if (!$validation->withRequest($this->request)->run()) {

           return redirect()->back()->withInput()->with('error', 'Please select From Date and To Date');
        }


            $from_date = $this->request->getPost('from_date');
            $to_date = $this->request->getPost('to_date');


            $model = new PurchaseBill();
            $data['purchase_order'] = $model->select('purchase_bill.*, vendor_details.*')
                    ->join('vendor_details','vendor_details.id = purchase_bill.customer_id')
                    ->where('purchase_bill.is_del','approved')
                    ->where('po_date >=', $from_date)
                    ->where('po_date <=', $to_date)
                    ->findAll();

           return view('Admin/Vendor/view_purchase_order', $data);
    }

}