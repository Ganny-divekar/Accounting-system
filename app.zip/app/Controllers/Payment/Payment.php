<?php

namespace App\Controllers\Payment;

use App\Controllers\BaseController;
use App\Models\AccountGroup\AccountModel;
use App\Models\Payment\PaymentModel;
use App\Models\OpeningBalance\BalanceSheetModel;



class Payment extends BaseController
{
    public function payment()
    {
                    
        $model = new PaymentModel();
        $data['payment'] = $model->select('expense.*, accounts.account_name')
                                 ->join('accounts','expense.expense_to_account = accounts.id','left')
                                 ->where('expense.is_del','approved')->findAll();
      
        return view('Admin/Payment/View_payment',$data);
    }

    public function add_expense()
    {
        $model = new AccountModel();
        $data['account'] = $model->where('is_del','approved')->findAll();
         
        $acc = new AccountModel();
        $accounts = $acc->where('is_del','approved')->findAll();

        $amount = [];

        foreach($accounts as $account){
            $account_id = $account['id'];

            $balance = new BalanceSheetModel();
            $result = $balance->select('SUM(debit) AS debit1, SUM(credit) AS credit1')
                              ->where('account_name',$account_id)
                              ->where('is_del','approved')
                              ->first();

            $debit = $result['debit1'];
            $credit = $result['credit1'];

            $balance = $credit - $debit;

            $amount[] = [
                'account_name' => $account['account_name'],
                'debit1' => $debit,
                'credit1' => $credit,
                'balance' => $balance
            ];

        }

        $data['amount'] = $amount;

     
                                 
        
        return view('Admin/Payment/Add_payment',$data);
    }

    public function save_expense()
    {
        $validation = \Config\Services::validation();

        $validation->setRule('payment_for', 'Payment For', 'required');
        $validation->setRule('payment_through', 'Payment Trough', 'required');
        $validation->setRule('amount', 'Amount', 'required');
        $validation->setRule('payment_mode', 'Payment Mode', 'required');
        $validation->setRule('person_name', 'Person Name', 'required');
        $validation->setRule('invoice_no', 'Invoice Number', 'required');
        $validation->setRule('remark', 'Remark', 'required');
        $validation->setRule('payment_date', 'Payment Date', 'required');

        if ($validation->withRequest($this->request)->run()) {

            $data['expense_to_account'] = $this->request->getPost('payment_for');
            $data['paid_from_account'] = $this->request->getPost('payment_through');
            $data['amount'] = $this->request->getPost('amount');
            $data['payment_type'] = 'expense';
            $data['payment_mode'] = $this->request->getPost('payment_mode');
            $data['vendor_name'] = $this->request->getPost('person_name');
            $data['invoice_no'] = $this->request->getPost('invoice_no');
            $data['remark'] = $this->request->getPost('remark');
            $data['payment_date'] = $this->request->getPost('payment_date');
            $month = date('m');
            $year = date('Y');

            

            $model = new PaymentModel();
            $model->insert($data);


                $bal1 = new BalanceSheetModel();
                $bal1->set('account_name',$data['expense_to_account'])
                    ->set('debit','0')
                    ->set('credit',$data['amount'])
                    ->set('trasaction_type','credit')
                    ->set('date',$data['payment_date'])
                    ->set('month',$month)
                    ->set('year',$year)
                    ->set('description',$data['remark'])
                    ->insert();

                $bal2 = new BalanceSheetModel();
                $bal2->set('account_name',$data['paid_from_account'])
                    ->set('debit',$data['amount'])
                    ->set('credit','0')
                    ->set('trasaction_type','expense')
                    ->set('date',$data['payment_date'])
                    ->set('month',$month)
                    ->set('year',$year)
                    ->set('description',$data['remark'])
                    ->insert();    

            $response['status'] = 1;
            $response['message'] = 'Customer added successfully!';

        }else{
            $response['status'] = 0;
            $response['payment_for'] = $validation->getError('payment_for');
            $response['payment_through'] = $validation->getError('payment_through');
            $response['amount'] = $validation->getError('amount');
            $response['payment_mode'] = $validation->getError('payment_mode');
            $response['person_name'] = $validation->getError('person_name');
            $response['invoice_no'] = $validation->getError('invoice_no');
            $response['remark'] = $validation->getError('remark');
            $response['payment_date'] = $validation->getError('payment_date');
        }

         return $this->response->setJSON($response);
    }
}