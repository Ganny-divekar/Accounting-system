<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Home::index');
$routes->get('register', 'Home::register');
$routes->get('home', 'Admin\Index::index');
$routes->post('save_register', 'Home::save_register');
$routes->post('login', 'Home::login');
$routes->get('logout', 'Home::logout');


// All Vendor Modules Routes
$routes->get('view_vendor', 'Vendor\Vendor::index');
$routes->get('add_vendor', 'Vendor\Vendor::add_vendor');
$routes->post('save_vendor', 'Vendor\Vendor::save_vendor');
$routes->get('edit_vendor/(:num)', 'Vendor\Vendor::edit_vendor/$1');
$routes->post('update_vendor', 'Vendor\Vendor::update_vendor');
$routes->post('delete_vendor/(:num)', 'Vendor\Vendor::delete_vendor/$1');

$routes->get('purchase_order/(:num)', 'Vendor\Vendor::purchase_order/$1');
$routes->post('save_purchase_order', 'Vendor\Vendor::save_purchase_order');
$routes->get('purchase_order_bill/(:num)', 'Vendor\Vendor::purchase_order_bill/$1');
$routes->post('save_purchase_bill', 'Vendor\Vendor::save_purchase_bill');
$routes->get('purchase_bill_pdf/(:num)', 'Vendor\Vendor::purchase_bill_pdf/$1');
$routes->get('purchase_order_datewise/(:num)', 'Vendor\Vendor::purchase_order_datewise/$1');
$routes->post('view_purchase_order', 'Vendor\Vendor::view_purchase_order');

$routes->get('view_purchase_history/(:num)', 'Vendor\Vendor::view_purchase_history/$1');
$routes->get('pay_purchase_history/(:num)/(:num)/(:num)', 'Vendor\Vendor::pay_purchase_history/$1/$2/$3');
$routes->post('save_purchase_history', 'Vendor\Vendor::save_purchase_history');
$routes->get('purchase_history_pdf/(:num)', 'Vendor\Vendor::purchase_history_pdf/$1');

$routes->get('edit_purchase_order/(:num)', 'Vendor\Vendor::edit_purchase_order/$1');
$routes->post('save_edit_purchase_order', 'Vendor\Vendor::save_edit_purchase_order');
$routes->get('edit_customer_order_bill/(:num)', 'Vendor\Vendor::edit_customer_order_bill/$1');
$routes->post('save_edit_purchase_bill', 'Vendor\Vendor::save_edit_purchase_bill');
$routes->post('delete_purchase_product/(:num)/(:num)', 'Vendor\Vendor::delete_purchase_product/$1/$2');
$routes->get('view_vendor_account/(:num)', 'Vendor\Vendor::view_vendor_account/$1');



// All Products Modules Routes
$routes->get('view_product', 'Product\Product::index');
$routes->get('add_product', 'Product\Product::add_product');
$routes->post('save_product', 'Product\Product::save_product');
$routes->get('edit_product/(:num)', 'Product\Product::edit_product/$1');
$routes->post('update_product', 'Product\Product::update_product');
$routes->post('delete_product/(:num)', 'Product\Product::delete_product/$1');


// All Customers Modules Routes
$routes->get('view_customer', 'Customer\Customer::index');
$routes->get('add_customer', 'Customer\Customer::add_customer');
$routes->post('save_customer', 'Customer\Customer::save_customer');
$routes->get('edit_customer/(:num)', 'Customer\Customer::edit_customer/$1');
$routes->post('update_customer', 'Customer\Customer::update_customer');
$routes->post('delete_customer/(:num)', 'Customer\Customer::delete_customer/$1');


// All Customers order with gst bill Modules Routes
$routes->get('customer_order/(:num)', 'Customer\Customer::customer_order/$1');
$routes->post('save_customer_order', 'Customer\Customer::save_customer_order');
$routes->get('customer_order_bill/(:num)', 'Customer\Customer::customer_order_bill/$1');
$routes->post('save_customer_bill', 'Customer\Customer::save_customer_bill');
$routes->get('customer_bill_pdf/(:num)', 'Customer\Customer::customer_bill_pdf/$1');


$routes->get('view_customer_bill/(:num)', 'Customer\Customer::view_customer_bill/$1');
$routes->get('pay_customer_history/(:num)/(:num)/(:num)/', 'Customer\Customer::pay_customer_history/$1/$2/$3');
$routes->post('save_customer_history', 'Customer\Customer::save_customer_history');


// All Purchase order Modules Routes
$routes->get('generate_purchase_order', 'PurchaseOrder\GenPurchaseOrder::generate_purchase_order');
$routes->post('purchase_order_save', 'PurchaseOrder\GenPurchaseOrder::purchase_order_save');
$routes->get('datewise_purchase_order', 'PurchaseOrder\GenPurchaseOrder::datewise_purchase_order');
$routes->post('view_purchase_datewise', 'PurchaseOrder\GenPurchaseOrder::view_purchase_datewise');


$routes->get('generate_customer_order', 'CustomerOrder\GenCustomerOrder::generate_customer_order');
$routes->post('customer_order_save', 'CustomerOrder\GenCustomerOrder::customer_order_save');
$routes->get('datewise_customer_order', 'CustomerOrder\GenCustomerOrder::datewise_customer_order');
$routes->post('view_customer_datewise', 'CustomerOrder\GenCustomerOrder::view_customer_datewise');


$routes->get('customer_order1/(:num)', 'Customer\Customer::customer_order1/$1');
$routes->post('save_customer_order1', 'Customer\Customer::save_customer_order1');
$routes->get('customer_order_bill1/(:num)', 'Customer\Customer::customer_order_bill1/$1');
$routes->post('save_customer_bill1', 'Customer\Customer::save_customer_bill1');
$routes->get('customer_bill_pdf1/(:num)', 'Customer\Customer::customer_bill_pdf1/$1');

$routes->get('view_customer_bill1/(:num)', 'Customer\Customer::view_customer_bill1/$1');
$routes->get('pay_customer_history1/(:num)/(:num)/(:num)/', 'Customer\Customer::pay_customer_history1/$1/$2/$3');
$routes->post('save_customer_history1', 'Customer\Customer::save_customer_history1');


// All Quotation Modules Routes
$routes->get('customer_quotation/(:num)', 'Quotation\Quotation::customer_quotation/$1');
$routes->post('save_customer_quotation', 'Quotation\Quotation::save_customer_quotation');
$routes->get('customer_quotation_bill/(:num)', 'Quotation\Quotation::customer_quotation_bill/$1');
$routes->post('save_quotation_bill', 'Quotation\Quotation::save_quotation_bill');
$routes->get('quotation_bill_pdf/(:num)', 'Quotation\Quotation::quotation_bill_pdf/$1');
$routes->get('view_quotation_datewise', 'Quotation\Quotation::view_quotation_datewise');
$routes->post('view_gst_quotation', 'Quotation\Quotation::view_gst_quotation');
$routes->get('customer_quotation_non_gst/(:num)', 'Quotation\Quotation::customer_quotation_non_gst/$1');
$routes->post('save_customer_quotation_nongst', 'Quotation\Quotation::save_customer_quotation_nongst');
$routes->get('customer_quotation_nongst_bill/(:num)', 'Quotation\Quotation::customer_quotation_nongst_bill/$1');
$routes->post('save_quotation_bill_nongst', 'Quotation\Quotation::save_quotation_bill_nongst');
$routes->get('quotation_nongst_bill_pdf/(:num)', 'Quotation\Quotation::quotation_nongst_bill_pdf/$1');
$routes->get('view_quotation_nongst_datewise', 'Quotation\Quotation::view_quotation_nongst_datewise');
$routes->post('view_nongst_quotation', 'Quotation\Quotation::view_nongst_quotation');



// All Edit Invoice Modules Routes
$routes->get('view_invoice_gst_datewise', 'EditInvoice\EditInvoice::view_invoice_gst_datewise');
$routes->post('view_invoice_gst', 'EditInvoice\EditInvoice::view_invoice_gst');
$routes->get('edit_customer_invoice/(:num)', 'EditInvoice\EditInvoice::edit_customer_invoice/$1');
$routes->post('save_edit_customer_invoice', 'EditInvoice\EditInvoice::save_edit_customer_invoice');
$routes->get('edit_customer_order_bill/(:num)', 'EditInvoice\EditInvoice::edit_customer_order_bill/$1');
$routes->post('save_edit_customer_bill', 'EditInvoice\EditInvoice::save_edit_customer_bill');
$routes->post('delete_customer_product/(:num)/(:num)/', 'EditInvoice\EditInvoice::delete_customer_product/$1/$2');
$routes->post('delete_customer_invoice_bill/(:num)', 'EditInvoice\EditInvoice::delete_customer_invoice_bill/$1');


$routes->get('view_invoice_nongst_datewise', 'EditInvoice\EditInvoice::view_invoice_nongst_datewise');
$routes->post('view_invoice_nongst', 'EditInvoice\EditInvoice::view_invoice_nongst');
$routes->get('edit_customer_invoice_nongst/(:num)', 'EditInvoice\EditInvoice::edit_customer_invoice_nongst/$1');
$routes->post('save_edit_customer_invoice_nongst', 'EditInvoice\EditInvoice::save_edit_customer_invoice_nongst');
$routes->get('edit_customer_order_bill_nongst/(:num)', 'EditInvoice\EditInvoice::edit_customer_order_bill_nongst/$1');
$routes->post('save_edit_customer_bill_nongst', 'EditInvoice\EditInvoice::save_edit_customer_bill_nongst');
$routes->post('delete_customer_nongst_product/(:num)/(:num)/', 'EditInvoice\EditInvoice::delete_customer_nongst_product/$1/$2');
$routes->post('delete_customer_invoice_bill_nongst/(:num)', 'EditInvoice\EditInvoice::delete_customer_invoice_bill_nongst/$1');


// All Expense / Accounts Module Routes
//         Create Group
$routes->get('create_group', 'AccountGroup\AccountGroup::create_group');

//         Create Account
$routes->get('view_account', 'AccountGroup\AccountGroup::view_account');
$routes->get('add_account', 'AccountGroup\AccountGroup::add_account');
$routes->post('save_account', 'AccountGroup\AccountGroup::save_account');
$routes->get('edit_account/(:num)', 'AccountGroup\AccountGroup::edit_account/$1');
$routes->post('update_account', 'AccountGroup\AccountGroup::update_account');
$routes->post('delete_account/(:num)', 'AccountGroup\AccountGroup::delete_account/$1');

//         Predefine Account
$routes->get('predefine_account', 'Predefine\Predefine::predefine_account');

//         Opening Balance
$routes->get('opening_balance', 'OpeningBalance\OpeningBalance::opening_balance');
$routes->post('save_opening_balance', 'OpeningBalance\OpeningBalance::save_opening_balance');

//         Transfer Amount
$routes->get('transfer_amount', 'TransferAmount\TransferAmount::transfer_amount');
$routes->post('save_transfer_amount', 'TransferAmount\TransferAmount::save_transfer_amount');

//         Payment
$routes->get('payment', 'Payment\Payment::payment');
$routes->get('add_expense', 'Payment\Payment::add_expense');
$routes->post('save_expense', 'Payment\Payment::save_expense');

//         Reports
$routes->get('view_report', 'Reports\Reports::view_report');
$routes->get('profit_loss_datewise', 'Reports\Reports::profit_loss_datewise');
$routes->post('view_profit_loss', 'Reports\Reports::view_profit_loss');

$routes->get('trail_sheet_datewise', 'Reports\Reports::trail_sheet_datewise');
$routes->post('view_trail_sheet', 'Reports\Reports::view_trail_sheet');


$routes->get('sale_by_customer_datewise', 'Reports\Reports::sale_by_customer_datewise');
$routes->post('view_sale_by_customer', 'Reports\Reports::view_sale_by_customer');


$routes->get('sale_by_item_datewise', 'Reports\Reports::sale_by_item_datewise');
$routes->post('view_sale_by_item', 'Reports\Reports::view_sale_by_item');

$routes->get('customer_balance_with_gst_datewise', 'Reports\Reports::customer_balance_with_gst_datewise');
$routes->post('View_customer_balance_with_gst', 'Reports\Reports::View_customer_balance_with_gst');

$routes->get('purchase_report_datewise', 'Reports\Reports::purchase_report_datewise');
$routes->post('View_purchase_report', 'Reports\Reports::View_purchase_report');

$routes->get('vendor_wise_purchase_report_datewise', 'Reports\Reports::vendor_wise_purchase_report_datewise');
$routes->post('View_vendor_wise_purchase_report', 'Reports\Reports::View_vendor_wise_purchase_report');

$routes->get('general_ledger_datewise', 'Reports\Reports::general_ledger_datewise');
$routes->post('view_general_ledger', 'Reports\Reports::view_general_ledger');

$routes->get('view_general_ledger_single/(:num)/(:any)/(:any)', 'Reports\Reports::view_general_ledger_single/$1/$2/$3');

$routes->get('backup_database', 'Admin\Index::backup_database');

