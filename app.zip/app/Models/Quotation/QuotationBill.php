<?php

namespace App\Models\Quotation;
use CodeIgniter\Model;

class QuotationBill extends Model
{
    protected $table = 'quotation_bill';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';

    protected $allowedFields = [
        'customer_id',
        'order_id',
        'quotation_no',
        'product_rate',
        'unit',
        'sgst',
        'sgst_amount',
        'cgst',
        'cgst_amount',
        'igst',
        'igst_amount',
        'product_amount',
        'paid_amount',
        'remaining_amount',
        'quotation_date',
        'quotation_month',
        'quotation_year',
        'hsn_code',
        'discount',
        'is_del'
    ];

   
}