<?php

namespace App\Models\Quotation;
use CodeIgniter\Model;

class CustomerQuotation extends Model
{
    protected $table = 'customer_quotation';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';

    protected $allowedFields = [
        'customer_id',
        'order_id',
        'quotation_no',
        'product_id',
        'product_rate',
        'product_quantity',
        'unit',
        'sgst',
        'sgst_amount',
        'cgst',
        'cgst_amount',
        'igst',
        'igst_amount',
        'product_amount',
        'quotation_date',
        'quotation_month',
        'quotation_year',
        'hsn_code',
        'discount',
        'is_del'
    ];

   
}