<?php

namespace App\Models\Product;
use CodeIgniter\Model;

class ProductModel extends Model
{
    protected $table = 'product';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';

    protected $allowedFields = [
        'product_name',
        'product_code',
        'barcode',
        'hsn_code',
        'unit',
        'gst_percentage',
        'purchase_price',
        'selling_price',
        'opening_stock',
        'reminder_stock',
        'description',
        'created_date',
        'is_del'
    ];

   
}