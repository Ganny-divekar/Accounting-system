<?php

namespace App\Models\AccountGroup;
use CodeIgniter\Model;

class AccountModel extends Model
{
    protected $table = 'accounts';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';

    protected $allowedFields = [
        'account_name',
        'group_name',
        'remark',
        'is_del'
    ];

   
}