<?php

namespace App\Models\AccountGroup;
use CodeIgniter\Model;

class GroupModel extends Model
{
    protected $table = 'account_group';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';

    protected $allowedFields = [
        'group_name',
        'remark',
        'is_del'
    ];

   
}