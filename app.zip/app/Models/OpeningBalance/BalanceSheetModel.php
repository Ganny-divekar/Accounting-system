<?php

namespace App\Models\OpeningBalance;
use CodeIgniter\Model;

class BalanceSheetModel extends Model
{
    protected $table = 'balance_sheet';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';

    protected $allowedFields = [
        'account_name',
        'debit',
        'credit',
        'trasaction_type',
        'date',
        'month',
        'year',
        'description',
        'is_del'
    ];

   
}