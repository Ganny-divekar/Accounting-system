<?php

namespace App\Models\OpeningBalance;
use CodeIgniter\Model;

class OpeningModel extends Model
{
    protected $table = 'opening_balance';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';

    protected $allowedFields = [
        'account_name',
        'amount',
        'payment_mode',
        'payment_date',
        'is_del'
    ];

   
}