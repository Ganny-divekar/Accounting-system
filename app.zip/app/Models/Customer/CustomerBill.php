<?php

namespace App\Models\Customer;
use CodeIgniter\Model;

class CustomerBill extends Model
{
    protected $table = 'customer_bill';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';

    protected $allowedFields = [
        'customer_id',
        'order_id',
        'invoice_no',
        'product_rate',
        'unit',
        'sgst',
        'sgst_amount',
        'cgst',
        'cgst_amount',
        'igst',
        'igst_amount',
        'product_amount',
        'paid_amount',
        'remaining_amount',
        'invoice_date',
        'po_date',
        'invoice_month',
        'invoice_year',
        'hsn_code',
        'discount',
        'is_del'
    ];

   
}