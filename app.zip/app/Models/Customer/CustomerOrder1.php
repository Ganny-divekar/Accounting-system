<?php

namespace App\Models\Customer;
use CodeIgniter\Model;

class CustomerOrder1 extends Model
{
    protected $table = 'customer_order1';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';

    protected $allowedFields = [
        'customer_id',
        'order_id',
        'invoice_no',
        'po_no',
        'product_id',
        'product_rate',
        'product_quantity',
        'unit',
        'product_amount',
        'invoice_date',
        'po_date',
        'invoice_month',
        'invoice_year',
        'hsn_code',
        'discount',
        'is_del'
    ];

   
}