<?php

namespace App\Models\Customer;
use CodeIgniter\Model;

class CustomerHistory1 extends Model
{
    protected $table = 'customer_payment_history1';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';

    protected $allowedFields = [
        'customer_id',
        'customer_bill_id',
        'order_id',
        'tot_remaining_amnt',
        'paid_amnt',
        'remaining_amount',
        'paid_to_account',
        'payment_type',
        'cheque_no',
        'bank_name',
        'credit_card_last_four_digit',
        'transaction_id',
        'finance_card_last_four_digit',
        'transaction_id1',
        'transaction_no',
        'bank_name1',
        'payment_date',
        'reminder_date',
        'is_del'
    ];

   
}