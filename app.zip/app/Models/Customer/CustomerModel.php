<?php

namespace App\Models\Customer;
use CodeIgniter\Model;

class CustomerModel extends Model
{
    protected $table = 'customer_details';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';

    protected $allowedFields = [
        'customer_name',
        'company_name',
        'mobile_no',
        'gst_no',
        'address',
        'city',
        'state',
        'pin_code',
        'payment_term',
        'is_del'
    ];

   
}