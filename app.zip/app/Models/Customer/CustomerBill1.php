<?php

namespace App\Models\Customer;
use CodeIgniter\Model;

class CustomerBill1 extends Model
{
    protected $table = 'customer_bill1';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';

    protected $allowedFields = [
        'customer_id',
        'order_id',
        'invoice_no',
        'product_rate',
        'unit',
        'product_amount',
        'paid_amount',
        'remaining_amount',
        'invoice_date',
        'po_date',
        'invoice_month',
        'invoice_year',
        'hsn_code',
        'discount',
        'is_del'
    ];

   
}