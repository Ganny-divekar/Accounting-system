<?php

namespace App\Models\Payment;
use CodeIgniter\Model;

class PaymentModel extends Model
{
    protected $table = 'expense';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';

    protected $allowedFields = [
        'vendor_name',
        'amount',
        'expense_to_account',
        'paid_from_account',
        'payment_type',
        'payment_mode',
        'cheque_no',
        'bank_name',
        'credit_card_last_four_digit',
        'transaction_id',
        'finance_card_last_four_digit',
        'transaction_id1',
        'transaction_no',
        'bank_name1',
        'payment_date',
        'invoice_no',
        'remark',
        'is_del'
    ];

   
}