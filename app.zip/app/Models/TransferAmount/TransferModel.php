<?php

namespace App\Models\TransferAmount;
use CodeIgniter\Model;

class TransferModel extends Model
{
    protected $table = 'transfer_amount';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';

    protected $allowedFields = [
        'from_account',
        'to_account',
        'amount',
        'payment_mode',
        'payment_date',
        'remark',
        'is_del'
    ];
}