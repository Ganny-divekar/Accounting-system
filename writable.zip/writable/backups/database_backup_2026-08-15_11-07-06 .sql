-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: billing_system
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account_group`
--

DROP TABLE IF EXISTS `account_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_group` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `remark` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL DEFAULT 'approved',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_group`
--

LOCK TABLES `account_group` WRITE;
/*!40000 ALTER TABLE `account_group` DISABLE KEYS */;
INSERT INTO `account_group` VALUES (1,'Current Asset','Asset','approved'),(2,'Current Liabilities','Liabilities','approved'),(3,'Equity','Equity','approved'),(4,'Expense','Expense','approved'),(5,'Income','Income','approved');
/*!40000 ALTER TABLE `account_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `account_name` varchar(100) NOT NULL,
  `group_name` varchar(100) NOT NULL,
  `remark` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL DEFAULT 'approved',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (1,'Ganesh Divekar','5','Ganesh Divekar_Current Asset','approved'),(6,'Swapnill Divekar','4','Swapnill Divekar_Expense','approved'),(7,'Kajal Divekar','5','Kajal Divekar_Income','approved');
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `balance_sheet`
--

DROP TABLE IF EXISTS `balance_sheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance_sheet` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `account_name` varchar(100) NOT NULL,
  `debit` varchar(100) NOT NULL,
  `credit` varchar(100) NOT NULL,
  `trasaction_type` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `month` varchar(100) NOT NULL,
  `year` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL DEFAULT 'approved',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance_sheet`
--

LOCK TABLES `balance_sheet` WRITE;
/*!40000 ALTER TABLE `balance_sheet` DISABLE KEYS */;
INSERT INTO `balance_sheet` VALUES (1,'1','0','500','credit','2026-08-11','08','11','travel','approved'),(2,'6','500','0','expense','2026-08-11','08','11','Ganesh_Divekar_Current Asset','approved'),(3,'6','0','1500','credit','2026-08-11','08','13','','approved'),(4,'1','1500','0','expense','2026-08-11','08','13','','approved'),(5,'6','0','1500','credit','2026-08-11','08','2026','','approved'),(6,'1','1500','0','expense','2026-08-11','08','2026','','approved'),(7,'6','0','1500','expense','2026-08-11','08','2026','','approved'),(8,'1','1500','0','expense','2026-08-11','08','2026','','approved'),(9,'6','0','1500','credit','2026-08-11','08','2026','','approved'),(10,'1','1500','0','expense','2026-08-11','08','2026','','approved'),(11,'6','0','1500','credit','2026-08-11','08','2026','Salary','approved'),(12,'1','1500','0','expense','2026-08-11','08','2026','Salary','approved'),(13,'1','0','1500','credit','2026-08-11','08','2026','Salary','approved'),(14,'6','1500','0','expense','2026-08-11','08','2026','Salary','approved'),(15,'6','0','500','credit','2026-08-11','08','2026','Salary','approved'),(16,'1','500','0','expense','2026-08-11','08','2026','Salary','approved'),(17,'1','0','50000','credit','2026-08-11','08','13','Ganesh_Divekar','approved'),(18,'7','0','5000','credit','2026-08-11','08','2026','Salary','approved'),(19,'6','5000','0','expense','2026-08-11','08','2026','Salary','approved');
/*!40000 ALTER TABLE `balance_sheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_bill`
--

DROP TABLE IF EXISTS `customer_bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_bill` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(100) NOT NULL,
  `order_id` varchar(100) NOT NULL,
  `invoice_no` varchar(100) NOT NULL,
  `product_rate` varchar(100) NOT NULL,
  `unit` varchar(100) NOT NULL,
  `sgst` varchar(100) NOT NULL,
  `sgst_amount` varchar(100) NOT NULL,
  `cgst` varchar(100) NOT NULL,
  `cgst_amount` varchar(100) NOT NULL,
  `igst` varchar(100) NOT NULL,
  `igst_amount` varchar(100) NOT NULL,
  `product_amount` varchar(100) NOT NULL,
  `paid_amount` varchar(100) NOT NULL,
  `remaining_amount` varchar(100) NOT NULL,
  `invoice_date` varchar(100) NOT NULL,
  `po_date` varchar(100) NOT NULL,
  `invoice_month` varchar(100) NOT NULL,
  `invoice_year` varchar(100) NOT NULL,
  `hsn_code` varchar(100) NOT NULL,
  `discount` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_bill`
--

LOCK TABLES `customer_bill` WRITE;
/*!40000 ALTER TABLE `customer_bill` DISABLE KEYS */;
INSERT INTO `customer_bill` VALUES (1,'1','519620260805','INV000002','20000','Nos','9','3600','9','3600','18','0','47200','0','47200','2026-08-05','2026-08-02','08','2026','5645645','0','approved'),(2,'1','322820260805','INV000003','10000','Nos','9','31950','9','31950','18','0','418900','0','418900','2026-08-05','2026-08-05','08','2026','749858','0','approved'),(3,'1','615520260805','INV000004','8550','Nos','9','3847.5','9','3847.5','18','0','50445','0','50445','2026-08-05','2026-08-06','08','2026','749858','5','approved'),(4,'1','861120260806','INV000005','10000','Nos','9','1800','9','1800','18','0','23600','0','23600','2026-08-06','2026-08-06','08','2026','749858','0','approved'),(5,'1','862820260807','INV000006','25000','Nos','9','22500','9','22500','18','0','295000','0','295000','2026-08-07','2026-08-01','08','2026','567576','0','approved'),(6,'1','156820260807','INV000007','15000','Nos','9','2700','9','2700','18','0','35400','0','35400','2026-08-10','2026-08-01','08','2026','749858','0','approved'),(7,'1','398020260815','INV000008','15000','Nos','9','2700','9','2700','18','0','35400','0','35400','2026-08-15','2026-08-15','08','2026','749858','0','approved');
/*!40000 ALTER TABLE `customer_bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_bill1`
--

DROP TABLE IF EXISTS `customer_bill1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_bill1` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(100) NOT NULL,
  `order_id` varchar(100) NOT NULL,
  `invoice_no` varchar(100) NOT NULL,
  `product_rate` varchar(100) NOT NULL,
  `unit` varchar(100) NOT NULL,
  `product_amount` varchar(100) NOT NULL,
  `paid_amount` varchar(100) NOT NULL,
  `remaining_amount` varchar(100) NOT NULL,
  `invoice_date` varchar(100) NOT NULL,
  `po_date` varchar(100) NOT NULL,
  `invoice_month` varchar(100) NOT NULL,
  `invoice_year` varchar(100) NOT NULL,
  `hsn_code` varchar(100) NOT NULL,
  `discount` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_bill1`
--

LOCK TABLES `customer_bill1` WRITE;
/*!40000 ALTER TABLE `customer_bill1` DISABLE KEYS */;
INSERT INTO `customer_bill1` VALUES (1,'1','806220260807','INV000002','9800','Nos','19600','0','19600','2026-08-07','2026-08-07','08','2026','749858','2','approved'),(2,'1','291520260807','INV000003','10000','Nos','275000','125000','150000','2026-08-07','2026-08-07','08','2026','749858','0','approved');
/*!40000 ALTER TABLE `customer_bill1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_details`
--

DROP TABLE IF EXISTS `customer_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_details` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(100) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `mobile_no` varchar(100) NOT NULL,
  `gst_no` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `pin_code` varchar(100) NOT NULL,
  `payment_term` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL DEFAULT 'approved',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_details`
--

LOCK TABLES `customer_details` WRITE;
/*!40000 ALTER TABLE `customer_details` DISABLE KEYS */;
INSERT INTO `customer_details` VALUES (1,'Anand Sagar','Vascon Pvt. Ltd','7498580961','22VVV657GD091','Gate no: 2, Metro Station B2, Hanumant Galli, Marine Line, Kalbadevi, Mumbai','Kalbadevi','Maharashtra','422410','100% Against PI','approved'),(2,'Umesh Sharma','Apollo Pvt. Ltd','7517959561','ZVV2016US9912','Apollo pvt ltd, murbad, kalyan badlapur highway, mumbai, maharashtra','Murbad','Maharashtra','432211','50% Advance Before Delivery','approved');
/*!40000 ALTER TABLE `customer_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_order`
--

DROP TABLE IF EXISTS `customer_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_order` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(100) NOT NULL,
  `order_id` varchar(100) NOT NULL,
  `invoice_no` varchar(100) NOT NULL,
  `po_no` varchar(100) NOT NULL,
  `product_id` varchar(100) NOT NULL,
  `product_rate` varchar(100) NOT NULL,
  `product_quantity` varchar(100) NOT NULL,
  `unit` varchar(100) NOT NULL,
  `sgst` varchar(100) NOT NULL,
  `sgst_amount` varchar(100) NOT NULL,
  `cgst` varchar(100) NOT NULL,
  `cgst_amount` varchar(100) NOT NULL,
  `igst` varchar(100) NOT NULL,
  `igst_amount` varchar(100) NOT NULL,
  `product_amount` varchar(100) NOT NULL,
  `invoice_date` varchar(100) NOT NULL,
  `po_date` varchar(100) NOT NULL,
  `invoice_month` varchar(100) NOT NULL,
  `invoice_year` varchar(100) NOT NULL,
  `hsn_code` varchar(100) NOT NULL,
  `discount` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_order`
--

LOCK TABLES `customer_order` WRITE;
/*!40000 ALTER TABLE `customer_order` DISABLE KEYS */;
INSERT INTO `customer_order` VALUES (1,'1','337820260805','INV000001','1','5','10000','2','Nos','9','1800','9','1800','18','0','23600','2026-08-05','2026-08-01','08','2026','749858','0','approved'),(3,'1','519620260805','INV000002','2','6','20000','2','Nos','9','3600','9','3600','18','0','47200','2026-08-05','2026-08-02','08','2026','5645645','0','approved'),(4,'1','322820260805','INV000003','3','5','10000','5','Nos','9','4500','9','4500','18','0','59000','2026-08-05','2026-08-05','08','2026','749858','0','approved'),(5,'1','322820260805','INV000003','3','6','20000','5','Nos','9','9000','9','9000','18','0','118000','2026-08-05','2026-08-05','08','2026','5645645','0','deleted'),(6,'1','322820260805','INV000003','3','7','25000','5','Nos','9','11250','9','11250','18','0','147500','2026-08-05','2026-08-05','08','2026','567576','0','approved'),(7,'1','615520260805','INV000004','4','5','8550','5','Nos','9','3847.5','9','3847.5','18','0','50445','2026-08-05','2026-08-06','08','2026','749858','5','approved'),(8,'1','861120260806','INV000005','3','5','10000','2','Nos','9','1800','9','1800','18','0','23600','2026-08-06','2026-08-06','08','2026','749858','0','approved'),(9,'1','862820260807','INV000006','112','7','25000','10','Nos','9','22500','9','22500','18','0','295000','2026-08-07','2026-08-01','08','2026','567576','0','approved'),(10,'1','156820260807','INV000007','110','5','10000','5','Nos','9','4500','9','4500','18','0','59000','2026-08-07','2026-08-01','08','2026','749858','0','deleted'),(11,'1','156820260807','INV000007','110','6','20000','5','Nos','9','9000','9','9000','18','0','118000','2026-08-07','2026-08-01','08','2026','5645645','0','deleted'),(12,'1','156820260807','INV000007','110','7','25000','5','Nos','9','11250','9','11250','18','0','147500','2026-08-07','2026-08-01','08','2026','567576','0','deleted'),(16,'1','322820260805','INV000003','3','5','15000','10','Nos','9','13500','9','13500','18','0','177000','2026-08-10','2026-08-05','08','2026','749858','0','approved'),(19,'1','156820260807','INV000007','7','5','15000','2','Nos','9','2700','9','2700','18','0','35400','2026-08-10','2026-08-01','08','2026','749858','0','approved'),(20,'1','322820260805','INV000003','3','5','15000','2','Nos','9','2700','9','2700','18','0','35400','2026-08-10','2026-08-05','08','2026','749858','0','approved'),(21,'1','398020260815','INV000008','07','5','15000','2','Nos','9','2700','9','2700','18','0','35400','2026-08-15','2026-08-15','08','2026','749858','0','approved');
/*!40000 ALTER TABLE `customer_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_order1`
--

DROP TABLE IF EXISTS `customer_order1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_order1` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(100) NOT NULL,
  `order_id` varchar(100) NOT NULL,
  `invoice_no` varchar(100) NOT NULL,
  `po_no` varchar(100) NOT NULL,
  `product_id` varchar(100) NOT NULL,
  `product_rate` varchar(100) NOT NULL,
  `product_quantity` varchar(100) NOT NULL,
  `unit` varchar(100) NOT NULL,
  `product_amount` varchar(100) NOT NULL,
  `invoice_date` varchar(100) NOT NULL,
  `po_date` varchar(100) NOT NULL,
  `invoice_month` varchar(100) NOT NULL,
  `invoice_year` varchar(100) NOT NULL,
  `hsn_code` varchar(100) NOT NULL,
  `discount` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_order1`
--

LOCK TABLES `customer_order1` WRITE;
/*!40000 ALTER TABLE `customer_order1` DISABLE KEYS */;
INSERT INTO `customer_order1` VALUES (1,'1','240120260807','INV000001','1','5','10000','2','Nos','20000','2026-08-07','2026-08-07','08','2026','749858','0','approved'),(2,'1','806220260807','INV000002','2','5','9800','2','Nos','19600','2026-08-07','2026-08-07','08','2026','749858','2','approved'),(3,'1','291520260807','INV000003','3','5','10000','5','Nos','50000','2026-08-07','2026-08-07','08','2026','749858','0','approved'),(4,'1','291520260807','INV000003','3','6','20000','5','Nos','100000','2026-08-07','2026-08-07','08','2026','5645645','0','approved'),(5,'1','291520260807','INV000003','3','7','25000','5','Nos','125000','2026-08-07','2026-08-07','08','2026','567576','0','approved');
/*!40000 ALTER TABLE `customer_order1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_payment_history`
--

DROP TABLE IF EXISTS `customer_payment_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_payment_history` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `receipt_no` varchar(100) NOT NULL,
  `customer_id` varchar(100) NOT NULL,
  `customer_bill_id` varchar(100) NOT NULL,
  `order_id` varchar(100) NOT NULL,
  `tot_remaining_amnt` varchar(100) NOT NULL,
  `paid_amnt` varchar(100) NOT NULL,
  `remaining_amount` varchar(100) NOT NULL,
  `paid_to_account` varchar(100) NOT NULL,
  `payment_type` varchar(100) NOT NULL,
  `cheque_no` varchar(100) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `credit_card_last_four_digit` varchar(100) NOT NULL,
  `transaction_id` varchar(100) NOT NULL,
  `finance_card_last_four_digit` varchar(100) NOT NULL,
  `transaction_id1` varchar(100) NOT NULL,
  `transaction_no` varchar(100) NOT NULL,
  `bank_name1` varchar(100) NOT NULL,
  `payment_date` varchar(100) NOT NULL,
  `reminder_date` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL DEFAULT 'approved',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_payment_history`
--

LOCK TABLES `customer_payment_history` WRITE;
/*!40000 ALTER TABLE `customer_payment_history` DISABLE KEYS */;
INSERT INTO `customer_payment_history` VALUES (1,'','1','1','519620260805','47200','7200','40000','','cash','','','','','','','','','2026-08-06','2026-08-31','approved'),(2,'','1','1','519620260805','40000','20000','20000','Ganesh Divekar','cash','','','','','','','','','2026-08-06','2026-08-31','approved'),(3,'','1','1','519620260805','20000','10000','10000','Ganesh Divekar','cash','','','','','','','','','2026-08-06','2026-08-31','approved'),(4,'','1','1','519620260805','10000','10000','0','Ganesh Divekar','cash','','','','','','','','','2026-08-07','2026-08-31','approved');
/*!40000 ALTER TABLE `customer_payment_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_payment_history1`
--

DROP TABLE IF EXISTS `customer_payment_history1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_payment_history1` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(100) NOT NULL,
  `customer_bill_id` varchar(100) NOT NULL,
  `order_id` varchar(100) NOT NULL,
  `tot_remaining_amnt` varchar(100) NOT NULL,
  `paid_amnt` varchar(100) NOT NULL,
  `remaining_amount` varchar(100) NOT NULL,
  `paid_to_account` varchar(100) NOT NULL,
  `payment_type` varchar(100) NOT NULL,
  `cheque_no` varchar(100) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `credit_card_last_four_digit` varchar(100) NOT NULL,
  `transaction_id` varchar(100) NOT NULL,
  `finance_card_last_four_digit` varchar(100) NOT NULL,
  `transaction_id1` varchar(100) NOT NULL,
  `transaction_no` varchar(100) NOT NULL,
  `bank_name1` varchar(100) NOT NULL,
  `payment_date` varchar(100) NOT NULL,
  `reminder_date` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL DEFAULT 'approved',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_payment_history1`
--

LOCK TABLES `customer_payment_history1` WRITE;
/*!40000 ALTER TABLE `customer_payment_history1` DISABLE KEYS */;
INSERT INTO `customer_payment_history1` VALUES (1,'1','2','291520260807','275000','75000','200000','Ganesh Divekar','cash','','','','','','','','','2026-08-07','2026-08-31',''),(2,'1','2','291520260807','200000','50000','150000','Ganesh Divekar','cash','','','','','','','','','2026-08-07','2026-08-31','approved'),(3,'1','1','806220260807','19600','600','19000','Ganesh Divekar','cash','','','','','','','','','2026-08-07','2026-08-31','approved');
/*!40000 ALTER TABLE `customer_payment_history1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_quotation`
--

DROP TABLE IF EXISTS `customer_quotation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_quotation` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(100) NOT NULL,
  `order_id` varchar(100) NOT NULL,
  `quotation_no` varchar(100) NOT NULL,
  `product_id` varchar(100) NOT NULL,
  `product_rate` varchar(100) NOT NULL,
  `product_quantity` varchar(100) NOT NULL,
  `unit` varchar(100) NOT NULL,
  `sgst` varchar(100) NOT NULL,
  `sgst_amount` varchar(100) NOT NULL,
  `cgst` varchar(100) NOT NULL,
  `cgst_amount` varchar(100) NOT NULL,
  `igst` varchar(100) NOT NULL,
  `igst_amount` varchar(100) NOT NULL,
  `product_amount` varchar(100) NOT NULL,
  `quotation_date` varchar(100) NOT NULL,
  `quotation_month` varchar(100) NOT NULL,
  `quotation_year` varchar(100) NOT NULL,
  `hsn_code` varchar(100) NOT NULL,
  `discount` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL DEFAULT 'approved',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_quotation`
--

LOCK TABLES `customer_quotation` WRITE;
/*!40000 ALTER TABLE `customer_quotation` DISABLE KEYS */;
INSERT INTO `customer_quotation` VALUES (1,'2','852620260809','QT000001','5','10000','2','Nos','9','1800','9','1800','18','0','23600','2026-08-09','08','2026','749858','0','approved');
/*!40000 ALTER TABLE `customer_quotation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_quotation_nongst`
--

DROP TABLE IF EXISTS `customer_quotation_nongst`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_quotation_nongst` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(100) NOT NULL,
  `order_id` varchar(100) NOT NULL,
  `quotation_no` varchar(100) NOT NULL,
  `product_id` varchar(100) NOT NULL,
  `product_rate` varchar(100) NOT NULL,
  `product_quantity` varchar(100) NOT NULL,
  `unit` varchar(100) NOT NULL,
  `product_amount` varchar(100) NOT NULL,
  `quotation_date` varchar(100) NOT NULL,
  `quotation_month` varchar(100) NOT NULL,
  `quotation_year` varchar(100) NOT NULL,
  `hsn_code` varchar(100) NOT NULL,
  `discount` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL DEFAULT 'approved',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_quotation_nongst`
--

LOCK TABLES `customer_quotation_nongst` WRITE;
/*!40000 ALTER TABLE `customer_quotation_nongst` DISABLE KEYS */;
INSERT INTO `customer_quotation_nongst` VALUES (1,'2','865520260809','QT000001','5','10000','5','Nos','50000','2026-08-09','08','2026','749858','0','approved'),(2,'1','810620260809','QT000002','5','10000','2','Nos','20000','2026-08-09','08','2026','749858','0','approved'),(3,'1','810620260809','QT000002','6','20000','2','Nos','40000','2026-08-09','08','2026','5645645','0','approved'),(4,'1','810620260809','QT000002','7','25000','2','Nos','50000','2026-08-09','08','2026','567576','0','approved');
/*!40000 ALTER TABLE `customer_quotation_nongst` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expense`
--

DROP TABLE IF EXISTS `expense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expense` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `vendor_name` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `expense_to_account` varchar(100) NOT NULL,
  `paid_from_account` varchar(100) NOT NULL,
  `payment_type` varchar(100) NOT NULL,
  `payment_mode` varchar(100) NOT NULL,
  `cheque_no` varchar(100) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `credit_card_last_four_digit` varchar(100) NOT NULL,
  `transaction_id` varchar(100) NOT NULL,
  `finance_card_last_four_digit` varchar(100) NOT NULL,
  `transaction_id1` varchar(100) NOT NULL,
  `transaction_no` varchar(100) NOT NULL,
  `bank_name1` varchar(100) NOT NULL,
  `payment_date` varchar(100) NOT NULL,
  `invoice_no` varchar(100) NOT NULL,
  `remark` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL DEFAULT 'approved',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expense`
--

LOCK TABLES `expense` WRITE;
/*!40000 ALTER TABLE `expense` DISABLE KEYS */;
INSERT INTO `expense` VALUES (1,'Ganesh Divekar','1500','1','6','expense','cash','','','','','','','','','2026-08-13','INV000002','Salary','approved'),(2,'Ganesh Divekar','1500','6','1','expense','cash','','','','','','','','','2026-08-13','INV000002','Salary','approved'),(3,'Ganesh Divekar','1500','6','1','expense','cash','','','','','','','','','2026-08-13','INV000002','Salary','approved'),(4,'Ganesh Divekar','1500','6','1','expense','cash','','','','','','','','','2026-08-13','INV000002','Salary','approved'),(5,'Ganesh Divekar','1500','1','6','expense','cash','','','','','','','','','2026-08-13','INV000002','Salary','approved'),(6,'Swapnil Divekar','500','6','1','expense','cash','','','','','','','','','2026-08-13','INV000002','Salary','approved'),(7,'Kajal Divekar','5000','7','6','expense','cash','','','','','','','','','2026-08-14','INV000002','Salary','approved');
/*!40000 ALTER TABLE `expense` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opening_balance`
--

DROP TABLE IF EXISTS `opening_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `opening_balance` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `account_name` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `payment_mode` varchar(100) NOT NULL,
  `payment_date` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL DEFAULT 'approved',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opening_balance`
--

LOCK TABLES `opening_balance` WRITE;
/*!40000 ALTER TABLE `opening_balance` DISABLE KEYS */;
INSERT INTO `opening_balance` VALUES (1,'1','50000','credit','11-08-2026','approved'),(2,'6','50000','expense','11-08-2026','approved'),(3,'1','10000','credit','11-08-2026','approved'),(4,'6','560','credit','11-08-2026','approved'),(5,'1','500','credit','11-08-2026','approved'),(6,'6','500','expense','11-08-2026','approved'),(7,'6','','','','approved'),(8,'1','','','','approved'),(9,'6','','','','approved'),(10,'1','','','','approved'),(11,'1','50000','credit','13-08-2026','approved');
/*!40000 ALTER TABLE `opening_balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(100) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `barcode` varchar(100) NOT NULL,
  `hsn_code` varchar(100) NOT NULL,
  `unit` varchar(100) NOT NULL,
  `gst_percentage` varchar(100) NOT NULL,
  `purchase_price` varchar(100) NOT NULL,
  `selling_price` varchar(100) NOT NULL,
  `opening_stock` varchar(100) NOT NULL,
  `reminder_stock` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `created_date` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (5,'Raw Sewage pump','22098700','PRD550899','749858','Nos','18','10000','15000','-11','5','Kirloskar\'s Good Pump Service\'s','2026-07-28','approved'),(6,'Filter Feed Pump','3423434','PRD331365','5645645','Nos','18','20000','25000','6','5','Kirloskar\'s Good Pump Service\'s','2026-07-29','approved'),(7,'sludge recirculation Pump','75757','PRD054611','567576','Nos','18','25000','30000','-6','5','Kirloskar\'s Good Pump Service\'s','2026-07-20','approved'),(8,'','','','','','','','','','','','','deleted');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_bill`
--

DROP TABLE IF EXISTS `purchase_bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_bill` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(100) NOT NULL,
  `order_id` varchar(100) NOT NULL,
  `purchase_order_no` varchar(100) NOT NULL,
  `product_id` varchar(100) NOT NULL,
  `product_rate` varchar(100) NOT NULL,
  `unit` varchar(100) NOT NULL,
  `sgst` varchar(100) NOT NULL,
  `sgst_amount` varchar(100) NOT NULL,
  `cgst` varchar(100) NOT NULL,
  `cgst_amount` varchar(100) NOT NULL,
  `igst` varchar(100) NOT NULL,
  `igst_amount` varchar(100) NOT NULL,
  `product_amount` varchar(100) NOT NULL,
  `paid_amount` varchar(100) NOT NULL,
  `remaining_amount` varchar(100) NOT NULL,
  `purchase_date` varchar(100) NOT NULL,
  `po_date` varchar(100) NOT NULL,
  `purchase_month` varchar(100) NOT NULL,
  `purchase_year` varchar(100) NOT NULL,
  `hsn_code` varchar(100) NOT NULL,
  `discount` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_bill`
--

LOCK TABLES `purchase_bill` WRITE;
/*!40000 ALTER TABLE `purchase_bill` DISABLE KEYS */;
INSERT INTO `purchase_bill` VALUES (1,'1','373420260728','PO000001','5','200','','9','261','9','261','0','0','3422','3422','0','2026-07-28','2026-07-28','07','2026','','0','approved'),(2,'2','777020260729','PO000012','5','200','','9','270','9','270','18','0','3540','0','3540','2026-07-29','2026-07-29','07','2026','','0','approved'),(3,'2','933320260729','PO000013','5','10000','','9','4500','9','4500','18','0','59000','0','59000','2026-07-29','2026-07-29','07','2026','','0','approved'),(4,'1','806320260730','PO000014','5','10000','','9','9900','9','9900','18','0','129800','100000','29800','2026-07-30','2026-07-30','07','2026','','0','approved'),(5,'1','712120260730','PO000015','5','10000','','9','1800','9','1800','18','0','23600','23600','0','2026-07-30','2026-07-30','07','2026','','0','approved'),(6,'1','680220260730','PO000016','5','10000','','9','4500','9','4500','18','0','59000','0','59000','2026-07-30','2026-07-30','07','2026','','0','approved'),(7,'1','680220260730','PO000016','5','10000','','9','4500','9','4500','18','0','59000','0','59000','2026-07-30','2026-07-30','07','2026','','0','approved'),(8,'1','512220260730','PO000017','5','10000','','9','4500','9','4500','18','0','59000','0','59000','2026-07-30','2026-07-30','07','2026','','0','approved'),(9,'1','349420260807','PO000022','7','25000','Nos','9','22500','9','22500','18','0','295000','95000','200000','2026-08-07','2026-08-07','08','2026','567576','0','approved');
/*!40000 ALTER TABLE `purchase_bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_product`
--

DROP TABLE IF EXISTS `purchase_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_product` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(100) NOT NULL,
  `order_id` varchar(100) NOT NULL,
  `purchase_order_no` varchar(100) NOT NULL,
  `product_id` varchar(100) NOT NULL,
  `product_rate` varchar(100) NOT NULL,
  `product_quantity` varchar(100) NOT NULL,
  `unit` varchar(100) NOT NULL,
  `sgst` varchar(100) NOT NULL,
  `sgst_amount` varchar(100) NOT NULL,
  `cgst` varchar(100) NOT NULL,
  `cgst_amount` varchar(100) NOT NULL,
  `igst` varchar(100) NOT NULL,
  `igst_amount` varchar(100) NOT NULL,
  `product_amount` varchar(100) NOT NULL,
  `purchase_date` varchar(100) NOT NULL,
  `po_date` varchar(100) NOT NULL,
  `purchase_month` varchar(100) NOT NULL,
  `purchase_year` varchar(100) NOT NULL,
  `hsn_code` varchar(100) NOT NULL,
  `discount` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_product`
--

LOCK TABLES `purchase_product` WRITE;
/*!40000 ALTER TABLE `purchase_product` DISABLE KEYS */;
INSERT INTO `purchase_product` VALUES (20,'1','373420260728','PO000001','5','200','2','','9','36','9','36','0','0','472','2026-07-28','2026-07-28','07','2026','','0','approved'),(21,'1','373420260728','PO000001','6','300','3','','9','81','9','81','0','0','1062','2026-07-28','2026-07-28','07','2026','','0','approved'),(22,'1','373420260728','PO000001','7','400','4','','9','144','9','144','0','0','1888','2026-07-28','2026-07-28','07','2026','','0','approved'),(23,'1','753320260728','PO000002','5','200','2','','9','36','9','36','18','0','472','2026-07-28','2026-07-28','07','2026','','0','approved'),(24,'1','180220260728','PO000003','6','20000','5','','9','9000','9','9000','18','0','118000','2026-07-28','2026-07-29','07','2026','','0','approved'),(25,'3','882720260728','PO000004','5','9900','5','','9','4455','9','4455','18','0','58410','2026-07-28','2026-07-29','07','2026','','1','approved'),(26,'1','123120260729','PO000005','5','10000','5','','9','4500','9','4500','18','0','59000','2026-07-29','2026-07-29','07','2026','','0','approved'),(27,'2','812320260729','PO000006','5','10000','2','','9','1800','9','1800','18','0','23600','2026-07-29','2026-07-29','07','2026','','0','approved'),(28,'2','174520260729','PO000006','5','10000','2','','9','1800','9','1800','18','0','23600','2026-07-29','2026-07-29','07','2026','','0','approved'),(29,'2','883420260729','PO000007','7','200','2','','9','36','9','36','18','0','472','2026-07-29','2026-07-29','07','2026','','0','approved'),(30,'1','555120260729','PO000008','5','10000','6','','9','5400','9','5400','18','0','70800','2026-07-29','2026-07-29','07','2026','','0','approved'),(31,'1','609020260729','PO000009','6','20000','5','','9','9000','9','9000','18','0','118000','2026-07-29','2026-07-29','07','2026','','0','approved'),(32,'2','133020260729','PO000010','6','20000','5','','9','0','9','0','18','18000','118000','2026-07-29','2026-07-29','07','2026','','0','approved'),(33,'3','633820260729','PO000011','5','200','2','','9','0','9','0','18','72','472','2026-07-29','2026-07-29','07','2026','','0','approved'),(34,'2','777020260729','PO000012','5','200','5','','9','90','9','90','18','0','1180','2026-07-29','2026-07-29','07','2026','','0','approved'),(35,'2','777020260729','PO000012','6','200','5','','9','90','9','90','18','0','1180','2026-07-29','2026-07-29','07','2026','','0','approved'),(36,'2','777020260729','PO000012','7','200','5','','9','90','9','90','18','0','1180','2026-07-29','2026-07-29','07','2026','','0','approved'),(37,'2','933320260729','PO000013','5','10000','5','','9','4500','9','4500','18','0','59000','2026-07-29','2026-07-29','07','2026','','0','approved'),(38,'1','806320260730','PO000014','5','10000','2','','9','1800','9','1800','18','0','23600','2026-07-30','2026-07-30','07','2026','','0','approved'),(39,'1','806320260730','PO000014','6','20000','2','','9','3600','9','3600','18','0','47200','2026-07-30','2026-07-30','07','2026','','0','approved'),(40,'1','806320260730','PO000014','7','25000','2','','9','4500','9','4500','18','0','59000','2026-07-30','2026-07-30','07','2026','','0','approved'),(41,'1','712120260730','PO000015','5','10000','2','','9','1800','9','1800','18','0','23600','2026-07-30','2026-07-30','07','2026','','0','approved'),(42,'1','680220260730','PO000016','5','10000','5','','9','4500','9','4500','18','0','59000','2026-07-30','2026-07-30','07','2026','','0','approved'),(43,'1','512220260730','PO000017','5','10000','5','','9','4500','9','4500','18','0','59000','2026-07-30','2026-07-30','07','2026','','0','approved'),(44,'1','685120260731','PO000018','5','10000','2','','9','1800','9','1800','18','0','23600','2026-07-31','2026-07-31','07','2026','','0','approved'),(45,'1','685120260731','PO000018','6','20000','3','','9','5400','9','5400','18','0','70800','2026-07-31','2026-07-31','07','2026','','0','approved'),(46,'1','685120260731','PO000018','7','25000','4','','9','9000','9','9000','18','0','118000','2026-07-31','2026-07-31','07','2026','','0','approved'),(47,'1','685120260731','PO000018','5','10000','5','','9','4500','9','4500','18','0','59000','2026-07-31','2026-07-31','07','2026','','0','approved'),(48,'1','935720260803','PO000019','5','200','2','','9','36','9','36','18','0','472','2026-08-03','2026-08-03','08','2026','','0','approved'),(49,'1','935720260803','PO000019','5','10000','5','','9','4500','9','4500','18','0','59000','2026-08-03','2026-08-03','08','2026','','0','approved'),(50,'1','928720260803','PO000019','5','200','2','','9','36','9','36','18','0','472','2026-08-03','2026-08-03','08','2026','','0','approved'),(51,'1','928720260803','PO000019','5','10000','5','','9','4500','9','4500','18','0','59000','2026-08-03','2026-08-03','08','2026','','0','approved'),(52,'1','928720260803','PO000019','7','25000','5','','9','11250','9','11250','18','0','147500','2026-08-03','2026-08-03','08','2026','','0','approved'),(53,'1','279320260803','PO000020','5','10000','2','','9','1800','9','1800','18','0','23600','2026-08-03','2026-08-03','08','2026','','0','approved'),(54,'1','279320260803','PO000020','6','20000','5','','9','9000','9','9000','18','0','118000','2026-08-03','2026-08-03','08','2026','','0','approved'),(55,'1','403620260803','PO000020','5','10000','2','','9','1800','9','1800','18','0','23600','2026-08-03','2026-08-03','08','2026','','0','approved'),(56,'1','403620260803','PO000020','6','20000','5','','9','9000','9','9000','18','0','118000','2026-08-03','2026-08-03','08','2026','','0','approved'),(57,'1','501820260807','PO000021','5','10000','10','Nos','9','9000','9','9000','18','0','118000','2026-08-07','2026-08-07','08','2026','749858','0','approved'),(58,'1','349420260807','PO000022','7','25000','10','Nos','9','22500','9','22500','18','0','295000','2026-08-07','2026-08-07','08','2026','567576','0','approved'),(59,'1','807220260815','PO000023','5','200','2','Nos','9','36','9','36','18','0','472','2026-08-15','2026-08-15','08','2026','749858','0','approved'),(60,'1','822920260815','PO000023','5','200','2','Nos','9','36','9','36','18','0','472','2026-08-15','2026-08-15','08','2026','749858','0','approved'),(61,'1','244220260815','PO000023','5','200','2','Nos','9','36','9','36','18','0','472','2026-08-15','2026-08-15','08','2026','749858','0','approved');
/*!40000 ALTER TABLE `purchase_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotation_bill`
--

DROP TABLE IF EXISTS `quotation_bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quotation_bill` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(100) NOT NULL,
  `order_id` varchar(100) NOT NULL,
  `quotation_no` varchar(100) NOT NULL,
  `product_rate` varchar(100) NOT NULL,
  `unit` varchar(100) NOT NULL,
  `sgst` varchar(100) NOT NULL,
  `sgst_amount` varchar(100) NOT NULL,
  `cgst` varchar(100) NOT NULL,
  `cgst_amount` varchar(100) NOT NULL,
  `igst` varchar(100) NOT NULL,
  `igst_amount` varchar(100) NOT NULL,
  `product_amount` varchar(100) NOT NULL,
  `paid_amount` varchar(100) NOT NULL,
  `remaining_amount` varchar(100) NOT NULL,
  `quotation_date` varchar(100) NOT NULL,
  `quotation_month` varchar(100) NOT NULL,
  `quotation_year` varchar(100) NOT NULL,
  `hsn_code` varchar(100) NOT NULL,
  `discount` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotation_bill`
--

LOCK TABLES `quotation_bill` WRITE;
/*!40000 ALTER TABLE `quotation_bill` DISABLE KEYS */;
INSERT INTO `quotation_bill` VALUES (1,'2','852620260809','QT000001','10000','Nos','9','1800','9','1800','18','0','23600','0','23600','2026-08-09','08','2026','749858','0','approved');
/*!40000 ALTER TABLE `quotation_bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotation_bill_nongst`
--

DROP TABLE IF EXISTS `quotation_bill_nongst`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quotation_bill_nongst` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(100) NOT NULL,
  `order_id` varchar(100) NOT NULL,
  `quotation_no` varchar(100) NOT NULL,
  `product_rate` varchar(100) NOT NULL,
  `unit` varchar(100) NOT NULL,
  `product_amount` varchar(100) NOT NULL,
  `paid_amount` varchar(100) NOT NULL,
  `remaining_amount` varchar(100) NOT NULL,
  `quotation_date` varchar(100) NOT NULL,
  `quotation_month` varchar(100) NOT NULL,
  `quotation_year` varchar(100) NOT NULL,
  `hsn_code` varchar(100) NOT NULL,
  `discount` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL DEFAULT 'approved',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotation_bill_nongst`
--

LOCK TABLES `quotation_bill_nongst` WRITE;
/*!40000 ALTER TABLE `quotation_bill_nongst` DISABLE KEYS */;
INSERT INTO `quotation_bill_nongst` VALUES (1,'2','865520260809','QT000001','10000','Nos','50000','0','50000','2026-08-09','08','2026','749858','0','approved'),(2,'1','810620260809','QT000002','10000','Nos','110000','0','110000','2026-08-09','08','2026','749858','0','approved');
/*!40000 ALTER TABLE `quotation_bill_nongst` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transfer_amount`
--

DROP TABLE IF EXISTS `transfer_amount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transfer_amount` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `from_account` varchar(100) NOT NULL,
  `to_account` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `payment_mode` varchar(100) NOT NULL,
  `payment_date` varchar(100) NOT NULL,
  `remark` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL DEFAULT 'approved',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transfer_amount`
--

LOCK TABLES `transfer_amount` WRITE;
/*!40000 ALTER TABLE `transfer_amount` DISABLE KEYS */;
INSERT INTO `transfer_amount` VALUES (1,'1','6','500','credit','12-08-2026','travel','approved'),(2,'6','1','560','credit','13-08-2026','travel','approved'),(3,'1','6','1500','credit','13-08-2026','petrol','approved'),(4,'1','6','1500','credit','13-08-2026','petrol','approved'),(5,'1','6','1500','credit','13-08-2026','petrol','approved'),(6,'1','6','1500','credit','13-08-2026','petrol','approved'),(7,'1','6','1500','credit','13-08-2026','petrol','approved'),(8,'1','6','1500','credit','13-08-2026','travel','approved'),(9,'1','6','1500','credit','13-08-2026','petrol','approved'),(10,'1','6','1500','expense','13-08-2026','petrol','approved'),(11,'1','6','1500','expense','13-08-2026','petrol','approved');
/*!40000 ALTER TABLE `transfer_amount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_registration`
--

DROP TABLE IF EXISTS `user_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_registration` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_registration`
--

LOCK TABLES `user_registration` WRITE;
/*!40000 ALTER TABLE `user_registration` DISABLE KEYS */;
INSERT INTO `user_registration` VALUES (1,'Ganesh Divekar','Nashik','divekarganesh94@gmail.com','1234','approved');
/*!40000 ALTER TABLE `user_registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendor_details`
--

DROP TABLE IF EXISTS `vendor_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendor_details` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `vendor_name` varchar(100) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `mobile_no` varchar(100) NOT NULL,
  `gst_no` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `pin_code` varchar(100) NOT NULL,
  `payment_term` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendor_details`
--

LOCK TABLES `vendor_details` WRITE;
/*!40000 ALTER TABLE `vendor_details` DISABLE KEYS */;
INSERT INTO `vendor_details` VALUES (1,'Dipika Sharma','Fluido Tech Pvt. Ltd','Dipika Sharma','7498580961','22VVV657GD091','Balewadi Pimpri-Chinchwad, Pune','Balewadi Pimpri-Chinchwad, Pune','Maharashtra','421001','100% Against PI','approved'),(2,'Rakesh Bharit','Rakesh Group Pvt. Ltd','Ganesh Divekar','7517550956','2VVRKB565GT','At Post Shevagedang ','Nashik','Mahashtra','422402','100% Against PI','approved'),(3,'Rakesh Bharit','Rakesh Group Pvt. Ltd','Ganesh Divekar','7517550956','2VVRKB565GT','At Post Shevagedang ','Nashik','Mahashtra','422402','100% Against PI','approved'),(4,'Madan Fadake','Fadake Polatry Farm Pvt. Ltd','7498580961','9357854512','SD464GJGW56','Hirawadi, Panchwati, Nashik','Hirawadi, Panchwati, Nashik','Maharashtra','422410','50% Advance Before Delivery','deleted'),(5,'Dipika Sharma','Fluido Tech Pvt. Ltd','Dipika Sharma','7498580961','22VVV657GD091','Balewadi Pimpri-Chinchwad, Pune','Pune','Maharashtra','421001','100% Against PI','deleted'),(6,'Fluido Tech','Fadake Polatry Farm Pvt. Ltd','Dipika Sharma','9357854512','SD464GJGW56','Hirawadi, Panchwati, Nashik','Nashik','Maharashtra','422410','50% Advance Before Delivery','deleted'),(27,'Fluido Tech','Fadake Polatry Farm Pvt. Ltd','Dipika Sharma','9357854512','SD464GJGW56','Hirawadi, Panchwati, Nashik','Nashik','Maharashtra','422410','50% Advance Before Delivery','deleted');
/*!40000 ALTER TABLE `vendor_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendor_payment_history`
--

DROP TABLE IF EXISTS `vendor_payment_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendor_payment_history` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `receipt_no` varchar(100) NOT NULL,
  `vendor_id` varchar(100) NOT NULL,
  `purchase_biil_id` varchar(100) NOT NULL,
  `order_id` varchar(100) NOT NULL,
  `tot_remaining_amnt` varchar(100) NOT NULL,
  `paid_amnt` varchar(100) NOT NULL,
  `remaining_amount` varchar(100) NOT NULL,
  `paid_to_account` varchar(100) NOT NULL,
  `payment_type` varchar(100) NOT NULL,
  `cheque_no` varchar(100) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `credit_card_last_four_digit` varchar(100) NOT NULL,
  `transaction_id` varchar(100) NOT NULL,
  `finance_card_last_four_digit` varchar(100) NOT NULL,
  `transaction_id1` varchar(100) NOT NULL,
  `transaction_no` varchar(100) NOT NULL,
  `bank_name1` varchar(100) NOT NULL,
  `payment_date` varchar(100) NOT NULL,
  `reminder_date` varchar(100) NOT NULL,
  `is_del` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendor_payment_history`
--

LOCK TABLES `vendor_payment_history` WRITE;
/*!40000 ALTER TABLE `vendor_payment_history` DISABLE KEYS */;
INSERT INTO `vendor_payment_history` VALUES (25,'RCP/2026-2027/0001','1','1','373420260728','3422','422','3000','Ganesh Divekar','cash','','','','','','','','','2026-08-03','2026-08-31','approved'),(26,'','1','5','712120260730','23600','3600','20000','Ganesh Divekar','cash','','','','','','','','','2026-08-05','2026-08-31','approved'),(27,'','1','5','712120260730','20000','20000','0','Ganesh Divekar','cash','','','','','','','','','2026-08-05','2026-08-31','approved'),(28,'','1','1','373420260728','3000','3000','0','Ganesh Divekar','cash','','','','','','','','','2026-08-06','2026-08-31','approved'),(29,'','1','9','349420260807','295000','95000','200000','Ganesh Divekar','cash','','','','','','','','','2026-08-07','2026-08-31','approved');
/*!40000 ALTER TABLE `vendor_payment_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-15 16:37:06
